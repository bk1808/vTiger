import {test,expect} from "@playwright/test";
import { goToSamDashBoard, navigateToBaseUrl} from "../utils/testHelper";


test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
});

test.describe('Show and Hide Columns in DDM Dashboard', () => {
    test('GIVEN a column is unchecked in the show/hide menu - THEN the column is hidden from the dashboard table', async ({page}) => {
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).toBeVisible();
        //hide column
        await page.getByTestId('show-hide-column-button').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'visible' });
        await page.getByRole('menuitem', { name: 'SAM ID' }).click();
        await page.locator('.MuiBackdrop-root').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'hidden' });
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).not.toBeVisible();

        // Reload page and verify column is still hidden
        await page.reload();
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).not.toBeVisible();

        //show column
        await page.getByTestId('show-hide-column-button').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'visible' });
        await page.getByRole('menuitem', { name: 'SAM ID' }).click();
        await page.locator('.MuiBackdrop-root').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'hidden' });
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).toBeVisible();
    });

    test('GIVEN multiple columns are unchecked - THEN they are hidden and reset button restores all columns', async ({page}) => {
        // Verify columns are initially visible
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).toBeVisible();
        await expect(page.getByRole('columnheader', { name: 'Data Type' })).toBeVisible();
        await expect(page.getByRole('columnheader', { name: 'Revision' })).toBeVisible();

        // Hide multiple columns
        await page.getByTestId('show-hide-column-button').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'visible' });
        await page.getByRole('menuitem', { name: 'SAM ID' }).click();
        await page.getByRole('menuitem', { name: 'Data Type' }).click();
        await page.getByRole('menuitem', { name: 'Revision' }).click();
        await page.locator('.MuiBackdrop-root').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'hidden' });

        // Verify columns are hidden
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).not.toBeVisible();
        await expect(page.getByRole('columnheader', { name: 'Data Type' })).not.toBeVisible();
        await expect(page.getByRole('columnheader', { name: 'Revision' })).not.toBeVisible();

        // Reset all columns using reset button
        await page.getByTestId('show-hide-column-button').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'visible' });
        await page.getByTestId('reset-columns-button').click();
        await page.locator('.MuiBackdrop-root').click();
        await page.locator('ul[role="menu"]').waitFor({ state: 'hidden' });

        // Verify all columns are now visible again
        await expect(page.getByRole('columnheader', { name: 'SAM ID' })).toBeVisible();
        await expect(page.getByRole('columnheader', { name: 'Data Type' })).toBeVisible();
        await expect(page.getByRole('columnheader', { name: 'Revision' })).toBeVisible();
    });
});