import {expect, test} from "@playwright/test";
import {navigateToBaseUrl,
} from "@root/tests/utils/testHelper";
import {validateAndVerifySamProvision} from "@root/tests/provision/utils/testHelper";
import {DISCIPLINE_SCHEMA} from "@root/tests/full-process/utils/constants";
import {KafkaService} from "@root/tests/utils/kafkaService";
import {KafkaMessage} from "kafkajs";
import {navigateToSystemAdministration} from "@root/tests/system-administration/common/testHelper";
import {KAFA_DISCIPLINE_TEST_TOPIC} from "@root/tests/utils/constants";

const kafkaService = new KafkaService();

// Setup before running the test
test.beforeAll(async () => {
    // Connect to Kafka and subscribe to the topic
    await kafkaService.connect();

    // Wait a bit after connecting to ensure the consumer is fully subscribed
    await new Promise(resolve => setTimeout(resolve, 500)); // Adding a small delay
});

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
});

test.describe('Discipline provision to Kafka', () => {
    test('GIVEN a call to Kafka discipline topic - THEN Discipline is provided as expected', async () => {

        // read messages from kafka
        const messages: KafkaMessage[] = await kafkaService.readMessages(KAFA_DISCIPLINE_TEST_TOPIC, 10000, true);
        expect(messages).not.toBeNull();
        expect(messages.length).toBeGreaterThan(0);

        // Expect that this particular message is valid and contains the expected fields
        const fieldPairs: Map<string, string> = new Map<string, string>([
            ["disciplines[60].id", "61"],
            ["disciplines[60].levelOneDiscipline.id", "62"],
            ["disciplines[60].levelOneDiscipline.nameDe", "Emissionen"],
            ["disciplines[60].levelOneDiscipline.nameEn", "Emissions"],
            ["disciplines[60].levelTwoDiscipline.id", "62.65"],
            ["disciplines[60].levelTwoDiscipline.nameDe", "Abgasreinigung + Schalldaempferanlage"],
            ["disciplines[60].levelTwoDiscipline.nameEn", "emission control + muffler system"],
            ["disciplines[60].prefix", "ASC"],
            ["disciplines[60].certificationTopic.id", "27"],
            ["disciplines[60].certificationTopic.nameDe", "Fzg."],
            ["disciplines[60].certificationTopic.nameEn", "vehicle"],
            ["disciplines[60].isActive", "true"],
            ["disciplines[60].cis2Id", "null"],
        ]);
        const schemaVersion = process.env.KAFKA_DISCIPLINE_PROVIDER_SCHEMA_VERSION;
        expect(await validateAndVerifySamProvision(schemaVersion,messages, DISCIPLINE_SCHEMA, fieldPairs)).toBe(true);
    });

    // Cleanup after the test is done
    test.afterAll(async () => {
        await kafkaService.disconnect();
    });
});