import {JSONSchema7} from "json-schema";
import Ajv from "ajv";
import {KafkaMessage} from "kafkajs";
import '../../utils/loadEnv';

export async function validateAndVerifySamProvision(
    schemaVersion:string|undefined,
    messages: KafkaMessage[],
    schema: JSONSchema7,
    fieldPairs: Map<string, string>
): Promise<boolean> {

    console.log(`Schema Version: ${schemaVersion}`);

    for (const kafkaMessage of messages) {

        const kafkaMessageValue = kafkaMessage.value?.toString();
        const kafkaMessageValueJson: string = JSON.parse(kafkaMessageValue ?? '');

        // Ignore schema version !== actual schema version
        const messageSchemaVersion = getNestedFieldValue(kafkaMessageValueJson, 'meta.schema.version');

        if (schemaVersion !== messageSchemaVersion) {
            continue;
        }

        console.debug('Validating kafkaMessageValue against schema:', JSON.stringify(kafkaMessageValueJson, null, 2));

        validateJsonAgainstSchema(kafkaMessageValueJson, schema);

        let allFieldsMatch = true; // Flag to check if all key-value pairs match

        for (const [key, expectedValue] of fieldPairs) {
            const kafkaFieldValue = getNestedFieldValue(kafkaMessageValueJson, `${key}`);

            console.debug(`Checking field '${key}': expected='${expectedValue}', actual='${kafkaFieldValue}'`);

            if (String(kafkaFieldValue).trim() !== String(expectedValue).trim()) {
                allFieldsMatch = false;
                break;
            }
        }

        if (allFieldsMatch) {
            console.debug('All fields match in this Kafka kafkaMessageValue.');
            return true;
        }
    }

    console.debug('No message fully matched all fieldPairs.');
    return false;
}

/**
 * Retrieves a nested field value from an object using a string path.
 * Supports dot notation (`"datatype.id"`) and array indexing (`"certificateTypes[0].name"`).
 *
 * @param {any} obj - The root object to traverse.
 * @param {string} field - The dot-separated path to the target value.
 *                         Can include array index notation (e.g., `"certificateTypes[0].name"`).
 * @returns {any} - The value at the specified path if it exists, otherwise `undefined`.
 *
 * @example
 * // Example 1: Accessing a property inside an object
 * const obj1 = { datatype: { id: 42, type: "string" } };
 * console.log(getNestedFieldValue(obj1, "datatype.id")); // Output: 42
 *
 * @example
 * // Example 2: Accessing an array element inside an object
 * const obj2 = { certificateTypes: [{ name: "ISO 9001" }, { name: "HACCP" }] };
 * console.log(getNestedFieldValue(obj2, "certificateTypes[0].name")); // Output: "ISO 9001"
 *
 * @example
 * // Example 3: Handling missing properties
 * const obj3 = { datatype: { type: "integer" } };
 * console.log(getNestedFieldValue(obj3, "datatype.id")); // Output: undefined
 *
 * @example
 * // Example 4: Handling an out-of-bounds array index
 * const obj4 = { certificateTypes: [{ name: "ISO 9001" }] };
 * console.log(getNestedFieldValue(obj4, "certificateTypes[2].name")); // Output: undefined
 */
function getNestedFieldValue(obj: any, field: string): any {
    return field.split('.').reduce((accumulator, part) => {
        if (!accumulator) return undefined;

        // Check if part contains array index notation (e.g., "certificateTypes[0]")
        const ARRAY_INDEX_REGEX = /^(.+)\[(\d+)]$/;
        const arrayIndexMatch = part.match(ARRAY_INDEX_REGEX);
        if (arrayIndexMatch) {
            const arrayKey = arrayIndexMatch[1];  // Extract property name
            const index = Number(arrayIndexMatch[2]); // Extract array index

            return Array.isArray(accumulator[arrayKey]) ? accumulator[arrayKey][index] : undefined;
        }

        return accumulator[part];
    }, obj);
}


export function validateJsonAgainstSchema(jsonData: string, schema: JSONSchema7): boolean {
    const ajv = new Ajv({allErrors: true, formats: {"date-time": /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/}});
    const validate = ajv.compile(schema);
    const valid = validate(jsonData);

    if (!valid) {
        console.error("Schema validation errors:", validate.errors);
    }

    return valid;
}