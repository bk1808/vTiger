import {expect, Page, test} from "@playwright/test";
import {
    goToSamCreateForm,
    goToSamDashBoard, navigateToBaseUrl,
    reviseAndVerifyStatusOfSam,
} from "@root/tests/utils/testHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {
    KAFKA_SAM_REVISION_TEST_TOPIC,
    KGUEN_IN_RANGE, PID_USER,
    RULE_TYPE_IDS, SAM_FACTORY_APPLICATION_LAYER_IDS,
    SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS,
    SAM_FACTORY_CERTUS_FUNCTION_IDS,
    SAM_FACTORY_CERTUS_MARKET_IDS,
    SAM_FACTORY_CERTUS_TOPIC_IDS,
    SAM_FACTORY_CERTUS_TYPE_IDS,
    SAM_FACTORY_CLUSTER_IDS, SAM_FACTORY_CONDITION_IDS,
    SAM_FACTORY_DATA_TYPE_IDS, SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_SYSTEM_NAME_IDS,
    SYSTEM_AFFILIATION_ABBREVIATION
} from "@root/tests/utils/constants";
import {validateAndVerifySamProvision} from "@root/tests/provision/utils/testHelper";
import {SAM_PROVISION_SCHEMA} from "@root/tests/full-process/utils/constants";
import {KafkaService} from "@root/tests/utils/kafkaService";
import {KafkaMessage} from "kafkajs";

const kafkaService = new KafkaService();

async function createSamWithCertus(page: Page, samName: string) {
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        nameDe: samName,
        nameEn: samName,
        samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
        certusMarket: SAM_FACTORY_CERTUS_MARKET_IDS.EU,
        certusCertificateTopic: SAM_FACTORY_CERTUS_TOPIC_IDS.LIGHTING,
        certusCertificateType: SAM_FACTORY_CERTUS_TYPE_IDS.TYPE_APPROVAL,
        certusAdditionalSpecification: SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS.CERTIFICATES,
        certusFunction:SAM_FACTORY_CERTUS_FUNCTION_IDS.CERTIFICATES
    });

    // Submit Data
    await page.getByTestId('submit-button').click();

    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);
}

async function createSamWithDerived(page: Page, samName: string) {
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        nameDe: samName,
        nameEn: samName,
        featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
        unit: 'unit-A',
        featureDataTypeRegularExpression: 'featureDataTypeRegularExpression-1,23457E+12',
        samType: SAM_FACTORY_SAM_TYPE_IDS.DERIVED,
        derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.FEATURE_TRANSFER_FUNCTION,
        ruleType: RULE_TYPE_IDS.LOCATION,
        derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.BOM_PART_POSV,
        derivedFeatureValueInputOneSamId: 'derivedFeatureValueInputOneSamId-c97c9121-1380-4a85-b12e-73367509e070',
        derivedFeatureCondition: SAM_FACTORY_CONDITION_IDS.MAIN_MODULE,
        derivedFeatureConditionValue: 'someConditionValue',
        derivedFeatureValueExplanation: 'someExplanation',
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD,
        kguens: ['000-99', KGUEN_IN_RANGE],
        legalVerificationDrawing: SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS.GE_NACHWEIS,
        systemAffiliations: [SYSTEM_AFFILIATION_ABBREVIATION],
    });

    // Submit Data
    await page.getByTestId('submit-button').click();

    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);
}

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);

    // Connect to Kafka and subscribe to the topic
    await kafkaService.connect();

    // Wait a bit after connecting to ensure the consumer is fully subscribed
    await new Promise(resolve => setTimeout(resolve, 500)); // Adding a small delay
});

test.describe('SAM provision to Kafka', () => {

    test('GIVEN a new SAM with Certus fields set is created - THEN SAM is provided to Kafka', async ({page}) => {

        const postfix = Date.now();
        const samName = `SAM-Provision:Certus` + postfix;

        await createSamWithCertus(page, samName);
        await reviseAndVerifyStatusOfSam(page);

        // read messages from kafka
        const messages: KafkaMessage[] = await kafkaService.readMessages(KAFKA_SAM_REVISION_TEST_TOPIC, 10000, true);
        expect(messages).not.toBeNull();
        expect(messages.length).toBeGreaterThan(0);

        // Adding a small delay to wait for the message to be consumed
        await new Promise(resolve => setTimeout(resolve, 5000));

        // define the expected SAM fields expected in the Kafka message
        const fieldPairs: Map<string, string> = new Map<string, string>([
            ["sam.nameDe", samName],
            ["sam.nameEn", samName],
            ["sam.featureDataType.id", "10"],
            ["sam.masterDataSystem.id", "2"],
            ["sam.masterDataSystem.nameDe", "CERTUS"],
            ["sam.masterDataSystem.nameEn", "CERTUS"],
            ["sam.status.id", "3"],
            ["sam.status.nameDe", "aktiv"],
            ["sam.status.nameEn", "active"],
            ["sam.status.objectType", "samRevision"],
            ["sam.responsibleDiscipline.classificationId", "3"],
            ["sam.responsibleDiscipline.levelOneId", "3"],
            ["sam.responsibleDiscipline.levelTwoId", "3"],
            ["sam.responsibleDiscipline.nameDe", "Alcohol Interlock (AI):Alcohol Interlock (AI)"],
            ["sam.responsibleDiscipline.nameEn", "Alcohol Interlock (AI):Alcohol Interlock (AI)"],
            ["sam.certificationTopic.id", "3"],
            ["sam.certificationTopic.nameDe", "Alcohol Interlock (AI)"],
            ["sam.certificationTopic.nameEn", "Alcohol Interlock (AI)"],
            ["sam.creator", PID_USER],
            ["sam.approvalRequester", PID_USER],
            ["sam.approver", "MISHRAD"],
            ["sam.samType.id", "1"],
            ["sam.samType.nameDe", "Direkt"],
            ["sam.samType.nameEn", "Direct"],

            ["sam.certus.market.id", "4"],
            ["sam.certus.market.name", "EU"],

            ["sam.certus.certificateTypes[0].id", "1"],
            ["sam.certus.certificateTypes[0].type", "Type-approval"],

            ["sam.certus.certificateTopic.id", "1"],
            ["sam.certus.certificateTopic.nameDe", "BELEUCHTUNG"],
            ["sam.certus.certificateTopic.nameEn", "LIGHTING"],

            ["sam.certus.additionalSpecification.id", "5"],
            ["sam.certus.additionalSpecification.nameDe", "Zertifikate"],
            ["sam.certus.additionalSpecification.nameEn", "Certificates"],
            ["sam.certus.additionalSpecification.value", "certificates"],

            ["sam.certus.function.id", "7"],
            ["sam.certus.function.nameDe", "Bremsleuchte"],
            ["sam.certus.function.nameEn", "Stop lamp"]
        ]);
        const schemaVersion = process.env.KAFKA_SAM_PROVIDER_SCHEMA_VERSION; 
        expect(await validateAndVerifySamProvision(schemaVersion,messages, SAM_PROVISION_SCHEMA, fieldPairs)).toBe(true);
    });

    test('GIVEN a new SAM with Number, derived and Smaragd, Kguen, legal verification drawing- THEN SAM is provided to Kafka', async ({page}) => {

        const postfix = Date.now();
        const samName = `SAM-Provision:Certus` + postfix;

        await createSamWithDerived(page, samName);
        await reviseAndVerifyStatusOfSam(page);

        // read messages from kafka
        const messages: KafkaMessage[] = await kafkaService.readMessages(KAFKA_SAM_REVISION_TEST_TOPIC, 10000, true);
        expect(messages).not.toBeNull();
        expect(messages.length).toBeGreaterThan(0);

        // Adding a small delay to ensure the message is produced before consuming
        await new Promise(resolve => setTimeout(resolve, 5000));

        // define the expected SAM fields expected in the Kafka message
        const fieldPairs: Map<string, string> = new Map<string, string>([
            ["sam.nameDe", samName],
            ["sam.nameEn", samName],
            ["sam.featureDataType.id", "12"],
            ["sam.featureDataType.nameDe", "Nummer"],
            ["sam.featureDataType.nameEn", "Number"],

            ["sam.masterDataSystem.id", "8"],
            ["sam.masterDataSystem.nameDe", "Smaragd"],
            ["sam.masterDataSystem.nameEn", "Smaragd"],

            ["sam.status.id", "3"],
            ["sam.status.nameDe", "aktiv"],
            ["sam.status.nameEn", "active"],
            ["sam.status.objectType", "samRevision"],

            ["sam.responsibleDiscipline.classificationId", "3"],
            ["sam.responsibleDiscipline.levelOneId", "3"],
            ["sam.responsibleDiscipline.levelTwoId", "3"],
            ["sam.responsibleDiscipline.nameDe", "Alcohol Interlock (AI):Alcohol Interlock (AI)"],
            ["sam.responsibleDiscipline.nameEn", "Alcohol Interlock (AI):Alcohol Interlock (AI)"],

            ["sam.certificationTopic.id", "3"],
            ["sam.certificationTopic.nameDe", "Alcohol Interlock (AI)"],
            ["sam.certificationTopic.nameEn", "Alcohol Interlock (AI)"],

            ["sam.creator", PID_USER],
            ["sam.approvalRequester", PID_USER],
            ["sam.approver", "MISHRAD"],

            ["sam.samType.id", "2"],
            ["sam.samType.nameDe", "Abgeleitet"],
            ["sam.samType.nameEn", "Derived"],

            ["sam.derivedFeature.ruleType.id", "12"],
            ["sam.derivedFeature.ruleType.nameDe", "Lokation"],
            ["sam.derivedFeature.ruleType.nameEn", "Location"],
            ["sam.derivedFeature.ruleType.abbreviation", "LOC"],
            ["sam.derivedFeature.ruleType.cluster.id", "6"],
            ["sam.derivedFeature.ruleType.cluster.nameDe", "Merkmalsübertragung Funktion"],
            ["sam.derivedFeature.ruleType.cluster.nameEn", "Feature transfer function"],

            ["sam.derivedFeature.explanation", "someExplanation"],
            ["sam.derivedFeature.fieldValues.condition.id", "1"],
            ["sam.derivedFeature.fieldValues.condition.nameDe", "Hauptmodul"],
            ["sam.derivedFeature.fieldValues.condition.nameEn", "Main module"],
            ["sam.derivedFeature.fieldValues.conditionValue", "someConditionValue"],
            ["sam.derivedFeature.fieldValues.applicationLayer.id", "1"],
            ["sam.derivedFeature.fieldValues.applicationLayer.nameDe", "Stücklistenteil (POSV)"],
            ["sam.derivedFeature.fieldValues.applicationLayer.nameEn", "BOM part (POSV)"],
            ["sam.derivedFeature.fieldValues.input1", "ASC.0001"],

            ["sam.unit.id", "36"],
            ["sam.unit.value", "A"],

            ["sam.featureDataTypeRegularExpression.id", "1"],
            ["sam.featureDataTypeRegularExpression.template", "1,23457E+12"],
            ["sam.featureDataTypeRegularExpression.value", "^[+-]?\\d{1,13}[,]?\\d{0,6}$"]
        ]);
        const schemaVersion = process.env.KAFKA_SAM_PROVIDER_SCHEMA_VERSION;
        expect(await validateAndVerifySamProvision(schemaVersion,messages, SAM_PROVISION_SCHEMA, fieldPairs)).toBe(true);
    });

    // Cleanup after the test is done
    test.afterEach(async () => {
        await kafkaService.disconnect();
    });

});