import {expect, test} from "@playwright/test";
import { goToUserSettings, saveAndVerifySuccessMessage, resetAndVerifySuccessMessage, selectFilterOption, selectFilterValue } from "./utils/testHelper";
import { goToSamDashBoard, navigateToBaseUrl } from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToUserSettings(page);
});

test.describe('User Settings Default Filters', () => {
    test('GIVEN user settings page - WHEN default filters section is visible - THEN it displays correctly', async ({page}) => {
        // Verify default filters section is present
        await expect(page.getByTestId('samViewFilter')).toBeVisible();
        
        // Verify default filters header/title
        await expect(page.getByText(/default filter|standardfilter/i)).toBeVisible();
    });

    test('GIVEN no default filters are selected - THEN empty state message is shown', async ({page}) => {
        // Initially no filters selected
        const filterChipsCount = await page.getByTestId('default-filter-container').locator('.MuiChip-root').count();
        
        expect(filterChipsCount).toBe(0);
    });

    test('GIVEN multiple default filters are selected - THEN all filters are displayed in the list', async ({page}) => {
        // Select multiple filters
        await selectFilterOption(page, 'filter-master-data-system', 'Data Source');
        await selectFilterValue(page, 'Data Source', 'CBC');
        
        await selectFilterOption(page, 'filter-change-status', 'Change Status');
        await selectFilterValue(page, 'Change Status', 'in Progress');
        
        await selectFilterOption(page, 'filter-approver', 'Approver');
        await selectFilterValue(page, 'Approver', 'MISHRAD');
    
        
        // Verify all filters are visible in the container
        await expect(page.getByTestId('default-filter-container').getByTestId('Data Source-selected-CBC')).toBeVisible();
        await expect(page.getByTestId('default-filter-container').getByTestId('Approver-selected-MISHRAD')).toBeVisible();
        await expect(page.getByTestId('default-filter-container').getByTestId('Change Status-selected-in Progress')).toBeVisible();
        
        // Count the filter chips
        const filterChipsCount = await page.getByTestId('default-filter-container').locator('.MuiChip-root').count();
        expect(filterChipsCount).toBeGreaterThanOrEqual(3);
        await expect(page.getByTestId('save-button')).toBeEnabled();
    });

    test('GIVEN a filter is selected - WHEN removing it - THEN it is removed from the list', async ({page}) => {
        // Select a filter
        await selectFilterOption(page, 'filter-unit', 'Unit');
        await selectFilterValue(page, 'Unit', 'bar');
        
        // Remove the filter by clicking the cancel icon
        await page.getByTestId('Unit-selected-bar').getByTestId('CancelIcon').click();
        
        // Verify filter is no longer visible
        await expect(page.getByTestId('default-filter-container').getByTestId('Unit-selected-bar')).not.toBeVisible();
    });

    test('GIVEN duplicate filter selection - WHEN same filter is selected twice - THEN it appears only once', async ({page}) => {
        // Select a filter
        await selectFilterOption(page, 'filter-antriebe', 'Antriebe');
        await selectFilterValue(page, 'Antriebe', 'CNG');
        
        // Try to select the same filter again
        await selectFilterOption(page, 'filter-antriebe', 'Antriebe');
        
        // Count the filter chips with same ID - should still be 1
        const antriebeChipCount = await page.getByTestId('default-filter-container')
            .locator('[data-testid="Antriebe-selected-CNG"]').count();
        expect(antriebeChipCount).toBe(1);
    });

    test('GIVEN default filters are selected and saved - WHEN page is reloaded - THEN filters persist', async ({page}) => {
        // Select filters
        await selectFilterOption(page, 'filter-sam-type', 'Sam Type');
        await selectFilterValue(page, 'Sam Type', 'Direct');
        
        // Save the changes
        await saveAndVerifySuccessMessage(page);
        
        // Reload the page
        await page.reload();
        
        // Navigate back to user settings
        await goToUserSettings(page);
        
        // Verify filters are still selected
        await expect(page.getByTestId('default-filter-container').getByTestId('Sam Type-selected-Direct')).toBeVisible();
        
        // Clean up - reset to original state
        await page.getByTestId('Sam Type-selected-Direct').getByTestId('CancelIcon').click();
        await saveAndVerifySuccessMessage(page);
    });

    test('GIVEN default filters are set - WHEN navigating to SAM dashboard - THEN selected filters are automatically applied', async ({page}) => {
        // Check if reset button is enabled, if yes reset all settings first
        const isResetEnabled = await page.getByTestId('reset-button').isEnabled();
        if (isResetEnabled) {
            await resetAndVerifySuccessMessage(page);
        }
        
        // Select default filters
        await selectFilterOption(page, 'filter-master-data-system', 'Data Source');
        await selectFilterValue(page, 'Data Source', 'CBC');
        
        await selectFilterOption(page, 'filter-unit', 'Unit');
        await selectFilterValue(page, 'Unit', 'bar');
        
        // Save the changes
        await saveAndVerifySuccessMessage(page);
        
        // Navigate to SAM dashboard
        await page.getByTestId('sidebar-sam-button').click();
        await expect(page).toHaveURL(/.*sam-dashboard/);
        
        // Verify the default filters are applied in the dashboard
        await expect(page.getByTestId('Data Source-selected-CBC')).toBeVisible();
        await expect(page.getByTestId('Unit-selected-bar')).toBeVisible();
        
        // Clean up - go back to user settings and remove the filters
        await goToUserSettings(page);
        await page.getByTestId('Data Source-selected-CBC').getByTestId('CancelIcon').click();
        await page.getByTestId('Unit-selected-bar').getByTestId('CancelIcon').click();
        await saveAndVerifySuccessMessage(page);
    });

    test('GIVEN user settings page - WHEN save button is disabled initially - THEN it enables after selecting a filter', async ({page}) => {
        // Verify save button is disabled initially (assuming no unsaved changes)
        const initialSaveButtonState = await page.getByTestId('save-button').isDisabled();
        
        // Select a filter
        await selectFilterOption(page, 'filter-unit', 'Unit');
        await selectFilterValue(page, 'Unit', 'bar');
        
        // Verify save button is now enabled
        await expect(page.getByTestId('save-button')).toBeEnabled();
    });

    test('GIVEN multiple Filter values selected - WHEN removing one chip - THEN only that value is removed', async ({page}) => {
         const isResetEnabled = await page.getByTestId('reset-button').isEnabled();
        if (isResetEnabled) {
            await resetAndVerifySuccessMessage(page);
        }
        
        // Select default filters
        await selectFilterOption(page, 'filter-master-data-system', 'Data Source');
        await selectFilterValue(page, 'Data Source', 'CBC');
        await selectFilterValue(page, 'Data Source', 'CERTUS');

        
        // Verify two chips are created
        const initialChipCount = await page.getByTestId('default-filter-container').locator('.MuiChip-root').count();
        expect(initialChipCount).toBe(2);
        
        // Remove the first chip
        await page.getByTestId('default-filter-container').locator('.MuiChip-root').first().getByTestId('CancelIcon').click();
        
        // Verify only one chip remains
        const finalChipCount = await page.getByTestId('default-filter-container').locator('.MuiChip-root').count();
        expect(finalChipCount).toBe(1);
    });
});
