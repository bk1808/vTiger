import {expect, test} from "@playwright/test";
import { goToSamDashBoard, navigateToBaseUrl } from "../utils/testHelper";
import { goToUserSettings, saveAndVerifySuccessMessage } from "./utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToUserSettings(page);
});

test.describe('User Settings Language Selection', () => {
    test('GIVEN German language is selected and saved - THEN the UI displays in German', async ({page}) => {
        // Select German language
        await page.getByRole('radio', { name: 'German' }).click();
        
        // Save the changes
        await saveAndVerifySuccessMessage(page);
        
        // Verify UI displays in German (check for German text in the page)
        await expect(page.getByText('Benutzereinstellungen')).toBeVisible(); // "User Settings" in German
        // Or verify the language radio button is checked
        await expect(page.getByRole('radio', { name: 'Deutsch' })).toBeChecked();
        
        // Reload page to verify language persists
        await page.reload();
        await expect(page.getByRole('radio', { name: 'Deutsch' })).toBeChecked();
    });

    test('GIVEN English language is selected and saved - THEN the UI displays in English', async ({page}) => {
        // Select English language
        await page.getByRole('radio', { name: 'Englisch' }).click();
        
        // Save the changes
        await saveAndVerifySuccessMessage(page, "DE");
        
        // Verify UI displays in English
        await expect(page.getByText('User Settings')).toBeVisible();
        // Or verify the language radio button is checked
        await expect(page.getByRole('radio', { name: 'English' })).toBeChecked();
        
        // Reload page to verify language persists
        await page.reload();
        await expect(page.getByRole('radio', { name: 'English' })).toBeChecked();
    });
});