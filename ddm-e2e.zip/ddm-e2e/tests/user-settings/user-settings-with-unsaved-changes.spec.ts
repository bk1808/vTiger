import {expect, test} from "@playwright/test";
import { SAM_FACTORY_DISCIPLINE_IDS } from "../utils/constants";
import { goToUserSettings, selectDisciplineDe } from "./utils/testHelper";
import { goToSamDashBoard, navigateToBaseUrl } from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToUserSettings(page);
});

test.describe('User Settings with Unsaved Changes', () => {
    test('GIVEN unsaved changes exist - WHEN user navigates away - THEN confirmation dialog appears and user can stay on page', async ({page}) => {
        // Make changes to settings without saving
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        
        // Verify discipline is selected
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
        
        // Attempt to navigate to another page
        await page.getByTestId('sidebar-sam-button').click();
        
        // Wait for confirmation dialog to appear
        await expect(page.getByTestId('confirmation-dialog-title')).toBeVisible();
        await expect(page.getByTestId('confirmation-dialog-content')).toContainText(/unsaved changes|leave|discard/i);
        
        // Click Cancel to stay on page
        await page.getByTestId('confirmation-dialog-left-button').click(); // Cancel button
        
        // Verify user is still on the settings page
        await expect(page).toHaveURL(/user-settings/);
        
        // Verify changes are still present
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
    });

    test('GIVEN unsaved changes exist - WHEN user confirms navigation - THEN changes are lost and user navigates away', async ({page}) => {
        // Make changes to settings without saving
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        
        // Verify discipline is selected
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
        
        // Attempt to navigate to another page
        await page.getByTestId('sidebar-sam-button').click();
        
        // Wait for confirmation dialog to appear
        await expect(page.getByTestId('confirmation-dialog-title')).toBeVisible();
        
        // Click Leave to navigate away
        await page.getByTestId('confirmation-dialog-right-button').click(); // Leave button
        
        // Verify user has navigated to the new page
        await expect(page).toHaveURL(/.*sam-dashboard/);
        
        // Navigate back to settings
        await goToUserSettings(page);
        
        // Verify changes were not saved (original values are shown)
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).not.toBeVisible();
    });

    test('GIVEN unsaved changes exist - WHEN user reloads page - THEN confirmation dialog appears and user can cancel reload', async ({page}) => {
        // Make changes to settings without saving
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        
        // Verify discipline is selected
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
        
        // Set up dialog handler BEFORE attempting reload
        page.once('dialog', async dialog => {
            expect(dialog.type()).toBe('beforeunload');
            await dialog.dismiss(); // User chooses to cancel reload
        });
        
        // Trigger reload (this will show the beforeunload dialog)
        await page.evaluate(() => location.reload());
        
        // Wait a moment to ensure dialog was handled
        await page.waitForTimeout(1000);
        
        // Verify user is still on the settings page with unsaved changes
        await expect(page).toHaveURL(/user-settings/);
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
    });
});