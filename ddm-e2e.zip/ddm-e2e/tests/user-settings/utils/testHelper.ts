import { Page } from "playwright";
import {expect} from "@playwright/test";

export async function goToUserSettings(page: Page) {
    // Click profile menu icon to open the menu
    await page.getByTestId('profile-menu-icon').click();
    
    // Click on "User Settings" menu item
    await page.getByRole('menuitem', { name: /user settings/i }).click();
    
    // Redirecting to the "User Settings" view
    await expect(page).toHaveURL(/.*user-settings/);
    await expect(page.getByTestId('user-settings-view')).toBeVisible();
}

export async function selectDisciplineDe(page: Page, discipline: string) {
    await page.getByTestId('disciplineId-de').click();
    await page.getByTestId(discipline).first().click();
}

export async function selectDisciplineEn(page: Page, discipline: string) {
    await page.getByTestId('disciplineId-en').click();
    await page.getByTestId(discipline).first().click();
}

export async function countDisciplinesSelected(page: Page, disciplineId: string) {
    return await page.getByTestId('favorite-disciplines-container').locator(`[data-testid^="discipline-chip-${disciplineId}"]`).count();
    
}

export async function saveAndVerifySuccessMessage(page: Page,language: string="EN") {
    await page.getByTestId('save-button').click();
    if(language==="DE") {
        await expect(page.getByTestId('confirmation-dialog-title')).toHaveText('Speichern bestätigen');
    } else {
        await expect(page.getByTestId('confirmation-dialog-title')).toHaveText('Confirm Save');
    }
    
    await page.getByTestId('confirmation-dialog-right-button').click();
    await expect(page.getByText(/success|saved|gespeichert/i)).toBeVisible();
}

export async function resetAndVerifySuccessMessage(page: Page,language: string="EN") {
    await page.getByTestId('reset-button').click();
    if(language==="DE") {
        await expect(page.getByTestId('confirmation-dialog-title')).toHaveText('Zurücksetzen bestätigen');
    } else {
        await expect(page.getByTestId('confirmation-dialog-title')).toHaveText('Confirm Reset');
    }
    await page.getByTestId('confirmation-dialog-right-button').click();
    
    // Wait for success message - try common success message patterns
    await expect(page.locator('text=/reset.*success|settings.*reset|zurückgesetzt|successfully/i').first()).toBeVisible({timeout: 10000});
}

export async function selectFilterOption(page: Page, filterOptionTestId: string, filterInputTestId: string) {
    // Open the default filters dropdown
    await page.getByTestId('samViewFilter').click();
    
    // Select a filter option (e.g., "Data Source")
    await page.getByTestId(filterOptionTestId).click();
    
    // Verify the filter input appears in the selected filters container
    await expect(page.getByTestId('default-filter-container').getByTestId(filterInputTestId)).toBeVisible();
}

export async function selectFilterValue(page: Page, filterInputTestId: string, optionToSelect: string) {
    // Click on the autocomplete input to open dropdown
    await page.getByTestId(filterInputTestId).locator('input').click();
    
    // Wait for dropdown options to appear
    await page.waitForSelector('[role="option"]', { timeout: 5000 });
    
    // Select the specified option by text
    await page.getByRole('option', { name: optionToSelect }).click();
    
    // Verify the specific chip is created with the pattern: {filterInputTestId}-selected-{optionText}
    // Example: "Data Source-selected-CBC"
    const chipTestId = `${filterInputTestId}-selected-${optionToSelect}`;
    await expect(page.getByTestId(chipTestId)).toBeVisible();
}