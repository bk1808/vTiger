import {expect,test} from "@playwright/test";
import { SAM_FACTORY_DISCIPLINE_IDS } from "../utils/constants";
import { goToUserSettings, resetAndVerifySuccessMessage, saveAndVerifySuccessMessage, selectDisciplineDe, selectDisciplineEn } from "./utils/testHelper";
import { goToSamDashBoard, navigateToBaseUrl } from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToUserSettings(page);
});

test.describe('User Settings Save and Reset', () => {
    test('GIVEN user settings page - WHEN user makes changes, saves, resets - THEN all button states and persistence work correctly', async ({page}) => {
        // STEP 1: Verify initial state - buttons are disabled when no changes
        await expect(page.getByTestId('save-button')).toBeDisabled();
        
        // STEP 2: Make a change - buttons become enabled
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
        
        // Verify Save button is enabled after changes
        await expect(page.getByTestId('save-button')).toBeEnabled();
        
        // STEP 3: Save changes
        await saveAndVerifySuccessMessage(page);
        
        // STEP 4: Verify persistence after reload
        await page.reload();
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
        
        // STEP 5: Make additional changes
        await selectDisciplineEn(page, SAM_FACTORY_DISCIPLINE_IDS.DOOR_LOCKS_AND_HINGES);
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-55')).toBeVisible();
        
        // Verify buttons are enabled after new changes
        await expect(page.getByTestId('save-button')).toBeEnabled();
        await expect(page.getByTestId('reset-button')).toBeEnabled();
        
        // STEP 6: Reset changes to previous saved state
        await resetAndVerifySuccessMessage(page);
        
        
        // Since changes are not saved after second discipline selected, When reset hit it will remove both discipline.
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).not.toBeVisible();
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-55')).not.toBeVisible();
        
        // STEP 7: Verify buttons are disabled after reset (no unsaved changes)
        await expect(page.getByTestId('save-button')).toBeDisabled();
        await expect(page.getByTestId('reset-button')).toBeDisabled();
    });
});