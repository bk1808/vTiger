import {expect, test} from "@playwright/test";
import { SAM_FACTORY_DISCIPLINE_IDS } from "../utils/constants";
import { countDisciplinesSelected, goToUserSettings, resetAndVerifySuccessMessage, saveAndVerifySuccessMessage, selectDisciplineDe,selectDisciplineEn } from "./utils/testHelper";
import { goToSamDashBoard, navigateToBaseUrl } from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToUserSettings(page);
});

test.describe('User Settings Favorite Discipline Selection', () => {
    test('GIVEN disciplines are selected and managed - THEN the selected list updates correctly', async ({page}) => {
        // Select discipline in German dropdown
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        // Verify it appears in the selected list on the right
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).toBeVisible();
        
        // Select discipline in English dropdown
        await selectDisciplineEn(page, SAM_FACTORY_DISCIPLINE_IDS.DOOR_LOCKS_AND_HINGES);
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-55')).toBeVisible();
        
        // Attempt to select duplicate discipline
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        // Verify it is not added twice to the list (count should still be 1)
        expect(await countDisciplinesSelected(page, "3")).toBe(1);
        
        // Remove a discipline from the selected list
        await page.getByTestId('discipline-chip-3').getByTestId('CancelIcon').click();
        
        // Verify it no longer appears on the right
        await expect(page.getByTestId('favorite-disciplines-container').getByTestId('discipline-chip-3')).not.toBeVisible();
        const disciplineCount = await countDisciplinesSelected(page, "");
        expect(disciplineCount).toBe(1);

        // Verify "No disciplines selected" message appears if all are removed
        await page.getByTestId('discipline-chip-55').getByTestId('CancelIcon').click();
        await expect(page.getByText('No disciplines selected')).toBeVisible();

    });

    test('GIVEN multiple favorite disciplines are selected - WHEN save button is clicked - THEN success message appears', async ({page}) => {
        // Select multiple disciplines
        await selectDisciplineDe(page, SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
        await selectDisciplineEn(page, SAM_FACTORY_DISCIPLINE_IDS.DOOR_LOCKS_AND_HINGES);
        
        // Verify all disciplines are selected
        const chipCount = await page.getByTestId('favorite-disciplines-container').locator('.MuiChip-root').count();
        expect(chipCount).toBe(2);
        
        // Click save button and verify success message
        await saveAndVerifySuccessMessage(page);

        // Wait for success message to disappear
        await expect(page.getByText(/success|saved|gespeichert/i)).not.toBeVisible();

        //reseting to initial state
        await resetAndVerifySuccessMessage(page);
        await expect(page.getByText('No disciplines selected')).toBeVisible();
    });
});
