import {expect, Page, test} from "@playwright/test";
import {
    goToMySAMs, goToSamCreateAndFillAllMandatoryFieldsAndSave, goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl,
    useSamDashboardFilterMultiInput
} from "../utils/testHelper";
import {format} from "date-fns";
import {selectByRoleAndDataFieldAndColIndex} from "../utils/selector";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
});

test.describe('Bulk Change', () => {
    test('GIVEN filtered SAMs  - THEN SAMs are editable in Bulk Change Modal' , async ({page}) => {
        const samNameOne: string = 'Bulk:ChangeOne';
        const samNameTwo: string = 'Bulk:ChangeTwo';

        await filterTwoSamsInDashboard(page, samNameOne, samNameTwo);

        await page.getByTestId('bulk-change-button').click();

        await inBulkChangeModalPageOneSelectFirstAndSecondSam(page);

        await page.getByTestId('next-button').click();

        await inBulkChangeModalPageTwoFillKguenAsAttribute(page);

        await inBulkChangeModalPageTwoFillOutChangeBlock(page);

        await page.getByTestId('approver').click();
        await page.getByTestId('approver-value-MISHRAD').click();

        await page.getByTestId('next-button').click();
        await expect(page.getByText('Your bulk change request has been successfully transmitted. You will receive an email about the status of the process.')).toBeVisible();

        await page.getByTestId('next-button').click();
        await expect(page).toHaveURL(/.*sam-dashboard/);
    });

    test('GIVEN My Observed SAM  - THEN Observed SAM is visible  in Bulk Change Modal' , async ({page}) => {
        const samName: string = 'Bulk:ChangeOne';
        await useSamDashboardFilterMultiInput(page, {
            filterToSelect: "filter-name-en",
            filterInputId: "SAM Name (EN)-input",
            input: samName,
        });

        await goToDetailViewOfSamAndObserveSam();

        await deleteSamNameFilterAndActivateMyObservedSamsFilter();

        await verifyThatSamIsVisibleInBulkChangeModal();

        async function goToDetailViewOfSamAndObserveSam() {
            await page.getByTestId(`sam-revision-data-table-data-row-0`).click();
            await expect(page).toHaveURL(/.*sam-detail/);
            await page.getByTestId('observe-sam-checkbox').click();
            await expect(page.getByTestId('observe-sam-checkbox').locator('input')).toBeChecked();
            await goToSamDashBoard(page);
        }

        async function deleteSamNameFilterAndActivateMyObservedSamsFilter() {
            await page.getByTestId('SAM Name (EN)-container').getByTestId('CancelIcon').click();
            await page.getByTestId('my-observed-sams-button').click();
        }

        async function verifyThatSamIsVisibleInBulkChangeModal() {
            await page.getByTestId('bulk-change-button').click();
            const selectorForSamNameCell = selectByRoleAndDataFieldAndColIndex(page, 'td', 'samNameEn', 2);
            await expect(page.getByTestId('bulk-change-modal-data-row-0').locator(selectorForSamNameCell)).toHaveText(samName);
        }
    });

    test('GIVEN My SAM  - THEN My SAM is visible in Bulk Change Modal' , async ({page}) => {
        const samName: string = 'BulkChange:MySAM';
        await goToSamCreateForm(page);
        await goToSamCreateAndFillAllMandatoryFieldsAndSave(page, samName);

        await goToSamDashBoard(page);
        await goToMySAMs(page);

        await page.getByTestId('bulk-change-button').click();
        await expect(page.getByText(samName).nth(3)).toBeVisible();
    });

    async function inBulkChangeModalPageOneSelectFirstAndSecondSam(page: Page) {
        const firstSamCheckboxInputSelector = page.getByTestId('bulk-change-modal-data-row-0').locator('input');
        await expect(firstSamCheckboxInputSelector).not.toBeChecked();
        await firstSamCheckboxInputSelector.click();
        await expect(firstSamCheckboxInputSelector).toBeChecked();

        const secondSamCheckboxSelector = page.getByTestId('bulk-change-modal-data-row-1').locator('input');
        await expect(secondSamCheckboxSelector).not.toBeChecked();
        await secondSamCheckboxSelector.click();
        await expect(secondSamCheckboxSelector).toBeChecked();
    }

    async function filterTwoSamsInDashboard(page: Page, samNameOne: string, samNameTwo: string) {
        await useSamDashboardFilterMultiInput(page, {
            filterToSelect: "filter-name-en",
            filterInputId: "SAM Name (EN)-input",
            input: samNameOne,
        });

        await useSamDashboardFilterMultiInput(page, {
            filterToSelect: "filter-name-en",
            filterInputId: "SAM Name (EN)-input",
            input: samNameTwo,
        });
    }

    async function inBulkChangeModalPageTwoFillKguenAsAttribute(page: Page) {
        await page.getByTestId('bulkChangeAttributeNameEn').click();
        await page.getByTestId('attribute-value-KGU-EN').click();
        await page.getByTestId('kguens').click();
        await page.getByTestId('kguens').locator('div > input').fill('000-00');
        await page.getByTestId('000-00').click();
    }

    async function inBulkChangeModalPageTwoFillOutChangeBlock(page: Page) {
        await page.getByTestId('summary').locator('div > textarea').first().fill("bulk change summary");

        const currentDate = new Date();
        const inputDate = new Date(currentDate.getFullYear() + 1, currentDate.getMonth(), currentDate.getDay());
        await page.getByTestId('create-sam-date-picker').click();
        await page.getByTestId('create-sam-date-picker').fill(format(inputDate, 'dd/MM/yyyy'));
        await page.getByTestId('create-sam-date-picker').press('Enter');

        await page.getByTestId('explanation').fill("bulk change explanation");
    }
});