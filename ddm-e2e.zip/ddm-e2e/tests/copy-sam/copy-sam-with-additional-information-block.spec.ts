import {expect, test} from "@playwright/test";
import {Messages} from "../create-sam/utils/messages";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import { SAM_FACTORY_CERTIFICATION_MARKET_IDS, SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "../utils/constants";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Copy SAM With Additional Information Block', () => {
    test('GIVEN a SAM is copied With Supplemental Information, Free attribute and Certification Market- THEN the fields are filled correctly', async ({page}) => {
        // Filter for SAM ID = ASC.0008
        await navigateToSam(page, "ASC.0008");

        // Go to SAM Detail page of SAM
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Copy SAM button
        await page.getByTestId("copy-sam-button").click();
        await expect(page).toHaveURL(/.*sam-create/);

        // Write values in empty fields
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
            targetDate: getSameDateInNextYear(),
            summary: 'Copy SAM summary',
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_WITH_ADDITIONAL_INFO_BLOCK',
            nameEn: 'SAM:COPY_WITH_ADDITIONAL_INFO_BLOCK',
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn',
            freeAttributeDe: 'freeAttributeDe',
            freeAttributeEn: 'freeAttributeEn',
            certificationMarketDe:SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_DE
        });

        // Submit & Verify in Detail View and in History View
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            summary: 'Copy SAM summary',
            targetDate: getSameDateInNextYear(),
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_WITH_ADDITIONAL_INFO_BLOCK',
            nameEn: 'SAM:COPY_WITH_ADDITIONAL_INFO_BLOCK',
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn',
            freeAttributeDe: 'freeAttributeDe',
            freeAttributeEn: 'freeAttributeEn',
            certificationMarketDe: 'Indien',
            certificationMarketEn: 'India',
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            summary: 'Copy SAM summary',
            targetDate: getSameDateInNextYear(),
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_WITH_ADDITIONAL_INFO_BLOCK',
            nameEn: 'SAM:COPY_WITH_ADDITIONAL_INFO_BLOCK',
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn',
            freeAttributeDe: 'freeAttributeDe',
            freeAttributeEn: 'freeAttributeEn',
            certificationMarketDe: 'Indien',
            certificationMarketEn: 'India',
        })
    });
});