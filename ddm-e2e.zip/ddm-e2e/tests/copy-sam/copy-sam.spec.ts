import {expect, test} from "@playwright/test";
import {Messages} from "../create-sam/utils/messages";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Copy SAM', () => {
    test('GIVEN a SAM is copied - THEN the required fields are validated and filled correctly', async ({page}) => {
        // Filter for SAM ID = ASC.0008
        await navigateToSam(page, "ASC.0008");

        // Go to SAM Detail page of SAM
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Copy SAM button
        await page.getByTestId("copy-sam-button").click();
        await expect(page).toHaveURL(/.*sam-create/);

        // Trigger SAM Submit so that empty Change Block and Sam Name values appear to be required
        await page.getByTestId('submit-button').click();

        await verifyIsEditableAndHasRedColorById(page, 'summary');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.SUMMARY_IS_EMPTY_ERROR);

        await expect(page.getByTestId('create-sam-date-picker')).toBeEditable();
        await verifyIsVisibleAndHasRedColorByText(page, Messages.TARGET_DATE_REQUIRED);

        await expect(page.getByTestId('explanation')).toBeEditable()
        await verifyIsVisibleAndHasRedColorByText(page, Messages.EXPLANATION_IS_EMPTY_ERROR);

        await verifyIsEditableAndHasRedColorById(page, 'nameDe');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);
        await verifyIsEditableAndHasRedColorById(page, 'nameEn');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);

        // Write values in empty fields
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            targetDate: getSameDateInNextYear(),
            summary: 'Copy SAM summary',
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_MANDATORY',
            nameEn: 'SAM:COPY_MANDATORY'
        });

        // Submit & Verify in Detail View and in History View
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            summary: 'Copy SAM summary',
            targetDate: getSameDateInNextYear(),
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_MANDATORY',
            nameEn: 'SAM:COPY_MANDATORY'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            summary: 'Copy SAM summary',
            targetDate: getSameDateInNextYear(),
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_MANDATORY',
            nameEn: 'SAM:COPY_MANDATORY'
        })
    });
});