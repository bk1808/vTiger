import {expect, test} from "@playwright/test";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import { SAM_FACTORY_ANTRIEBE_IDS, SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "../utils/constants";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Copy SAM With ISTDaWo Data Source and Antriebe type', () => {
    test('GIVEN a SAM is copied With ISTDaWo Data Source- THEN the antriebe field is filled correctly', async ({page}) => {
        // Filter for SAM ID = ASC.0008
        await navigateToSam(page, "ASC.0008");

        // Go to SAM Detail page of SAM
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Copy SAM button
        await page.getByTestId("copy-sam-button").click();
        await expect(page).toHaveURL(/.*sam-create/);

        // Write values in empty fields
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.ISTDAWO,
            targetDate: getSameDateInNextYear(),
            summary: 'Copy SAM summary',
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_WITH_ISTDaWo',
            nameEn: 'SAM:COPY_WITH_ISTDaWo',
            antriebe:SAM_FACTORY_ANTRIEBE_IDS.DIESEL
        });

        // Submit & Verify in Detail View and in History View
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            summary: 'Copy SAM summary',
            targetDate: getSameDateInNextYear(),
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_WITH_ISTDaWo',
            nameEn: 'SAM:COPY_WITH_ISTDaWo',
            antriebe: 'Diesel'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            summary: 'Copy SAM summary',
            targetDate: getSameDateInNextYear(),
            explanation: 'Copy SAM explanation',
            nameDe: 'SAM:COPY_WITH_ISTDaWo',
            nameEn: 'SAM:COPY_WITH_ISTDaWo',
            antriebe: 'Diesel'
        })
    });
});