import {expect, test} from "@playwright/test";
import {
    goToMyObservedSAMs, goToSamCreateAndFillAllMandatoryFieldsAndSave,
    goToSamDashBoard,
    navigateToBaseUrl, navigateToSam,
} from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('My Observed SAMs', () => {
    test('GIVEN unobserved SAM  - THEN SAM is observed in Detail View', async ({page}) => {
        const samName: string = 'My:ObservedSAM'
        await goToSamCreateAndFillAllMandatoryFieldsAndSave(page, samName);

        await navigateToSam(page, 'ALI.0001');
        await page.getByTestId('observe-sam-checkbox').click();

        await goToSamDashBoard(page);
        await goToMyObservedSAMs(page);
        await page.getByText('ALI.0001').nth(1).click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await expect(page.getByTestId('observe-sam-checkbox').locator('input')).toBeChecked();

        await page.getByTestId('observe-sam-checkbox').click();
        await expect(page.getByTestId('observe-sam-checkbox').locator('input')).not.toBeChecked();

        await goToSamDashBoard(page);
        await expect(page.getByTestId('my-observed-sams-button').locator('input')).toBeChecked();
        await expect(page.getByText(samName)).not.toBeVisible();
    });
});