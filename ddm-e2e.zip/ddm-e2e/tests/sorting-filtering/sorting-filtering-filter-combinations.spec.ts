import {expect, Page, test} from "@playwright/test";
import {selectTableRowByRoleAndDataFieldAndColAndRowIndex} from "../utils/selector";
import {navigateToBaseUrl} from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSamDashboard(page);
});

test.describe('Sorting and Filtering SAM Filter Combinations', () => {
    test('Filter sorting SAMS', async ({page}) => {
        // upward sort of SAM name German
        await page.waitForSelector('[data-testid="sam-view-filter"]');
        await page.getByText('SAM Name (DE)').click();
        const nameDeFirstRow = selectTableRowByRoleAndDataFieldAndColAndRowIndex(page, "td", "samNameDe", 2, 0);
        await expect(nameDeFirstRow).toHaveText('Abgasanlage: Darstellung Sachnummer <A-Snr>');
     });

    test('Pagination', async ({page}) => {
        await page.getByTestId('sidebar-sam-button').click();
        // Open Pagination area
        await page.locator('.MuiTablePagination-actions').click();
        // 50 Rows per page is the default value
        await page.getByLabel('50').click();
        // cannot be selected beacuse hidden: await page.getByTestId('ArrowDropDownIcon').focus();
        // Selecting 100 rows per page
        await page.getByRole('option', { name: '100' }).click();
        await page.getByLabel('100').click();
        // Selecting 500 rows per page
        await page.getByRole('option', { name: '500' }).click();
        await page.getByLabel('500').click();
        // The SAM Overview page shows the number of SAMs currently displayed and the total number of SAMs currently available.
        // In the format "1-XX of XX". This number depends on the selected quantity to be displayed per page.
        expect(page.getByText('1-21 of 21')).toBeDefined();
        // Click on the right arrow to redirect to other table pages
        // First selecting 100 rows per page
        await page.getByRole('option', { name: '100' }).click();
        await page.getByLabel('100').click();
        // Click on the right arrow to redirect to next page
        await page.getByTestId('KeyboardArrowRightIcon').focus();
        await page.getByTestId('KeyboardArrowRightIcon').dispatchEvent('click');
        // Click on the left arrow to redirect to previous page
        await page.getByTestId('KeyboardArrowLeftIcon').focus();
        await page.getByTestId('KeyboardArrowLeftIcon').dispatchEvent('click');
    });

    test('Combination of filtering options', async ({page}) => {
        //  Data Source 'Smaragd'
        await page.getByTestId('sam-view-filter').click();
        await page.getByTestId('filter-master-data-system').click();
        await page.getByTestId('Data Source').click();
        await page.getByTestId('Data Source').locator('div > input').type('Smaragd');
        await page.getByTestId('Data Source').locator('div > input').press('Enter');
        // Filtering of Discipline_DE 'Airbag'
        await page.getByTestId('sam-view-filter').click();
        await page.getByTestId('filter-discipline-de').click();
        await page.getByTestId('Level 1 : Level 2 Discipline (DE)').click();
        await page.getByTestId('Level 1 : Level 2 Discipline (DE)').locator('div > input').type('Airbag');
        await page.getByTestId('Level 1 : Level 2 Discipline (DE)').locator('div > input').press('Enter');
        // Filtering of Change Status 'closed'
        await page.getByTestId('sam-view-filter').click();
        await page.getByTestId('filter-change-status').click();
        await page.getByTestId('Change Status').click();
        await page.getByTestId('Change Status').locator('div > input').type('closed');
        await page.getByTestId('Change Status').locator('div > input').press('Enter');
        // Open Pagination area
        await page.locator('.MuiTablePagination-actions').click();
        // 6 SAMS is the result of this filter combination
        expect(page.getByText('1-5 of 6')).toBeDefined();
    });

});

async function navigateToSamDashboard(page: Page) {
    // Select "SAM" from the left menu bar
    await page.getByTestId('sidebar-sam-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*sam-dashboard/);
    await expect(page.getByTestId('sam-view')).toBeVisible();
}
