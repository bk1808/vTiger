import {expect, test} from "@playwright/test";
import {
    goToApprover,
    goToCreator,
    goToMySAMs, goToRequester, goToSamCreateAndFillAllMandatoryFieldsAndSave,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl, verifyCreatorRequesterApprover
} from "../utils/testHelper";
import {PID_USER} from "@root/tests/utils/constants";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('My SAMs filter', () => {
    test('GIVEN SAM with requester ID equal to current user - THEN SAM appears in My SAMs', async ({page}) => {
        const samIDNameCurrentUserAsRequester: string = 'CRA.0447'

        await goToSamDashBoard(page);
        await goToMySAMs(page);
        await goToCreator(page);

        await page.getByText(samIDNameCurrentUserAsRequester).first().click();

        await expect(page).toHaveURL(/.*sam-detail/);

        await verifyCreatorRequesterApprover(page, " ", PID_USER, " ");
    });

    test('GIVEN SAM with approver ID equal to current user - THEN SAM appears in My SAMs', async ({page}) => {
        const samIDNameCurrentUserAsApprover: string = 'CRA.0448'

        await goToSamDashBoard(page);
        await goToMySAMs(page);
        await goToCreator(page)
        await goToRequester(page)
        await goToApprover(page);

        await page.getByText(samIDNameCurrentUserAsApprover).first().click();

        await expect(page).toHaveURL(/.*sam-detail/);

        await verifyCreatorRequesterApprover(page, " ", " ", PID_USER);
    });

    test('GIVEN created SAM - THEN SAM appears in My SAMs', async ({page}) => {
        const samName: string = 'My:SAMs'
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);
        await goToSamCreateAndFillAllMandatoryFieldsAndSave(page, samName);

        await goToSamDashBoard(page);
        await goToMySAMs(page);
        await goToRequester(page)

        await page.getByText(samName).first().click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifyCreatorRequesterApprover(page, PID_USER, " ", " ");
    });

    test("GIVEN filter is applied and mySAMs is toggled - THEN SAMs with creator and requestor as current user should appear", async ({page}) => {
        await goToSamDashBoard(page);

        const samName = 'SAB.0001';
        // Filtering of Discipline_DE 'Airbag'
        await page.getByTestId('sam-view-filter').click();
        await page.getByTestId('filter-discipline-de').click();
        await page.getByTestId('Level 1 : Level 2 Discipline (DE)').click();
        await page.getByTestId('Level 1 : Level 2 Discipline (DE)').locator('div > input').type('Airbag');
        await page.getByTestId('Level 1 : Level 2 Discipline (DE)').locator('div > input').press('Enter');
        await page.getByTestId('Airbag: Airbag').click()

        const dataRow = page.getByText(samName)
        await expect(dataRow).toBeVisible()

        await goToMySAMs(page);

        await expect(dataRow).not.toBeVisible()
    })
});