import {expect, Page, test} from "@playwright/test";
import {
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl, setRowsPerPage, waitForSamStatus
} from "../utils/testHelper";
import {
    CHANGE_STATUS_CLOSED,
    PID_USER,
    SAM_FACTORY_ANTRIEBE_IDS,
    SAM_FACTORY_CERTIFICATION_MARKET_IDS,
    SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS,
    SAM_FACTORY_CERTUS_FUNCTION_IDS,
    SAM_FACTORY_CERTUS_MARKET_IDS,
    SAM_FACTORY_CERTUS_TOPIC_IDS,
    SAM_FACTORY_CERTUS_TYPE_IDS,
    SAM_FACTORY_DATA_TYPE_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_SYSTEM_NAME_IDS, SAM_STATUS_ACTIVE,
    STATUS_IN_REVIEW,
    STATUS_NEW
} from "../utils/constants";
import {INPUT} from "../utils/locators";
import {filterWithoutHavingOwnColumnInSamDashboard, filterWithOwnColumnInSamDashboard} from "@root/tests/sorting-filtering/utils/filtering-common-validation";
import {RowConstants} from "@root/tests/sorting-filtering/utils/constants";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";

async function createSamForUnitFilter(page: Page) {
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        nameDe: "Test:UnitFilter",
        samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
        featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
        unit: "unit-1/min",
        featureDataTypeRegularExpression: "featureDataTypeRegularExpression-1,23457E+12",
    });

    // Submit Data
    await page.getByTestId('submit-button').click();
    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);
    await goToSamDashBoard(page);
}

async function createSamForCertificationMarketFilter(page: Page) {
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        nameDe: "Test:CertificationFilter",
        samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
        certificationMarketDe: SAM_FACTORY_CERTIFICATION_MARKET_IDS.KOREA_DE,
    });

    // Submit Data
    await page.getByTestId('submit-button').click();

    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);

    await goToSamDashBoard(page);
}

async function createSamForAntriebeFilter(page: Page) {
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        nameDe: "Test:AntriebeFilter",
        samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.ISTDAWO,
        antriebe:SAM_FACTORY_ANTRIEBE_IDS.MILD_OR_FULL_HYBRID_DIESEL
    });

    // Submit Data
    await page.getByTestId('submit-button').click();

    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);

    await goToSamDashBoard(page);
}

async function createSamForCertusFilter(page: Page) {
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        nameDe: "Test:CertusFilter",
        samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
        certusMarket: SAM_FACTORY_CERTUS_MARKET_IDS.EU,
        certusCertificateTopic: SAM_FACTORY_CERTUS_TOPIC_IDS.LIGHTING,
        certusCertificateType: SAM_FACTORY_CERTUS_TYPE_IDS.TYPE_APPROVAL,
        certusAdditionalSpecification: SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS.CERTIFICATES,
        certusFunction: SAM_FACTORY_CERTUS_FUNCTION_IDS.CERTIFICATES
    });

    // Submit Data
    await page.getByTestId('submit-button').click();

    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);

    await goToSamDashBoard(page);
}

async function createSamForCreatorApproverRequesterFilter(page: Page){
    // Go to SamCreate view
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);

    // Fill everything needed
    await fillSamFactoryFields(page, {
        fillMandatoryFieldsAutomatically: true,
        nameDe: "Test:CreatorApproverRequesterFilter",
        nameEn: "Test:CreatorApproverRequesterFilter",
    });

    // Submit Data
    await page.getByTestId('submit-button').click();

    // Expect Sam Detail View after create sam
    await expect(page).toHaveURL(/.*sam-detail/);

    // set Sam to in review with MISHRAD as approver
    await page.getByTestId('Common.InReview').click();
    await page.getByRole('combobox', {name: 'Approver'}).fill("Devesh Mishra - [MISHRAD]");
    await page.getByTestId('approver-value-MISHRAD').click();
    await page.getByTestId('input-dialog-confirm-button').click();

    // wait for CA to approve
    await expect(page.getByText('Approval Request successfully sent to Central Approval')).toBeVisible();
    await expect(page).toHaveURL(/.*sam-detail/);
    await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue(STATUS_NEW);
    await page.reload();
    await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue(STATUS_IN_REVIEW);
    await expect(page.getByTestId('detail-view-approval-requester').locator('input')).toHaveValue(PID_USER);
    const conditionsMet = await waitForSamStatus(page, SAM_STATUS_ACTIVE, CHANGE_STATUS_CLOSED);
    expect(conditionsMet).toBe(true);

    await goToSamDashBoard(page);
}

test.beforeEach(async ({ page }) => {
    await navigateToBaseUrl(page);
    await navigateToSamDashboard(page);
    await setRowsPerPage(page, 500);
});


test.describe('Sorting and Filtering SAM Overview', () => {
    test('WHEN SamID filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-feature-id',
            'SAM ID',
            'SRM.0002',
            RowConstants.SAM_ID,
            true,
            ' '
        );
    });

    test('WHEN SamNameDe filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-name-de',
            'SAM Name (DE)',
            'Spiegel',
            RowConstants.SAM_NAME_DE,
            false,
            ' '
        );
    });


    test('WHEN SamNameEn filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-name-en',
            'SAM Name (EN)',
            'mirror',
            RowConstants.SAM_NAME_EN,
            false,
            ' '
        );
    });

    test('WHEN additional information (German) filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-supplemental-information-de',
            'Additional Information (DE)',
            'Pilot-CCD',
            RowConstants.ADDITIONAL_INFORMATION_DE,
            false,
            ' '
        );
    });

    test('WHEN Additional Information (English) filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-supplemental-information-en',
            'Additional Information (EN)',
            'Pilot-CCD',
            RowConstants.ADDITIONAL_INFORMATION_EN,
            false,
            ' '
        );
    });

    test('WHEN Free Attribute (German) filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-free-attribute-de',
            'Free Attribute (DE)',
            'free attribute de',
            RowConstants.FREE_ATTRIBUTE_DE,
            false,
            ' '
        );
    });

    test('WHEN Free Attribute (English) filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-free-attribute-en',
            'Free Attribute (EN)',
            'free attribute en',
            RowConstants.FREE_ATTRIBUTE_EN,
            false,
            ' '
        );
    });

    test('WHEN notes for expression filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-notes-on-default-value',
            'Notes for Expression',
            'tandem',
            RowConstants.NOTES_FOR_EXPRESSION,
            false,
            ' '
        );
    });

    test('WHEN default value filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-default-value',
            'Expression',
            'EB',
            RowConstants.EXPRESSION,
            false,
            ' '
        );
    });


    test('WHEN discipline (German) filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-discipline-de',
            'Level 1 : Level 2 Discipline (DE)',
            'Airbag: Airbag',
            RowConstants.DISCIPLINE_DE,
            true,
            'xy'
        );
    });

    test('WHEN discipline (English) filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-discipline-en',
            'Level 1 : Level 2 Discipline (EN)',
            'Airbag: Airbag',
            RowConstants.DISCIPLINE_EN,
            true,
            'YYY'
        );
    });

    test('WHEN data source filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-master-data-system',
            'Data Source',
            'CBC',
            RowConstants.DATA_SOURCE,
            true,
            'YYY'
        );
    });

    test('WHEN change status filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-change-status',
            'Change Status',
            'in Review',
            RowConstants.CHANGE_STATUS,
            true,
            'YYY'
        );
    });


    test('WHEN data type filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-feature-data-type',
            'Data Type',
            'Mark',
            RowConstants.DATA_TYPE,
            true,
            'YYY'
        );
    });


    test('WHEN KguEn filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-kguens',
            'kguens',
            '827-33',
            RowConstants.KGU_EN,
            true,
            'YYY'
        );
    });

    test('WHEN unit filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await createSamForUnitFilter(page);

        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-unit',
            'Unit',
            '1/min',
            'Zusaetzliche Abgasreinigung: Beschreibung',
            "Test:UnitFilter",
            true,
            'YYY'
        );
    });



    test('WHEN Sam Type filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-sam-type',
            'Sam Type',
            'Direct',
            'Zusaetzliche Abgasreinigung: Beschreibung',
            "Test:UnitFilter",
            true,
            'YYY'
        );
    });

    test('WHEN Creator filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        // Set the timeout for this specific test to 5 minutes
        test.setTimeout(5 * 60 * 1000);

        await createSamForCreatorApproverRequesterFilter(page);

        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-creator',
            'Creator',
            PID_USER,
            'Zusaetzliche Abgasreinigung: Beschreibung',
            'Test:CreatorApproverRequesterFilter',
            true,
            'YYY'
        );
    });

    test('WHEN Approver filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-approver',
            'Approver',
            'MISHRAD',
            'Test:UnitFilter',
            'Test:CreatorApproverRequesterFilter',
            true,
            'YYY'
        );
    });

    test('WHEN Requester filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-requester',
            'Requester',
            PID_USER,
            'Zusaetzliche Abgasreinigung: Beschreibung',
            'Test:CreatorApproverRequesterFilter',
            true,
            'YYY'
        );
    });

    test('WHEN Certification market filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await createSamForCertificationMarketFilter(page);

        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-certification-market',
            'Certification Market',
            'Korea',
            RowConstants.CERTIFICATION_MARKET_EN,
            true,
            'YYY'
        );
    });

    test('WHEN Antriebe filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await createSamForAntriebeFilter(page);

        await filterWithOwnColumnInSamDashboard(
            page,
            'filter-antriebe',
            'Antriebe',
            'Mild/Full-Hybrid-Diesel',
            RowConstants.ANTRIEBE,
            true,
            'YYY'
        );
    });

    test('WHEN Certus market filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await createSamForCertusFilter(page);

        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-certus-market',
            'Certus Market',
            'EU',
            'Zusaetzliche Abgasreinigung: Beschreibung',
            'Test:CertusFilter',
            true,
            'YYY'
        );
    });

    test('WHEN Certus type filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-certus-type',
            'Certus Certificate Type',
            'Type-approval',
            'Zusaetzliche Abgasreinigung: Beschreibung',
            'Test:CertusFilter',
            true,
            'YYY'
        );
    });

    test('WHEN Certus Topic filter applied - THEN filter works and is also applied after page reload', async ({page}) => {
        await filterWithoutHavingOwnColumnInSamDashboard(
            page,
            'filter-certus-topic',
            'Certus Certificate Topic',
            'LIGHTING',
            'Zusaetzliche Abgasreinigung: Beschreibung',
            'Test:CertusFilter',
            true,
            'YYY'
        );
    });
});


async function navigateToSamDashboard(page: Page) {
    // Select "SAM" from the left menu bar
    await page.getByTestId('sidebar-sam-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*sam-dashboard/);
    await expect(page.getByTestId('sam-view')).toBeVisible();
}
