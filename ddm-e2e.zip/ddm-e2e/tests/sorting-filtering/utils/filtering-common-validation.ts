import {expect, Page} from "@playwright/test";
import {selectDatatableRowByIndex} from "../../utils/selector";
import {setRowsPerPage} from "@root/tests/utils/testHelper";
import {INPUT} from "@root/tests/utils/locators";
import {RowConstants} from "@root/tests/sorting-filtering/utils/constants";


/**
 * Applies filtering with a dedicated column and verifies expected behavior.
 * For example the Filter "samId" does have a dedicated column 'Sam Id ' in the Sam Dashboard table.
 * In contrast, there exists no column named "approver" even though a filter for "approver" exists.
 * @param page The Playwright page object
 * @param filterMenuButton Test ID for opening the filter menu
 * @param filter Test ID of the filter field
 * @param filterInput The primary value entered for filtering
 * @param filterColumnIndex The index of the column to apply the filter on
 * @param comboboxFeature True for dropdown, false for free text fields
 * @param noOptionsValue A value that yields no filter matches
 */
export async function filterWithOwnColumnInSamDashboard(
    page: Page,
    filterMenuButton: string,
    filter: string,
    filterInput: string,
    filterColumnIndex: number,
    comboboxFeature: boolean,
    noOptionsValue: string
) {
    const itemInput = `${filter}-input`;

    // Open the filter menu
    await openFilterMenu(page, filterMenuButton);

    // Apply the appropriate filter type
    await applyFilter(page, filter, filterInput, comboboxFeature, noOptionsValue, itemInput);

    // Verify the filter effect
    expect(await doesEveryRowContainFilterInput(page, filterInput, filterColumnIndex)).toBe(true);

    // Reload the page and verify the filters are still applied
    await page.reload();
    expect(await doesEveryRowContainFilterInput(page, filterInput, filterColumnIndex)).toBe(true);

    // Close the filter and re-verify the selection remains active because closing is not allowed when filters are set
    await closeFilter(page, filter);
    expect(await doesEveryRowContainFilterInput(page, filterInput, filterColumnIndex)).toBe(true);

    // Reopen the filter to confirm persistence
    await openFilterMenu(page, filterMenuButton);
    await verifyFilterPersistence(page, filter, filterInput, comboboxFeature);

    // Remove the filter and ensure items return to unfiltered state
    await clearFilter(page, filter, filterInput, comboboxFeature);
    expect(await doesEveryRowContainFilterInput(page, filterInput, filterColumnIndex)).toBe(false);
}

/**
 * Applies filtering without a dedicated column and verifies expected behavior.
 * For example the Filter "samId" does have a dedicated column 'Sam Id ' in the Sam Dashboard table
 * In contrast, there exists no column named "approver" even though a filter for "approver" exists.
 * @param page The Playwright page object
 * @param filterMenuButton Test ID for opening the filter menu
 * @param filter Test ID of the filter field
 * @param filterInput The primary value entered for filtering
 * @param excludedFromFilterResultSamNameDe The SAM Name (German) that should be excluded after filtering
 * @param includedInFilterResultSamNameDe The SAM Name (German) that should be included after filtering
 * @param comboboxFeature True for dropdown, false for free text fields
 * @param noOptionsValue A value that yields no filter matches
 */
export async function filterWithoutHavingOwnColumnInSamDashboard(
    page: Page,
    filterMenuButton: string,
    filter: string,
    filterInput: string,
    excludedFromFilterResultSamNameDe: string,
    includedInFilterResultSamNameDe: string,
    comboboxFeature: boolean,
    noOptionsValue: string
) {
    const itemInput = `${filter}-input`;

    // Ensure that the unfiltered item is initially visible
    expect(await doesAnyRowContainSamNameDe(page, excludedFromFilterResultSamNameDe)).toBe(true);

    // Open the filter menu
    await openFilterMenu(page, filterMenuButton);

    // Apply the appropriate filter type
    await applyFilter(page, filter, filterInput, comboboxFeature, noOptionsValue, itemInput);

    // Verify the filter effect
    expect(await doesAnyRowContainSamNameDe(page, includedInFilterResultSamNameDe)).toBe(true);
    expect(await doesAnyRowContainSamNameDe(page, excludedFromFilterResultSamNameDe)).toBe(false);

    // Reload the page and verify the filters are still applied
    await page.reload();
    expect(await doesAnyRowContainSamNameDe(page, includedInFilterResultSamNameDe)).toBe(true);
    expect(await doesAnyRowContainSamNameDe(page, excludedFromFilterResultSamNameDe)).toBe(false);

    // Close the filter and re-verify the selection remains active because closing is not allowed when filters are set
    await closeFilter(page, filter);
    expect(await doesAnyRowContainSamNameDe(page, includedInFilterResultSamNameDe)).toBe(true);
    expect(await doesAnyRowContainSamNameDe(page, excludedFromFilterResultSamNameDe)).toBe(false);

    // Reopen the filter to confirm persistence
    await openFilterMenu(page, filterMenuButton);
    await verifyFilterPersistence(page, filter, filterInput, comboboxFeature);

    // Remove the filter and ensure items return to unfiltered state
    await clearFilter(page, filter, filterInput, comboboxFeature);
    expect(await doesAnyRowContainSamNameDe(page, excludedFromFilterResultSamNameDe)).toBe(true);
}

/**
 * Checks if every row in the table contains the expected cell text.
 * @param page The Playwright page object.
 * @param expectedText The text that should be present in the specified column.
 * @param columnIndex The column index where the text should be checked.
 * @returns `true` if at least one row contains the expected text, otherwise `false`.
 */
async function doesEveryRowContainFilterInput(
    page: Page,
    expectedText: string,
    columnIndex: number
): Promise<boolean> {
    await setRowsPerPage(page, 500);
    let index = 0;

    while (true) {
        const row = selectDatatableRowByIndex(page, index);

        // Ensure the row is fully loaded and visible before proceeding
        try {
            await row.waitFor({ state: 'visible', timeout: 1000 });
        } catch (error) {
            break;
        }

        await row.scrollIntoViewIfNeeded();
        const cell = row.locator(`td[data-colindex="${columnIndex}"]`);
        const cellText = await cell.textContent();

        //remove all whitespaces and compare
        if (cellText && !cellText.replace(/\s+/g, '').includes(expectedText.replace(/\s+/g, ''))) {
            return false;
        }

        index++;
    }
    return true;
}

/**
 * Checks if any row in the table contains the expected SAM Name (English).
 * @param page The Playwright page object.
 * @param expectedSamNameDe The SAM Name (German) that should be present in the column.
 * @returns `true` if at least one row contains the expected text, otherwise `false`.
 */
async function doesAnyRowContainSamNameDe(
    page: Page,
    expectedSamNameDe: string
): Promise<boolean> {
    await setRowsPerPage(page, 500);
    let index = 0;

    while (true) {
        const row = selectDatatableRowByIndex(page, index);

        // Ensure the row is fully loaded and visible before proceeding
        try {
            await row.waitFor({ state: 'visible', timeout: 2000 });
        } catch (error) {
            break; // Stop when there are no more rows
        }

        await row.scrollIntoViewIfNeeded();
        const cell = row.locator(`td[data-colindex="${RowConstants.SAM_NAME_DE}"]`);
        const cellText = await cell.textContent();

        // If any row contains the expected text, return true immediately
        if (cellText && cellText.includes(expectedSamNameDe)) {
            return true;
        }

        index++;
    }
    return false;
}

/**
 * Opens the filter menu.
 */
async function openFilterMenu(page: Page, filterMenuButton: string) {
    await page.getByTestId('sam-view-filter').click();
    await page.getByTestId(filterMenuButton).click();
}

/**
 * Decide if the filter is a combobox or a text field and apply the filter.
 */
async function applyFilter(
    page: Page,
    filter: string,
    filterInput: string,
    comboboxFeature: boolean,
    noOptionsValue: string,
    itemInput: string
) {
    if (comboboxFeature) {
        await applyComboboxFilter(page, filter, filterInput, noOptionsValue);
    } else {
        await applyTextFieldFilter(page, itemInput, filterInput);
    }
    await setRowsPerPage(page, 500);
}

/**
 * Applies a combobox (dropdown) filter.
 */
async function applyComboboxFilter(
    page: Page,
    filter: string,
    filterInput: string,
    noOptionsValue: string
) {
    await page.getByTestId(filter).click();

    // Attempt to filter with a value that has no matching options
    await page.getByTestId(filter).locator(INPUT).fill(noOptionsValue);
    await expect(page.getByTestId(`${filter}-no-options`)).toBeVisible();

    // Apply a valid filter
    await page.getByTestId(filter).locator(INPUT).fill(filterInput);
    await expect(page.getByTestId(filter).locator(INPUT)).toHaveValue(filterInput);

    // Select the filtered option
    await page.getByTestId(filterInput).click();
}

/**
 * Applies a text field filter.
 */
async function applyTextFieldFilter(page: Page, itemInput: string, mainSelection: string) {
    await page.getByTestId(itemInput).locator('input').fill(mainSelection);
    await page.getByTestId(itemInput).locator('input').press('Enter');
}

/**
 * Closes the filter.
 */
async function closeFilter(page: Page, filter: string) {
    await page.getByTestId(`hide-button-${filter}`).click();
}

/**
 * Verifies that the filter persists after reopening.
 */
async function verifyFilterPersistence(
    page: Page,
    filter: string,
    filterInput: string,
    comboboxFeature: boolean
) {
    if (comboboxFeature) {
        await expect(page.getByTestId(filter)).toBeVisible();
        await expect(page.getByTestId(filter)).not.toBeEmpty();
        await expect(page.getByTestId(filter)).toContainText(filterInput);
    } else {
        const itemContainer = `${filter}-container`;
        await expect(page.getByTestId(itemContainer)).toBeVisible();
        await expect(page.getByTestId(itemContainer)).toContainText(filterInput);
    }
}

/**
 * Clears the applied filter.
 */
async function clearFilter(page: Page, filter: string, filterInput: string, comboboxFeature: boolean) {
    if (comboboxFeature) {
        await page.getByTestId(filter).locator(INPUT).click();
        await page.getByTestId(filter).getByTestId('CloseIcon').click();
        await expect(page.getByTestId(filter).locator(INPUT)).toBeEmpty();
    } else {
        const itemContainer = `${filter}-container`;
        await page.getByTestId(`${filter}-${filterInput}`).getByTestId('CancelIcon').click();
        await expect(page.getByTestId(itemContainer)).toBeEmpty();
    }
}