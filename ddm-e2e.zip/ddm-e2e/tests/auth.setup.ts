import {test as setup, expect, selectors} from '@playwright/test';
import * as fs from 'fs';

const jsonString = fs.readFileSync('playwright/.auth/user-store.json', 'utf-8');
const jsonData = JSON.parse(jsonString) as User;

interface User {
    name: string,
    password: string
}

const authFile = 'playwright/.auth/user.json';

setup('authenticate', async ({ page }) => {
    selectors.setTestIdAttribute("id");

    // Perform authentication steps. Replace these actions with your own.
    await page.goto('https://login-int.mercedes-benz.com/');
    await page.getByTestId('userid').fill(jsonData.name);
    await page.getByTestId('next-btn').click();
    await page.getByTestId('password').fill(jsonData.password);
    await page.getByTestId('loginSubmitButton').click();
    // Wait until the page receives the cookies.
    //
    // Sometimes login flow sets cookies in the process of several redirects.
    // Wait for the final URL to ensure that the cookies are actually set.
    // await page.waitForURL('https://login-int.mercedes-benz.com/');
    // Alternatively, you can wait until the page reaches a state where all cookies are set.
    await expect(page.getByTestId('logoutButton')).toBeEnabled();

    // End of authentication steps.

    await page.context().storageState({ path: authFile });
});