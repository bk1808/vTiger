export type StandardCaseTestData = {
    formatType: FormatType,
    samID: string,
    samUUID: string,
}

export type FormatType = {
    id: number;
    nameEn: string;
}
