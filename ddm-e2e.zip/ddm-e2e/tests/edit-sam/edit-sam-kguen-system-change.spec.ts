import {expect, test} from "@playwright/test";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {INPUT} from "../utils/locators";
import {
    SAM_FACTORY_SYSTEM_NAME_IDS,
    SAM_FACTORY_SAM_TYPE_IDS, DATA_SOURCE_SMARAGD_ID,
} from "../utils/constants";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit SAM - Change master system - behaviour of kguens and system affiliation', () => {
    test('GIVEN master system changes from Smaragd to CBC and back to Smaragd - THEN KGU-ENs and system affiliations are only editable for Smaragd and saved when system changes in edit mode', async ({page}) => {
        const kguens: string[] = ['900-01', '750-82'];
        const systemAffiliation: string[] = ['ENG.CTRL.'];

        // CREATE NEW SAM
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD,
            kguens: kguens,
            systemAffiliations: systemAffiliation
        });

        // Change the Data Source << from Smaragd to CBC >>
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC
        });

        // The KGU-EN attribute disappears
        // No KGU-EN can be entered
        // System Affiliation also disappears
        await expect(page.getByTestId('kguens')).not.toBeVisible();
        await expect(page.getByTestId('system-affiliations')).not.toBeVisible();

        await verifySamFactoryFields(page, {
            kguens: kguens,
            systemAffiliations: systemAffiliation,
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })

        // Change Data Source from << CBC to Smaragd >>
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD
        });

        // KGU-EN must be filled automatically with:
        // 900-01 ; 750-82
        // System Affiliation must be filled automatically with:
        // System Affiliation: ENG.CTRL.
        await expect(page.getByTestId('kguens').locator(INPUT)).toBeEditable();
        await expect(page.getByTestId('system-affiliations').locator(INPUT)).toBeEditable();

        await verifySamFactoryFields(page, {
            kguens: kguens,
            systemAffiliations: systemAffiliation
        })

        // EDIT THE NEW SAM AND VERIFY KGUENS AND SYSTEM AFFILIATION NOT SENT TO DDM_SERVICE
        // Change the Data Source << from Smaragd to CBC >>
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC
        });

        // The KGU-EN attribute disappears: The input field and value chips are both not present in the DOM (not just hidden)
        // System Affiliation also disappears: The input field and value chips are both not present in the DOM (not just hidden)
        await expect(page.getByTestId('kguens')).not.toBeVisible();
        await expect(page.getByTestId('system-affiliations')).not.toBeVisible();

        await verifySamFactoryFields(page, {
            kguens: kguens,
            systemAffiliations: systemAffiliation,
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT
        });

        // Submit
        await page.getByTestId('submit-button').click();
        // Redirecting to the SAM detail view page
        await expect(page).toHaveURL(/.*sam-detail/);
        // Navigate to edit view
        await page.getByTestId('Sam.DetailView.Edit.Button').click();
        await expect(page).toHaveURL(/.*sam-edit/);

        // Change Data Source from << CBC to Smaragd >>
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD
        });

        // No KGU-EN are set in SAM form
        // No System Affiliation are set in SAM form
        await expect(page.getByTestId('kguens').locator(INPUT)).toBeEditable();

        await verifySamFactoryFields(page, {
            kguens: kguens,
            systemAffiliations: systemAffiliation,
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })

        // Submit
        await page.getByTestId('submit-button').click();
        // Redirecting to the SAM detail view page
        await expect(page).toHaveURL(/.*sam-detail/);
        // Verify in Detail View
        await verifySamFactoryFields(page, {
            masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`
        })

        // The KGU-EN input field is visible but empty
        // The System Affiliation input field is not visible and empty
        await expect(page.getByTestId('kguens')).toBeVisible();
        await expect(page.getByTestId('system-affiliations')).not.toBeVisible();

        await verifySamFactoryFields(page, {
            kguens: kguens,
            systemAffiliations: systemAffiliation,
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            kguens: kguens,
            systemAffiliations: systemAffiliation,
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })
    });
});