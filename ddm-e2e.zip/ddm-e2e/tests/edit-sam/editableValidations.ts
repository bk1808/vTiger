import {expect, Page} from "@playwright/test";
import {
    verifyIsEditableById,
    verifyIsEditableByIdLocator,
    verifyIsNotEditableById,
    verifyIsNotEditableByIdLocator
} from "../utils/commonValidations"
import {INPUT} from "../utils/locators";

export async function verifyNothingIsEditable (page: Page) {
    await verifyNothingIsEditableHistoryPage(page);
    await verifyIsNotEditableByIdLocator(page, 'system-affiliations', INPUT);
}

export async function verifyNothingIsEditableHistoryPage (page: Page) {
    await expect(page.getByTestId('summary').locator('div > textarea').first()).not.toBeEditable();
    await verifyIsNotEditableById(page, 'create-sam-date-picker');
    await verifyIsNotEditableById(page, 'explanation');

    await verifyIsNotEditableByIdLocator(page, 'disciplineId-de', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'disciplineId-en', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'nameDe', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'nameEn', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'featureDataTypeId', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'samFormatTypeId', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'masterDataSystemId', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'kguens', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'supplementalInformationDe', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'supplementalInformationEn', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'defaultValue', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'notesOnDefaultValue', INPUT);
}


export async function verifyOnlyChangeBlockIsEditable (page: Page) {
    await expect(page.getByTestId('summary').locator('div > textarea').first()).toBeEditable();
    await verifyIsEditableById(page, 'create-sam-date-picker');
    await verifyIsEditableById(page, 'explanation');

    await verifyIsNotEditableByIdLocator(page, 'disciplineId-de', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'disciplineId-en', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'nameDe', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'nameEn', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'featureDataTypeId', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'samFormatTypeId', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'masterDataSystemId', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'kguens', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'system-affiliations', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'supplementalInformationDe', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'supplementalInformationEn', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'defaultValue', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'notesOnDefaultValue', INPUT);
}

export async function verifyEditableFieldsOnEditView(page: Page) {
    await expect(page.getByTestId('summary').locator('div > textarea').first()).toBeEditable();
    await verifyIsEditableById(page, 'create-sam-date-picker');
    await verifyIsEditableById(page, 'explanation');

    await verifyIsNotEditableByIdLocator(page, 'disciplineId-de', INPUT);
    await verifyIsNotEditableByIdLocator(page, 'disciplineId-en', INPUT);
    await verifyIsEditableById(page, 'nameDe');
    await verifyIsEditableById(page, 'nameEn');
    await verifyIsEditableByIdLocator(page, 'featureDataTypeId', INPUT);
    await verifyIsEditableByIdLocator(page, 'samFormatTypeId', INPUT);
    await verifyIsEditableByIdLocator(page, 'samTypeId', INPUT);
    await verifyIsEditableByIdLocator(page, 'masterDataSystemId', INPUT);
    await verifyIsEditableByIdLocator(page, 'kguens', INPUT);
    await verifyIsEditableByIdLocator(page, 'system-affiliations', INPUT);
    await verifyIsEditableByIdLocator(page, 'supplementalInformationDe', INPUT);
    await verifyIsEditableByIdLocator(page, 'supplementalInformationEn', INPUT);
    await verifyIsEditableByIdLocator(page, 'defaultValue', INPUT);
    await verifyIsEditableByIdLocator(page, 'notesOnDefaultValue', INPUT);
}
