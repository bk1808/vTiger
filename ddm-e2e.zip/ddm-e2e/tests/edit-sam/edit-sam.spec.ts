import {expect, Page, test} from "@playwright/test";
import {
    verifyEditableFieldsOnEditView,
    verifyNothingIsEditable, verifyNothingIsEditableHistoryPage,
    verifyOnlyChangeBlockIsEditable
} from "./editableValidations";
import {
    KGUEN_IN_RANGE, PID_USER,
    STATUS_IN_PROGRESS, STATUS_IN_REVIEW,
    STATUS_NEW, SYSTEM_AFFILIATION_ABBREVIATION
} from "../utils/constants";
import {INPUT} from "../utils/locators";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam,
    verifyCreatorRequesterApprover
} from "../utils/testHelper";
import {verifyIsVisibleAndHasRedColorByText} from "@root/tests/utils/commonValidations";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {Messages} from "@root/tests/create-sam/utils/messages";

const SAM_ID_NEW_IN_PROGRESS: string = 'ASC.0001';
const SAM_ID_NEW_IN_REVIEW: string = 'ASC.0002';

const SAM_UUID_ACTIVE_CLOSED_2: string = '297b863b-17f3-48f6-847c-64ef31920c6e';
const SAM_ID_ACTIVE_CLOSED_2: string = 'SBE.0003';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit SAM', () => {
    test('GIVEN SAM is in progress - THEN nothing is editable on detail view', async ({page}) => {
        await navigateToSamDetailViewWithSamInProgress(page);

        //Nothing is editable
        await verifyNothingIsEditable(page);
    });

    test('GIVEN SAM is in progress - THEN nothing is editable in history view', async ({page}) => {
        await navigateToSamDetailViewWithSamInProgress(page);

        // Navigate to "SAM HISTORY VIEW"
        const historyViewPage = await goFromDetailViewToHistoryView(page);
        await verifyNothingIsEditableHistoryPage(historyViewPage);
    });

    test('GIVEN SAM is in progress - THEN verify editable and non-editable fields in edit view', async ({page}) => {
        const EDITED_SAM_NAME_2: string = 'EditedSAMName2:EditedSAMName2';

        await navigateToSamDetailViewWithSamInProgress(page);
        // go to edit view
        await page.getByTestId('Sam.DetailView.Edit.Button').click();
        await expect(page).toHaveURL(/.*sam-edit/);
        // Everything is editable except for [Discipline] (and SAM Name)
        await verifyEditableFieldsOnEditView(page);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            nameDe: EDITED_SAM_NAME_2,
            nameEn: EDITED_SAM_NAME_2,
            targetDate: getSameDateInNextYear(),
        })

        // Submit and verify edit changes
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            nameDe: EDITED_SAM_NAME_2,
            nameEn: EDITED_SAM_NAME_2,
            targetDate: getSameDateInNextYear(),
        })

        await expect(page.getByTestId(`kguen-chip-${KGUEN_IN_RANGE}`)).toBeVisible();
        await expect(page.getByTestId(`system-affiliation-chip-${SYSTEM_AFFILIATION_ABBREVIATION}`)).toBeVisible();
    });

    test('GIVEN SAM status is in review - THEN nothing is editable', async ({page}) => {
        // Select "SAM" from the left menu bar
        await page.getByTestId('sidebar-sam-button').click();
        // Redirecting to "SAM Overview". A table of SAMs is provided
        await expect(page).toHaveURL(/.*sam-dashboard/);
        await expect(page.getByTestId('sam-view')).toBeVisible();
        //Using a SAM in [SAM-Status = new] and [Change Status = In Review] (e.g. ASC.0002)
        await page.getByText(SAM_ID_NEW_IN_REVIEW).click();
        //Redirecting to the detail view
        await expect(page).toHaveURL(/.*sam-detail/);

        //[SAM-Status = new] and [Change Status = In Review]
        await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue(STATUS_NEW);
        await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue(STATUS_IN_REVIEW);

        // Buttons "Set to In Review", "EDIT", "Cancel Change" are not visible
        await expect(page.getByTestId('Common.InReview')).not.toBeVisible();
        await expect(page.getByTestId('Sam.DetailView.Edit.Button')).not.toBeVisible();
        await expect(page.getByTestId('Sam.DetailView.CancelChange.Button')).not.toBeVisible();

        await verifyCreatorRequesterApprover(page, "Systemadmin", " ", " ");

        await verifyNothingIsEditable(page);
    });

    test('GIVEN SAM is revised and set to inactive - THEN only change block is editable', async ({page}) => {
        const SUMMARY_EDITED: string = 'Edited Summary';
        const EXPLANATION_EDITED: string = 'Edited Explanation';

        const SUMMARY_EDITED_AGAIN_FOR_NEW_REVISION: string = 'Edited Again Summary';
        const EXPLANATION_EDITED_AGAIN_FOR_NEW_REVISION: string = 'Edited Again Explanation';

        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_2);

        // Hit 'Revise' button then hit 'Set to Inactive' button in dialog
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-right-button').click();
        // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_2}`));

        await verifyOnlyChangeBlockIsEditable(page);

        await verifySamFactoryFields(page, {
            summary: '',
            explanation: '',
            targetDate: null
        })

        await page.getByTestId('submit-button').click();
        await verifyIsVisibleAndHasRedColorByText(page, Messages.TARGET_DATE_REQUIRED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.SUMMARY_IS_EMPTY_ERROR);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.EXPLANATION_IS_EMPTY_ERROR);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            targetDate: getSameDateInNextYear(),
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
        })

        // Submit and verify
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
            targetDate: getSameDateInNextYear(),
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
            targetDate: getSameDateInNextYear(),
        })

        await page.getByTestId('Sam.DetailView.Edit.Button').click();
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            summary: SUMMARY_EDITED_AGAIN_FOR_NEW_REVISION,
            explanation: EXPLANATION_EDITED_AGAIN_FOR_NEW_REVISION,
            targetDate: getSameDateInNextYear()
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            summary: SUMMARY_EDITED_AGAIN_FOR_NEW_REVISION,
            explanation: EXPLANATION_EDITED_AGAIN_FOR_NEW_REVISION,
            targetDate: getSameDateInNextYear()
        })
    });

    test('GIVEN SAM is edited - THEN creator is saved', async ({page}) => {
        await navigateToCreateSam(page);
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifyCreatorRequesterApprover(page, PID_USER, " ", " ");

        await page.getByTestId('Sam.DetailView.Edit.Button').click();
        await expect(page).toHaveURL(/.*sam-edit/);
        await page.getByTestId('submit-button').click();

        await verifyCreatorRequesterApprover(page, PID_USER, " ", " ");
    });
});

async function navigateToSamDetailViewWithSamInProgress(page: Page) {
    // Select "SAM" from the left menu bar
    await page.getByTestId('sidebar-sam-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*sam-dashboard/);
    await expect(page.getByTestId('sam-view')).toBeVisible();
    //Using a SAM in [SAM-Status = new] and [Change Status = In Progress] (e.g. ASC.0001)
    await page.getByText(SAM_ID_NEW_IN_PROGRESS).click();
    //Redirecting to the detail view
    await expect(page).toHaveURL(/.*sam-detail/);
    //[SAM-Status = new] and [Change Status = In Progress]
    await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue(STATUS_NEW);
    await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue(STATUS_IN_PROGRESS);
    // Buttons "Set to In Review", "EDIT", "Cancel Change" are visible
    await expect(page.getByTestId('Common.InReview')).toBeVisible();
    await expect(page.getByTestId('Sam.DetailView.Edit.Button')).toBeVisible();
    await expect(page.getByTestId('Sam.DetailView.CancelChange.Button')).toBeVisible();
}