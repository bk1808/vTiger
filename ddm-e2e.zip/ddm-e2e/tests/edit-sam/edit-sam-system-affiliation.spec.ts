import {expect, test} from "@playwright/test";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {KGUEN_IN_RANGE, SAM_FACTORY_DATA_TYPE_IDS, SYSTEM_AFFILIATION_ABBREVIATION} from "../utils/constants";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {Messages} from "@root/tests/create-sam/utils/messages";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";

const SAM_UUID_ACTIVE_CLOSED: string = '215c6688-4901-4275-81c7-9f02f796bda8';
const SAM_ID_ACTIVE_CLOSED: string = 'ASC.0446';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit System Affiliation', () => {
    test('GIVEN SAM is revised - THEN system affiliation is editable and changes are saved', async ({page}) => {
        // REVISE a SAM with a KGU-EN in the range of 900-904 and a filled System Affiliation
        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED);
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-left-button').click()
        // Everything is editable without [Discipline] (and SAM Name)
        // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED}`));

        // Delete the System Affiliation of the revised SAM
        await page.getByTestId('system-affiliations').click();
        await page.getByTestId('system-affiliations').getByTestId('CloseIcon').click();

        await verifySamFactoryFields(page, {
            systemAffiliations: [SYSTEM_AFFILIATION_ABBREVIATION],
            verifyEquality: {
                systemAffiliations: false
            }
        })
        // SAM can not be saved. a Error message appers and the text is red highlighted
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED}`));
        await verifyIsEditableAndHasRedColorById(page, 'system-affiliations');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR);

        // Delete all KGU-EN in the range of 900-904
        await page.getByTestId('kguens').click();
        await page.getByTestId('kguens').getByTestId('CloseIcon').click();

        await verifySamFactoryFields(page, {
            kguens: [KGUEN_IN_RANGE],
            verifyEquality: {
                kguens: false
            }
        })

        // System affiliation disappears and the SAM can be saved and no error message appears.
        await verifySamFactoryFields(page, {
            systemAffiliations: [SYSTEM_AFFILIATION_ABBREVIATION],
            verifyEquality: {
                systemAffiliations: false
            }
        })

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            summary: 'Summary',
            explanation: 'Explanation',
            targetDate: getSameDateInNextYear(),
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.DOCUMENT,
        })

        await expect(page.getByText(Messages.FIELD_IS_REQUIRED_ERROR)).not.toBeVisible();

        // Submit and verify edit changes
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            kguens: [KGUEN_IN_RANGE],
            systemAffiliations: [SYSTEM_AFFILIATION_ABBREVIATION],
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            kguens: [KGUEN_IN_RANGE],
            systemAffiliations: [SYSTEM_AFFILIATION_ABBREVIATION],
            verifyEquality: {
                kguens: false,
                systemAffiliations: false
            }
        })
    });
});