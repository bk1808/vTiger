import {expect, test} from "@playwright/test";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import { SAM_FACTORY_CERTIFICATION_MARKET_IDS, SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "../utils/constants";

const SAM_UUID_ACTIVE_CLOSED_1: string = 'db13938c-8a93-4822-a5a0-7b106f28d2c7';
const SAM_ID_ACTIVE_CLOSED_1: string = 'ASC.0006';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit SAM certification market and free attribute and additional information', () => {
    test.skip('GIVEN SAM is revised and edited - THEN certificationMarketDe, certificationMarketEn, freeAttributeDe, freeAttributeEn, supplementalInformationDe and supplementalInformationEn are editable and changes are saved', async ({page}) => {
        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_1);

        // Hit 'Revise' button then hit 'Edit' button in dialog
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-left-button').click();
        // // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_1}`));

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
            summary: 'summary',
            explanation: 'explanation',
            targetDate: getSameDateInNextYear(),
            freeAttributeDe: 'freeAttributeDe',
            freeAttributeEn: 'freeAttributeEn',
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn',
            certificationMarketDe:SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_DE
        })

        // // Submit and verify edit changes
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            freeAttributeDe: 'freeAttributeDe',
            freeAttributeEn: 'freeAttributeEn',
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            freeAttributeDe: 'freeAttributeDe',
            freeAttributeEn: 'freeAttributeEn',
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn'
        })
    });
});