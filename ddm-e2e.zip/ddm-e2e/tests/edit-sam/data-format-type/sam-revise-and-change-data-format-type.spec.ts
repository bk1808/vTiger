import {expect, Page, test} from "@playwright/test";
import {
     navigateToBaseUrl,navigateToSam,goFromDetailViewToHistoryView,getSameDateInNextYear
} from "@root/tests/utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {
    FORMAT_TYPE_REGEX_ID,FORMAT_TYPE_FREE_TEXT_ID,FORMAT_TYPE_NO_VALUE_ID,FORMAT_TYPE_BLANK_ID,
    SAM_TYPE_DIRECT_ID,DATA_SOURCE_SMARAGD_ID,DATA_TYPE_NUMBER_ID,SAM_TYPE_LEG_VERF_VEHICLE_ID,SAM_FACTORY_SAM_TYPE_IDS,SAM_FACTORY_DATA_FORMAT_TYPE_IDS,
    DATA_TYPE_NUMERICAL_VALUE_ID,SAM_TYPE_LEG_VERF_COMPONENT_ID,FEATURE_DATA_TYPE_DOCUMENT_ID,
    SAM_FACTORY_DATA_TYPE_IDS, SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS
} from "@root/tests/utils/constants";
import {SAM_ID_ACTIVE_CLOSED_REGEX,SAM_ID_ACTIVE_CLOSED_REGEX_VALUE_DEFINITION,SAM_ID_ACTIVE_CLOSED_FREE_TEXT,SAM_ID_ACTIVE_CLOSED_NUMBER,
    SAM_ID_ACTIVE_CLOSED_LEG_VERF_COMPONENT,SAM_UUID_ACTIVE_CLOSED_REGEX,SAM_UUID_ACTIVE_CLOSED_REGEX_VALUE_DEFINITION,SAM_UUID_ACTIVE_CLOSED_FREE_TEXT,
    SAM_UUID_ACTIVE_CLOSED_NUMBER,SAM_UUID_ACTIVE_CLOSED_LEG_VERF_COMPONENT,SAM_ID_ACTIVE_CLOSED_BLANK,SAM_UUID_ACTIVE_CLOSED_BLANK} from "./utils/constants";
import {INPUT} from "@root/tests/utils/locators";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

async function reviseAndEditSam(page: Page,SAM_UUID : string) {
    await page.getByTestId('Sam.DetailView.Revise.Button').click();
    await page.getByTestId('confirmation-dialog-left-button').click();
    await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID}`));
}
async function submitAndValidateStatusNewInProgress(page: Page) {
    await page.getByTestId('submit-button').click();
    await expect(page).toHaveURL(/.*sam-detail/);
    await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue('new');
    await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue('in Progress');
}

    test.describe('SAM Revision Workflows', () => {

          test('GIVEN a Active/Closed SAM having DataType-NUMERICAL_VALUE SamType-Direct samFormatType-RegEx  Value Definition ^A\\d{10}$  - THEN SAM with updated Value Definition ^A\\d{20}$', async ({ page }) => {
              await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_REGEX)

              await reviseAndEditSam(page, SAM_UUID_ACTIVE_CLOSED_REGEX);

              await page.getByTestId('samFormatTypeId').click();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.EMPTY)).not.toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY)).toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST)).toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX)).toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.NO_VALUE)).toBeVisible();
              await page.click('body');

              await fillSamFactoryFields(page, {
                    fillMandatoryFieldsAutomatically: false,
                    summary: 'summary',
                    explanation: 'explanation',
                    targetDate: getSameDateInNextYear(),
                    valueDefinition: "^A\\d{20}$"
              });

              await submitAndValidateStatusNewInProgress(page);

              await verifySamFactoryFields(page, {
                    featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                    samType: `${SAM_TYPE_DIRECT_ID}`,
                    samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                    valueDefinition: "^A\\d{20}$"
              });

              await goFromDetailViewToHistoryView(page);

              await verifySamFactoryFields(page, {
                      featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                      samType: `${SAM_TYPE_DIRECT_ID}`,
                      samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                      valueDefinition: "^A\\d{20}$"
              });
          });

          test('GIVEN a Active/Closed SAM having DataType-NUMERICAL_VALUE SamType-Direct samFormatType-RegEx  Value Definition ^A\\d{20}$  - THEN SAM with updated samFormatType- FREE_TEXT_NOT_EMPTY', async ({ page }) => {
              await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_REGEX_VALUE_DEFINITION);

              await reviseAndEditSam(page, SAM_UUID_ACTIVE_CLOSED_REGEX_VALUE_DEFINITION);

              await page.getByTestId('samFormatTypeId').click();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.EMPTY)).not.toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY)).toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST)).toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX)).toBeVisible();
              await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.NO_VALUE)).toBeVisible();
              await page.click('body');

              await fillSamFactoryFields(page, {
                fillMandatoryFieldsAutomatically: false,
                summary: 'summary',
                explanation: 'explanation',
                targetDate: getSameDateInNextYear(),
                samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY,
              });

              await submitAndValidateStatusNewInProgress(page);

              await verifySamFactoryFields(page, {
                  featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                  samType: `${SAM_TYPE_DIRECT_ID}`,
                  samFormatType: `${FORMAT_TYPE_FREE_TEXT_ID}`
              });

              await goFromDetailViewToHistoryView(page);

              await verifySamFactoryFields(page, {
                  featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                  samType: `${SAM_TYPE_DIRECT_ID}`,
                  samFormatType: `${FORMAT_TYPE_FREE_TEXT_ID}`
              });

          });

          test('GIVEN a Active/Closed SAM having DataType-NUMERICAL_VALUE SamType-Direct samFormatType-FREE_TEXT_NOT_EMPTY - THEN SAM with updated DataType-NUMBER', async ({ page }) => {
                 await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_FREE_TEXT);

                 await reviseAndEditSam(page, SAM_UUID_ACTIVE_CLOSED_FREE_TEXT);

                 await fillSamFactoryFields(page, {
                   fillMandatoryFieldsAutomatically: false,
                   summary: 'summary',
                   explanation: 'explanation',
                   targetDate: getSameDateInNextYear(),
                   featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
                   unit: 'unit-cm',
                   featureDataTypeRegularExpression: 'featureDataTypeRegularExpression-1,23457E+12',
                 });

                await submitAndValidateStatusNewInProgress(page);

                await verifySamFactoryFields(page, {
                   featureDataType: `${DATA_TYPE_NUMBER_ID}`,
                   samType: `${SAM_TYPE_DIRECT_ID}`,
                   samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                   unit: 'cm',
                   featureDataTypeRegularExpression: '1,23457E+12'
                });

               await goFromDetailViewToHistoryView(page);

                 await verifySamFactoryFields(page, {
                    featureDataType: `${DATA_TYPE_NUMBER_ID}`,
                    samType: `${SAM_TYPE_DIRECT_ID}`,
                    samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                    unit: 'cm',
                    featureDataTypeRegularExpression: '1,23457E+12'
                 });
          });

          test('GIVEN a Active/Closed SAM having DataType-NUMBER  - THEN SAM with updated SamType-LEG_VERF_COMPONENT', async ({page}) => {
                await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_NUMBER);

                await reviseAndEditSam(page, SAM_UUID_ACTIVE_CLOSED_NUMBER);

                await fillSamFactoryFields(page, {
                   fillMandatoryFieldsAutomatically: false,
                   summary: 'summary',
                   explanation: 'explanation',
                   targetDate: getSameDateInNextYear(),
                   samType: SAM_FACTORY_SAM_TYPE_IDS.LEG_VERF_COMPONENT
               });

               await submitAndValidateStatusNewInProgress(page);

               await verifySamFactoryFields(page, {
                  featureDataType: `${FEATURE_DATA_TYPE_DOCUMENT_ID}`,
                  samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                  valueAmount: '1',
                  valueDefinition: '^A\\d{10}$',
               });

               await goFromDetailViewToHistoryView(page);

               await verifySamFactoryFields(page, {
                   featureDataType: `${FEATURE_DATA_TYPE_DOCUMENT_ID}`,
                   samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                   valueAmount: '1',
                   valueDefinition: '^A\\d{10}$',
                   samType: `${SAM_TYPE_LEG_VERF_COMPONENT_ID}`
               });

          });

          test('GIVEN a Active/Closed SAM having  SamType-LEG_VERF_COMPONENT  - THEN SAM with updated SamType-LEG_VERF_VEHICLE', async ({page}) => {
               await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_LEG_VERF_COMPONENT);

               await reviseAndEditSam(page, SAM_UUID_ACTIVE_CLOSED_LEG_VERF_COMPONENT);

               await fillSamFactoryFields(page, {
                   fillMandatoryFieldsAutomatically: false,
                   summary: 'summary',
                   explanation: 'explanation',
                   targetDate: getSameDateInNextYear(),
                   samType: SAM_FACTORY_SAM_TYPE_IDS.LEG_VERF_VEHICLE
               });

               await expect(page.getByTestId('kguen-chip-000-99')).toBeVisible();
               await expect(page.getByTestId('kguen-chip-000-99').locator('button')).toBeDisabled();
               await expect(page.getByTestId('kguens').locator(INPUT)).toBeEditable();

               await fillSamFactoryFields(page, {
                   fillMandatoryFieldsAutomatically: false,
                   legalVerificationDrawing: SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS.GE_NACHWEIS
               });

              await submitAndValidateStatusNewInProgress(page);

              await verifySamFactoryFields(page, {
                    featureDataType: `${FEATURE_DATA_TYPE_DOCUMENT_ID}`,
                    samFormatType: `${FORMAT_TYPE_NO_VALUE_ID}`,
                    valueAmount: '',
                    valueDefinition: '',
                    masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
                    samType: `${SAM_TYPE_LEG_VERF_VEHICLE_ID}`
              });

              await goFromDetailViewToHistoryView(page);

               await verifySamFactoryFields(page, {
                   featureDataType: `${FEATURE_DATA_TYPE_DOCUMENT_ID}`,
                   samFormatType: `${FORMAT_TYPE_NO_VALUE_ID}`,
                   valueAmount: '',
                   valueDefinition: '',
                   masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
                   defaultValue: '',
                   samType: `${SAM_TYPE_LEG_VERF_VEHICLE_ID}`
               });

          });

          test('GIVEN a Active/Closed SAM having DataType-NUMERICAL_VALUE SamType-Direct samFormatType-BLANK - THEN SAM with updated samFormatType-RegEx', async ({ page }) => {
                     await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_BLANK);

                     await reviseAndEditSam(page, SAM_UUID_ACTIVE_CLOSED_BLANK);

                     await verifySamFactoryFields(page, {
                         featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                         samFormatType: `${FORMAT_TYPE_BLANK_ID}`,
                         masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
                         samType: `${SAM_TYPE_DIRECT_ID}`
                     });

                     await expect(page.getByTestId('formatTypeValueAmount').locator(INPUT)).not.toBeVisible();
                     await expect(page.getByTestId('formatTypeValueDefinition').locator(INPUT)).not.toBeVisible();
                     await expect(page.getByTestId('valueDefinition').locator(INPUT)).not.toBeVisible();

                     await page.getByTestId('samFormatTypeId').click();
                     await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.EMPTY)).toBeVisible();
                     await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY)).toBeVisible();
                     await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST)).toBeVisible();
                     await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX)).toBeVisible();
                     await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.NO_VALUE)).toBeVisible();
                     await page.click('body');

                    await fillSamFactoryFields(page, {
                         fillMandatoryFieldsAutomatically: false,
                         summary: 'summary',
                         explanation: 'explanation',
                         targetDate: getSameDateInNextYear(),
                         samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX,
                         valueDefinition: "^A\\d{10}$"
                     });

                    await submitAndValidateStatusNewInProgress(page);

                    await verifySamFactoryFields(page, {
                        featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                        samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                        valueAmount: '1',
                        valueDefinition: '^A\\d{10}$',
                        masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
                        samType: `${SAM_TYPE_DIRECT_ID}`
                    });

                    await goFromDetailViewToHistoryView(page);

                     await verifySamFactoryFields(page, {
                         featureDataType: `${DATA_TYPE_NUMERICAL_VALUE_ID}`,
                         samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
                         valueAmount: '1',
                         valueDefinition: '^A\\d{10}$',
                         masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
                         defaultValue: '',
                         samType: `${SAM_TYPE_DIRECT_ID}`
                     });
          });
    });