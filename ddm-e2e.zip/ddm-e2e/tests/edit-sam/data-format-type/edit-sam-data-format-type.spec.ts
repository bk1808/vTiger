import {expect, Page, test} from "@playwright/test";
import {verifyIsNotEditableByIdLocator} from "@root/tests/utils/commonValidations";
import {INPUT, TEXTAREA} from "@root/tests/utils/locators";
import {
    FORMAT_TYPE_FREE_TEXT_ID,
    FORMAT_TYPE_NO_VALUE_ID,
    FORMAT_TYPE_REGEX_ID,
    FORMAT_TYPE_SELECT_FROM_LIST_ID, SAM_FACTORY_DATA_FORMAT_TYPE_IDS, SAM_FACTORY_DATA_TYPE_IDS
} from "@root/tests/utils/constants";
import {getSameDateInNextYear, navigateToBaseUrl, navigateToSam} from "@root/tests/utils/testHelper";
import {FormatType} from "@root/tests/edit-sam/models";
import {
    formatTypeValues,
    SAM_ID_ACTIVE_CLOSED_BLANK,
    SAM_REVISION_ID_ACTIVE_CLOSED_NO_VALUE,
    SAM_REVISION_ID_ACTIVE_CLOSED_REGEX,
    SAM_UUID_ACTIVE_CLOSED_BLANK,
    SAM_UUID_ACTIVE_CLOSED_REGEX,
    standardCaseTestData
} from "@root/tests/edit-sam/constants";
import {SamFactoryFillProps} from "@root/tests/create-sam/utils/models";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.afterEach(async ({page}) => {
    await cleanup(page);
});

async function cleanup(page: Page) {
    if (page.url().includes('sam-edit')) {
        await cancelEdit(page)
    }
    if (page.url().includes('sam-detail') && isDetailPageOfNewRevision(page.url())) {
        await cancelChange(page)
    }
}

function isDetailPageOfNewRevision(url: string) {
    let revisionId = parseInt(url.split('/').at(-1) ?? '-1');
    return revisionId > SAM_REVISION_ID_ACTIVE_CLOSED_NO_VALUE;
}

async function cancelEdit(page: Page) {
    await page.getByTestId('cancel-edit-button').click();
}

async function cancelChange(page: Page) {
    await page.getByTestId('Sam.DetailView.CancelChange.Button').click();
    await page.getByTestId('confirmation-dialog-right-button').click();
}

test.describe.configure({mode: "serial"}); // may not run in parallel to ensure correct cleanup

async function verifyPreconditions(page: Page, expectedCurrentSelection: string) {
    await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue('active');
    await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue('closed');
    await verifyIsNotEditableByIdLocator(page, 'samFormatTypeId', INPUT);
    await expect(page.getByTestId('samFormatTypeId').locator('div > div')).toHaveText(expectedCurrentSelection);
}

test.describe('Edit SAM - Change format type with new revision', () => {

    for (const targetFormatType of formatTypeValues) {
        test(`GIVEN active closed SAM with Format Type blank - THEN new SAM revision with Format Type ${targetFormatType.nameEn} is created successfully`, async ({page}) => {
            const inputLocator = targetFormatType.id === FORMAT_TYPE_SELECT_FROM_LIST_ID ? TEXTAREA : INPUT

            await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_BLANK)
            await verifyPreconditions(page, '');

            // Revise
            await page.getByTestId('Sam.DetailView.Revise.Button').click();
            // Hit "EDIT"
            await page.getByTestId('confirmation-dialog-left-button').click();

            await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_BLANK}`));

            await page.getByTestId('featureDataTypeId').click();
            await page.getByTestId(SAM_FACTORY_DATA_TYPE_IDS.UNDEFINED).click();

            await page.getByTestId('samFormatTypeId').click();
            await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.EMPTY)).toBeVisible();
            await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY)).toBeVisible();
            await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST)).toBeVisible();
            await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX)).toBeVisible();
            await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.NO_VALUE)).toBeVisible();

            // new selection
            await page.getByTestId('data-format-type-value-' + targetFormatType.id).click();

            if (targetFormatType.id === FORMAT_TYPE_NO_VALUE_ID || targetFormatType.id === FORMAT_TYPE_FREE_TEXT_ID) {
                await expect(page.getByTestId('formatTypeValueAmount').locator(INPUT)).not.toBeEditable();
                await expect(page.getByTestId('formatTypeValueDefinition').locator(inputLocator)).not.toBeEditable();
            }

            await fillSamFactoryFields(page, {
                fillMandatoryFieldsAutomatically: false,
                summary: 'Summary',
                explanation: 'Explanation',
                targetDate: getSameDateInNextYear(),
            })

            if ([FORMAT_TYPE_SELECT_FROM_LIST_ID, FORMAT_TYPE_REGEX_ID].includes(targetFormatType.id)) {
                const fillOptions: SamFactoryFillProps = {
                    fillMandatoryFieldsAutomatically: false,
                    valueAmount: targetFormatType.id === FORMAT_TYPE_SELECT_FROM_LIST_ID ? '1' : undefined,
                    valueDefinitionSelectFromList: targetFormatType.id === FORMAT_TYPE_SELECT_FROM_LIST_ID ? '^d+.d{4}$' : undefined,
                    valueDefinition: targetFormatType.id === FORMAT_TYPE_REGEX_ID ? '^d+.d{4}$' : undefined,
                };
                await fillSamFactoryFields(page, fillOptions);
            }

            await submitAndValidateState(page, targetFormatType);
        });
    }

    for (const current of standardCaseTestData) {
        for (const targetFormatType of formatTypeValues) {
            test(`GIVEN active closed SAM with Format Type ${current.formatType.nameEn} - THEN new SAM revision with Format Type  ${targetFormatType.nameEn} is created successfully`, async ({page}) => {
                const inputLocator = targetFormatType.id === FORMAT_TYPE_SELECT_FROM_LIST_ID ? TEXTAREA : INPUT
                await navigateToSam(page, current.samID);

                await verifyPreconditions(page, current.formatType.nameEn);

                // Revise
                await page.getByTestId('Sam.DetailView.Revise.Button').click();
                // Hit "EDIT"
                await page.getByTestId('confirmation-dialog-left-button').click();

                await expect(page).toHaveURL(new RegExp(`/sam-edit/${current.samUUID}`));
                await page.getByTestId('featureDataTypeId').click();
                await page.getByTestId(SAM_FACTORY_DATA_TYPE_IDS.UNDEFINED).click();

                await page.getByTestId('samFormatTypeId').click();
                await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.EMPTY)).not.toBeVisible();
                await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY)).toBeVisible();
                await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST)).toBeVisible();
                await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX)).toBeVisible();
                await expect(page.getByTestId(SAM_FACTORY_DATA_FORMAT_TYPE_IDS.NO_VALUE)).toBeVisible();

                // new selection
                await page.getByTestId('data-format-type-value-' + targetFormatType.id).click();

                if (targetFormatType.id === FORMAT_TYPE_NO_VALUE_ID || targetFormatType.id === FORMAT_TYPE_FREE_TEXT_ID) {
                    await expect(page.getByTestId('formatTypeValueAmount').locator(INPUT)).not.toBeEditable();
                    await expect(page.getByTestId('formatTypeValueDefinition').locator(inputLocator)).not.toBeEditable();
                }

               await fillSamFactoryFields(page, {
                   fillMandatoryFieldsAutomatically: false,
                   summary: 'Summary',
                   explanation: 'Explanation',
                   targetDate: getSameDateInNextYear(),
               })

                if ([FORMAT_TYPE_SELECT_FROM_LIST_ID, FORMAT_TYPE_REGEX_ID].includes(targetFormatType.id)) {
                    const fillOptions: SamFactoryFillProps = {
                        fillMandatoryFieldsAutomatically: false,
                        valueAmount: targetFormatType.id === FORMAT_TYPE_SELECT_FROM_LIST_ID ? '1' : undefined,
                        valueDefinitionSelectFromList: targetFormatType.id === FORMAT_TYPE_SELECT_FROM_LIST_ID ? '^d+.d{4}$' : undefined,
                        valueDefinition: targetFormatType.id === FORMAT_TYPE_REGEX_ID ? '^d+.d{4}$' : undefined
                    };
                    await fillSamFactoryFields(page, fillOptions);
                }

                await submitAndValidateState(page, targetFormatType);
            });
        }
    }

    test('GIVEN RegEx format type in last revision - THEN other format type will be selectable', async ({page}) => {
        await page.goto(`/sam-detail/${SAM_REVISION_ID_ACTIVE_CLOSED_REGEX}`);

        await verifyPreconditions(page, 'RegEx');

        // Revise
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        // Hit "EDIT"
        await page.getByTestId('confirmation-dialog-left-button').click();

        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_REGEX}`));

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            summary: 'summary',
            explanation: 'explanation',
            targetDate: getSameDateInNextYear(),
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY,
        });

    });
});

async function submitAndValidateState(page: Page, targetFormatType: FormatType) {
    await page.getByTestId('submit-button').click();
    await expect(page).toHaveURL(/.*sam-detail/);
    await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue('new');
    await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue('in Progress');
    await expect(page.getByTestId('samFormatTypeId').getByRole('combobox')).toHaveText(targetFormatType.nameEn);
}