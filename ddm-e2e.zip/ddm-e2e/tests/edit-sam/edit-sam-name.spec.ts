import {expect, test} from "@playwright/test";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

const SAM_UUID_ACTIVE_CLOSED_1: string = 'db13938c-8a93-4822-a5a0-7b106f28d2c7';
const SAM_ID_ACTIVE_CLOSED_1: string = 'ASC.0006';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit SAM nameDe and nameEn', () => {
    test('GIVEN SAM is revised and edited - THEN nameDe and nameEn are editable and changes are saved', async ({page}) => {
        const EDITED_SAM_NAME_1: string = 'EditedSAMName1:EditedSAMName1';
        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_1);

        // Hit 'Revise' button then hit 'Edit' button in dialog
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-left-button').click();
        // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_1}`));

        // Edit SAM nameDe and nameEn
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            summary: 'summary',
            explanation: 'explanation',
            targetDate: getSameDateInNextYear(),
            nameDe: EDITED_SAM_NAME_1,
            nameEn: EDITED_SAM_NAME_1
        })

        // Submit and verify edit changes
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            nameDe: EDITED_SAM_NAME_1,
            nameEn: EDITED_SAM_NAME_1
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            nameDe: EDITED_SAM_NAME_1,
            nameEn: EDITED_SAM_NAME_1
        })
    });
});