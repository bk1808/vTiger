import test, { expect } from "@playwright/test";
import { fillSamFactoryFields, getFeatureDataTypeRegularExpressionTestId } from "@root/tests/create-sam/utils/samCreationTestHelper";
import { SAM_FACTORY_DATA_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "@root/tests/utils/constants";
import { getSameDateInNextYear, navigateToBaseUrl, navigateToSam } from "@root/tests/utils/testHelper";
import { verifySamFactoryFields } from "@root/tests/create-sam/utils/samDetailTestHelper";

const SAM_ID_ACTIVE_CLOSED_1: string = 'ASC.0004';
const SAM_UUID_ACTIVE_CLOSED_1: string = '9c0bba19-32f0-46c0-b7ff-10785725adad';
const SAM_ID_ACTIVE_CLOSED_2: string = 'ASC.0007'; 
const SAM_UUID_ACTIVE_CLOSED_2: string = '031010fb-7541-46c0-a68a-3ebbf44a8ac7';

const FEATURE_DATA_TYPE_DATE_ID = '9';
export const DATA_SOURCE_CBC_ID: string = '1';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit SAM - Change master system - from Smaragd to another - behavior of DZ Feature', () => {
    test("GIVEN master system changes from Smaragd to CBC - THEN Option to continue DZ feature should be visible and false should be selected.", async ({page}) => {
        const SUMMARY_EDITED: string = 'Edited Summary - DZ Feature - False';
        const EXPLANATION_EDITED: string = 'Edited Explanation - DZ Feature - False';

        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_1);

        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-left-button').click();
        // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_1}`));

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            targetDate: getSameDateInNextYear(),
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.DATE,
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId('DD.MM.YYYY'),
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC
        });

        expect(page.getByTestId('dz-feature-on-smaragd')).toBeVisible()
        expect(page.getByTestId('dz-feature-yes')).toBeVisible()
        expect(page.getByTestId('dz-feature-no')).toBeVisible()
        expect(page.getByTestId('dz-feature-no').isChecked).toBeTruthy()
        
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
            targetDate: getSameDateInNextYear(),
            featureDataType: FEATURE_DATA_TYPE_DATE_ID,
            featureDataTypeRegularExpression: 'DD.MM.YYYY',
            masterDataSystem: DATA_SOURCE_CBC_ID
        });
    });

    test("GIVEN master system changes from Smaragd to CBC - THEN Option to continue DZ feature should be visible and true should be selected.", async ({page}) => {
        const SUMMARY_EDITED: string = 'Edited Summary - DZ Feature - False';
        const EXPLANATION_EDITED: string = 'Edited Explanation - DZ Feature - False';

        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_2);

        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-left-button').click();
        // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_2}`));

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            targetDate: getSameDateInNextYear(),
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.DATE,
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId('DD.MM.YYYY'),
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC
        });

        expect(page.getByTestId('dz-feature-on-smaragd')).toBeVisible()
        expect(page.getByTestId('dz-feature-yes')).toBeVisible()
        expect(page.getByTestId('dz-feature-no')).toBeVisible()
        expect(page.getByTestId('dz-feature-no').isChecked).toBeTruthy()

        await page.getByTestId('dz-feature-yes').click();

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            summary: SUMMARY_EDITED,
            explanation: EXPLANATION_EDITED,
            targetDate: getSameDateInNextYear(),
            featureDataType: FEATURE_DATA_TYPE_DATE_ID,
            featureDataTypeRegularExpression: 'DD.MM.YYYY',
            masterDataSystem: DATA_SOURCE_CBC_ID
        });
    });
});