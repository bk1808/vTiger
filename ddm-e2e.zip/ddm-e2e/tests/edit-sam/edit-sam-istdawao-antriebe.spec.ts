import {expect, test} from "@playwright/test";
import {
    getSameDateInNextYear,
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    navigateToSam
} from "../utils/testHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import { SAM_FACTORY_ANTRIEBE_IDS, SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "../utils/constants";

const SAM_UUID_ACTIVE_CLOSED_1: string = 'db13938c-8a93-4822-a5a0-7b106f28d2c7';
const SAM_ID_ACTIVE_CLOSED_1: string = 'ASC.0006';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Edit SAM antriebe type', () => {
    test.skip('GIVEN SAM with ISTDaWo is revised and edited - THEN antriebe is editable and changes can be saved', async ({page}) => {
        await navigateToSam(page, SAM_ID_ACTIVE_CLOSED_1);

        // Hit 'Revise' button then hit 'Edit' button in dialog
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-left-button').click();
        // // Redirecting to Edit View
        await expect(page).toHaveURL(new RegExp(`/sam-edit/${SAM_UUID_ACTIVE_CLOSED_1}`));

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.ISTDAWO,
            summary: 'summary',
            explanation: 'explanation',
            targetDate: getSameDateInNextYear(),
            antriebe:SAM_FACTORY_ANTRIEBE_IDS.DIESEL
        })

        // // Submit and verify edit changes
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            antriebe: 'Diesel'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            antriebe: 'Diesel'
        })
    });
});