import {expect, test} from "@playwright/test";
import {
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
});

test.describe('Cache sam dashboard filter in session storage', () => {
    test('GIVEN SAM dashboard - THEN default filter are applied', async ({page}) => {
        await expect(page.getByTestId('Release Status-selected-undefined')).toBeVisible();
        await expect(page.getByTestId('Release Status-selected-new')).toBeVisible();
        await expect(page.getByTestId('Release Status-selected-active')).toBeVisible();
    });
});
