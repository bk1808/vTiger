export type FilterProps = {
    filterToSelect: string;
    filterInputId: string;
    input: string;
}
