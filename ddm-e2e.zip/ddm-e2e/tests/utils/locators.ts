export const INPUT: string = 'div > input'
export const TEXTAREA: string = 'div > textarea'