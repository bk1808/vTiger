import {expect, Page} from "@playwright/test";
import {BLUE, RED} from "./constants";
import {INPUT} from "./locators";

export async function verifyIsVisibleAndHasRedColorByText(page: Page, text: string, index: number = 0) {
    await verifyIsVisibleByText(page, text, index);
    await verifyHasColorByText(page, text, index, RED);
}

export async function verifyIsVisibleAndHasBlueColorByText(page: Page, text: string, index: number = 0) {
    await verifyIsVisibleByText(page, text, index);
    await verifyHasColorByText(page, text, index, BLUE);
}

export async function verifyIsVisibleByText(page: Page, text: string, index: number = 0) {
    await expect(page.getByText(text).nth(index)).toBeVisible();
}

export async function verifyHasColorByText(page: Page, validationMessageNameDe: string, index: number = 0, color: string) {
    await expect(page.getByText(validationMessageNameDe).nth(index)).toHaveCSS('color', color);
}

export async function verifyLabelHasRedColorById(page: Page, testId: string) {
    await expect(page.getByTestId(testId).locator('label')).toHaveCSS('color', RED);
}

export async function verifyIsEditableById(page: Page, testId: string) {
    await expect(page.getByTestId(testId)).toBeEditable();
}

export async function verifyIsEditableAndHasRedColorById(page: Page, testId: string) {
    await verifyIsEditableById(page, testId);
    await verifyLabelHasRedColorById(page, testId);
}

export async function verifyIsNotEditableById(page: Page, testId: string) {
    await expect(page.getByTestId(testId)).not.toBeEditable();
}

export async function verifyIsNotEditableByIdLocator(page: Page, testId: string, locator: string) {
    await expect(page.getByTestId(testId).locator(locator)).not.toBeEditable();
}

export async function verifyIsEditableByIdLocator(page: Page, testId: string, locator: string) {
    await expect(page.getByTestId(testId).locator(locator)).toBeEditable();
}

export async function verifyThatDropdownFieldIsVisibleAndDisabled(page: Page, dataTestId: string) {
    await expect(page.getByTestId(dataTestId)).toBeVisible();
    await expect(page.getByTestId(dataTestId).getByRole('combobox')).toBeDisabled();
}

export async function verifyThatFreeTextFieldIsVisibleAndDisabled(page: Page, dataTestId: string) {
    await expect(page.getByTestId(dataTestId)).toBeVisible();
    await expect(page.getByTestId(dataTestId).locator(INPUT)).toBeDisabled();
}