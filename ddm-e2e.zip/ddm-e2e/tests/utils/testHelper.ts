import {expect, Page} from "@playwright/test";
import {FilterProps} from "./models";
import {selectDataTableItem} from "./selector";
import {INPUT} from "./locators";
import playwrightConfig from "../../playwright.config";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "./commonValidations";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {CHANGE_STATUS_CLOSED, SAM_STATUS_ACTIVE, STATUS_IN_REVIEW, STATUS_NEW} from "@root/tests/utils/constants";

export async function navigateToBaseUrl(page: Page) {
    if (playwrightConfig.use?.baseURL === undefined)
        throw new Error('playwrightConfig.use is undefined');

    const baseUrl: string = playwrightConfig.use.baseURL;
    await page.goto(baseUrl);
    await page.evaluate((url) => window.open(url, "_self"), baseUrl);
}

export async function goToSamDashBoard(page: Page) {
    // Select "SAM" from the left menu bar
    await page.getByTestId('sidebar-sam-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*sam-dashboard/);
    await expect(page.getByTestId('sam-view')).toBeVisible();
}

export async function goToSamCreateForm(page: Page) {
    // Using the "Create / New SAM" button on the left corner (See Fig.1)
    await page.getByTestId('create-sam-button').click();
    // Redirecting to the "SAM Create View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-create/);
}

export async function goToMySAMs(page: Page) {
    // Using the "My SAMs" toggle button on the left corner (See Fig.1)
    await page.getByTestId('my-sams-button').click();
    // Redirecting to the "SAM Dashboard View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-dashboard/);
}

export async function goToCreator(page: Page){
    // Using the "Creator" toggle button on the left corner (See Fig.1)
    await page.getByTestId('creator-button').click();
    // Redirecting to the "SAM Dashboard View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-dashboard/);
}
export async function goToRequester(page: Page){
    // Using the "Requester" toggle button on the left corner (See Fig.1)
    await page.getByTestId('requester-button').click();
    // Redirecting to the "SAM Dashboard View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-dashboard/);
}
export async function goToApprover(page: Page){
    // Using the "Approvwe" toggle button on the left corner (See Fig.1)
    await page.getByTestId('approver-button').click();
    // Redirecting to the "SAM Dashboard View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-dashboard/);
}

export async function goToMyObservedSAMs(page: Page) {
    // Using the "My Observed SAMs" toggle button on the left corner (See Fig.1)
    await page.getByTestId('my-observed-sams-button').click();
    // Redirecting to the "SAM Dashboard View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-dashboard/);
}

export async function goToSmaragdExport(page: Page) {
    // Select "Smaragd Export" from the left menu bar
    await page.getByTestId('sidebar-smaragd-export-button').click();
    // Redirecting to "Smaragd Export".
    await expect(page).toHaveURL(/.*smaragd-export/);
    await expect(page.getByTestId('smaragd-export-view')).toBeVisible();
}

export async function goToSamCreateAndFillAllMandatoryFieldsAndSave(page: Page, samName: string) {
    await navigateToCreateSam(page);

    await fillSamFactoryFields(page, {
        fillMandatoryFieldsAutomatically: true,
        nameDe: samName,
        nameEn: samName
    });

    await page.getByTestId('submit-button').click();
    // Redirecting to the SAM detail view page
    await expect(page).toHaveURL(/.*sam-detail/);
}

export async function useSamDashboardFilterAutocomplete(page: Page, filterProps: FilterProps) {
    // Open Filter Items dropdown
    await page.getByTestId('sam-view-filter').click();
    // Select filter
    const filterDropdownButton = page.getByTestId(filterProps.filterToSelect);
    expect(filterDropdownButton);
    await filterDropdownButton.click();

    // Click on Input Field in case it is not focused
    await page.getByTestId(filterProps.filterInputId).locator('div > input').click();
    // Enter desired Input
    await page.getByTestId(filterProps.filterInputId).locator('div > input').fill(filterProps.input);
    // Confirm input using Enter
    await page.getByTestId(filterProps.filterInputId).locator('div > input').press('Enter');
}

export async function useSamDashboardFilterMultiInput(page: Page, filterProps: FilterProps) {
    // Open Filter Items dropdown
    await page.getByTestId('sam-view-filter').click();
    // Select filter
    const filterDropdownButton = page.getByTestId(filterProps.filterToSelect);
    expect(filterDropdownButton);
    await filterDropdownButton.click();

    // Click on Input Field in case it is not focused
    await page.getByTestId(filterProps.filterInputId).click();
    // Enter desired Input
    await page.getByTestId(filterProps.filterInputId).locator('input').fill(filterProps.input);
    // Confirm input using Enter
    await page.getByTestId(filterProps.filterInputId).press('Enter');
}

export async function navigateToSam(page: Page, samId: string) {
    await goToSamDashBoard(page);

    await useSamDashboardFilterAutocomplete(page, {
        filterToSelect: "filter-feature-id",
        filterInputId: "SAM ID",
        input: samId,
    });

    const dataRow = await selectDataTableItem(page, 0);
    await expect(dataRow).toContainText(samId);
    await dataRow.click();

    await expect(page).toHaveURL(/.*sam-detail/);
}

/**
 * Filters the SAM dashboard by selecting a value from an autocomplete dropdown.
 *
 * @param page The Playwright page object
 * @param valueToFilterBy The value to filter by (entered in the input field)
 * @param filterInputChipTestId The test ID of the chip that is created after selecting a value from the dropdown
 * @param filterTestId The test ID of the filter menu button
 * @param filterInputTestId The test ID of the filter input field
 * @param valueToSelect Optional value to select from the dropdown (defaults to valueToFilterBy if not provided)
 */
export async function filterByAutoCompleteDropdown(page: Page, valueToFilterBy: string, filterInputChipTestId: string, filterTestId: string, filterInputTestId: string, valueToSelect?: string) {
    await page.getByTestId('sam-view-filter').click();
    await page.getByTestId(filterTestId).click();
    await page.getByTestId(filterInputTestId).locator(INPUT).fill(valueToFilterBy);
    await page.getByTestId(valueToSelect ?? valueToFilterBy).click();
    await expect(page.getByTestId(filterInputChipTestId)).toBeVisible();
}

/**
 * Function to filter by a text input field component in the SAM dashboard
 *
 * @param page current page in the browser
 * @param valueToFilterBy the value to filter by (entering this value in the input field)
 * @param filterInputChipTestId test id of the chip that is created after selecting a value from the dropdown
 * @param filterTestId the test id of the filter menu button
 * @param filterInputTestId the test id of the filter input field
 */
export async function filterByTextInputField(page: Page, valueToFilterBy: string, filterInputChipTestId: string, filterTestId: string, filterInputTestId: string) {
    await page.getByTestId('sam-view-filter').click();

    await page.getByTestId(filterTestId).click();
    await page.getByTestId(filterInputTestId).locator('input').fill(valueToFilterBy);
    await page.getByTestId(filterInputTestId).locator('input').press('Enter');
    await expect(page.getByTestId(filterInputChipTestId)).toBeVisible();
}

export async function verifyCreatorRequesterApprover(page: Page, creator: string, approvalRequester: string, approver: string) {
    await expect(page.getByTestId('detail-view-creator').locator(INPUT)).toHaveValue(creator);
    await expect(page.getByTestId('detail-view-approval-requester').locator(INPUT)).toHaveValue(approvalRequester);
    await expect(page.getByTestId('detail-view-approver').locator(INPUT)).toHaveValue(approver);
}

export async function submitAndVerifyAppearanceOfValidationMessage(page: Page, fieldNameTestId: string, validationMessageName: string) {
    // Press "Submit"
    await page.getByTestId('submit-button').click();

    // A red note appears below the input field. It indicates that it not fulfills the validation condition.
    await expect(page).toHaveURL(/.*sam-create/);

    await verifyIsEditableAndHasRedColorById(page, fieldNameTestId);
    await verifyIsVisibleAndHasRedColorByText(page, validationMessageName);
}

export async function goFromDetailViewToHistoryView(page: Page) {
        const newTabPromise = page.waitForEvent('popup');

        await page.getByTestId('history-button').click();
        const historyViewPage = await newTabPromise;
        await historyViewPage.waitForLoadState();

        await expect(historyViewPage).toHaveURL(/.*sam-history/);
        return historyViewPage;
}

// Reusable function to set the number of rows per page
export async function setRowsPerPage(page: Page, rows: number) {
    // Click the dropdown to open the listbox
    await page.locator('div[role="combobox"][aria-haspopup="listbox"]').click();

    // Wait for the options to be visible
    await page.waitForSelector(`li[role="option"][data-value="${rows}"]`, { state: 'visible' });

    // Click on the desired rows per page option
    await page.locator(`li[role="option"][data-value="${rows}"]`).click();

    // Verify the selection was successful
    await expect(page.locator('div[role="combobox"][aria-haspopup="listbox"]')).toHaveText(`${rows}`);
}

/**
 * Function to wait until the finite state machine (FSM) of a SAM reaches the specified status
 * @param page current page in the browser
 * @param samStatus the SAM status to wait for
 * @param changeStatus the change status to wait for
 * @param timeout the maximum time to wait for the conditions to be met
 * @param interval the interval to check the conditions
 */
export async function waitForSamStatus(page: Page, samStatus: string, changeStatus: string, timeout = 1200000, interval = 10000): Promise<boolean> {
    const startTime = Date.now();

    while (Date.now() - startTime < timeout) {
        await page.reload();

        const actualSamStatus = await page.getByTestId('detail-view-sam-status').locator(INPUT).inputValue();
        const actualChangeStatus = await page.getByTestId('detail-view-change-status').locator(INPUT).inputValue();

        if (actualSamStatus === samStatus && actualChangeStatus === changeStatus) {
            console.log(`Conditions met: SAM status is ${samStatus} and change status is ${changeStatus}.`);
            return true;
        }

        await new Promise(resolve => setTimeout(resolve, interval));
    }

    console.log(`Timeout: Conditions SAM status ${samStatus} and change status ${changeStatus} not met:`);
    return false;
}

/**
 * Function to revise a SAM by sending an approval request to Central Approval.
 *
 * @param {Page} page - The Playwright page object representing the browser page.
 */
export async function reviseSam(page: Page) {

    await page.getByTestId('Common.InReview').click();
    await page.getByRole("dialog").getByLabel('approver').fill('Devesh Mishra - [MISHRAD]');
    await page.getByTestId('approver-value-MISHRAD').click();
    await page.getByTestId('input-dialog-confirm-button').click();

    await expect(page.getByText('Approval Request successfully sent to Central Approval')).toBeVisible();
    await expect(page).toHaveURL(/.*sam-detail/);
}

export async function reviseAndVerifyStatusOfSam(page: Page, samRevisionNumber: number = 1) {
    await reviseSam(page);

    await expect(page.getByTestId('detail-view-sam-revision').locator('input')).toHaveValue(samRevisionNumber.toString());
    await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue(STATUS_NEW);
    await page.reload();
    await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue(STATUS_IN_REVIEW);

    const conditionsMetActiveClose = await waitForSamStatus(page, SAM_STATUS_ACTIVE, CHANGE_STATUS_CLOSED);
    expect(conditionsMetActiveClose).toBe(true);
}

/**
 * Generates a date that is exactly one year in the future from the current date.
 *
 * @returns {Date} A Date object representing the date one year in the future.
 */
export function getSameDateInNextYear(): Date {
    const currentDate = new Date();
    return new Date(currentDate.getFullYear() + 1, currentDate.getMonth(), currentDate.getDate());
}