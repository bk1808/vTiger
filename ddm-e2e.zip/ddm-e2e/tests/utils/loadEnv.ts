import dotenv from 'dotenv';
import path from 'path';

const isProduction: boolean = process.env.NODE_ENV === 'production';
const envFile = isProduction ? '.env.production' : '.env.local';
console.log(`Loading environment variables from ${envFile}`);
const dotenvConfigOutput = dotenv.config({ path: path.resolve(__dirname, '../../', envFile) });

if (dotenvConfigOutput.error) {
    console.error('Error loading .env file:', dotenvConfigOutput.error);
}
console.log('KAFKA_BROKERS:', process.env.KAFKA_BROKERS);

export { isProduction };