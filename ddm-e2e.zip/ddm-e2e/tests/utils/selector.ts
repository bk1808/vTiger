import {Locator, Page} from "@playwright/test";

export async function waitForLastRow(page: Page): Promise<boolean> {
    const lastRow = await page.$('.MuiDataGrid-row--lastVisible');

    if (lastRow) {
        return await lastRow.isVisible();
    }

    return false;
}


export function selectDatatableRowByIndex(page: Page, rowIndex: number): Locator {
    let selector = `tr[role="tr"][data-rowindex="${rowIndex}"]`;
    return page.locator(selector);
}


/**
 * Function to search for a specific element with optional attributes
 *
 * @param page provides methods to interact with a single tab in a Browser
 * @param role the role of the desired element
 * @param dataField the dataField of the desired element
 * @param dataColindex the dataColindex of the desired element
 * @return a locator matching the given parameters
 */
export function selectByRoleAndDataFieldAndColIndex(page: Page, role: string, dataField: string, dataColindex: number): Locator {
    let selector = `td[role="${role}"][data-field="${dataField}"][data-colindex="${dataColindex}"]`;
    return page.locator(selector);
}

/**
 * Function to select a row by Index
 *
 * @param page provides methods to interact with a single tab in a Browser
 * @param rowIndex of the DataTable row to select
 */
export async function selectDataTableItem(page: Page, rowIndex: number) {
    const selector = `tr[role="tr"][data-rowindex="${rowIndex}"]`;
    await page.waitForSelector(selector);
    return page.locator(selector);
}

/**
 * Function to search for a specific element with optional attributes
 *
 * @param page provides methods to interact with a single tab in a Browser
 * @param role the role of the desired element
 * @param dataField the dataField of the desired element
 * @param dataColindex the dataColindex of the desired element
 * @param dataRowindex the dataRowindex of the desired element
 * @return a locator matching the given parameters
 */
export function selectTableRowByRoleAndDataFieldAndColAndRowIndex(page: Page, role: string, dataField: string, dataColindex: number, dataRowindex: number): Locator {
    return selectByRoleAndDataFieldAndColIndex(page, role, dataField, dataColindex).nth(dataRowindex);
}

/**
 * Function to search for a specific element with optional attributes
 * Important! - This function already exists but there is a difference between div and td HTMLElement while selecting, therefor we create a new one
 *
 * @param page provides methods to interact with a single tab in a Browser
 * @param role the role of the desired element
 * @param dataField the dataField of the desired element
 * @param dataColindex the dataColindex of the desired element
 * @param rowIndex of the desired element
 * @return a locator matching the given parameters
 */
export function selectDIVByRoleAndDataFieldAndColAndRowIndex(page: Page, role: string, dataField: string, dataColindex: number, rowIndex: number): Locator {
    let selector = `div[role="${role}"][data-field="${dataField}"][data-colindex="${dataColindex}"]`;
    return page.locator(selector).nth(rowIndex);
}
