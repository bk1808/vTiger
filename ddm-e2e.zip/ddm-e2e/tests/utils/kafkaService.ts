import {Kafka, Consumer, Producer, KafkaMessage, logLevel, Partitioners} from 'kafkajs';
import { isProduction } from './loadEnv';
import * as fs from 'fs';

// Parse JAAS file to extract OAuth credentials
function parseJaasFile(jaasPath: string): { 
    clientId: string; 
    clientSecret: string; 
    scope: string; 
    tokenEndpoint: string;
    extensions?: Record<string, string>;
} {
    const jaasContent = fs.readFileSync(jaasPath, 'utf-8');
    
    const clientIdMatch = jaasContent.match(/clientId="([^"]+)"/);
    const clientSecretMatch = jaasContent.match(/clientSecret="([^"]+)"/);
    const scopeMatch = jaasContent.match(/scope="([^"]+)"/);
    const tokenEndpointMatch = jaasContent.match(/sasl\.oauthbearer\.token\.endpoint\.url="([^"]+)"/);
    
    // Parse extensions
    const extensions: Record<string, string> = {};
    const extensionMatches = jaasContent.matchAll(/extension_(\w+)="([^"]+)"/g);
    for (const match of extensionMatches) {
        extensions[match[1]] = match[2];
    }
    
    if (!clientIdMatch || !clientSecretMatch || !tokenEndpointMatch) {
        throw new Error('Failed to parse JAAS file: missing required fields');
    }
    
    return {
        clientId: clientIdMatch[1],
        clientSecret: clientSecretMatch[1],
        scope: scopeMatch ? scopeMatch[1] : 'openid',
        tokenEndpoint: tokenEndpointMatch[1],
        extensions: Object.keys(extensions).length > 0 ? extensions : undefined
    };
}

class KafkaService {
    private readonly kafka: Kafka;
    private readonly consumer: Consumer;
    private readonly producer: Producer;

    constructor() {
        const clientId = process.env.KAFKA_CLIENT_ID;
        if (!clientId) {
            throw new Error('KAFKA_CLIENT_ID is not defined');
        }

        const brokers = process.env.KAFKA_BROKERS;
        if (!brokers) {
            throw new Error('KAFKA_BROKERS is not defined');
        }

        if (isProduction) {
            const jaasFilePath = process.env.KAFKA_JAAS_FILE || '/var/lib/onekafka/jaas';
            
            if (!fs.existsSync(jaasFilePath)) {
                throw new Error(`JAAS file not found at ${jaasFilePath}. Ensure onekafka-secret is mounted.`);
            }
            
            const { clientId: oauthClientId, clientSecret, scope, tokenEndpoint, extensions } = parseJaasFile(jaasFilePath);

            console.log('OneKafka OAuth config:', {
                tokenEndpoint,
                clientId: oauthClientId,
                scope,
                extensions,
                broker: brokers
            });

            this.kafka = new Kafka({
                clientId,
                brokers: brokers.split(','),
                ssl: {
                    rejectUnauthorized: false,
                },
                sasl: {
                    mechanism: 'oauthbearer',
                    oauthBearerProvider: async () => {
                        console.log('Fetching OAuth token from:', tokenEndpoint);
                        const response = await fetch(tokenEndpoint, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: new URLSearchParams({
                                grant_type: 'client_credentials',
                                client_id: oauthClientId,
                                client_secret: clientSecret,
                                scope: scope,
                            }),
                        });
                        
                        console.log('Token response status:', response.status, response.statusText);
                        
                        if (!response.ok) {
                            const errorText = await response.text();
                            console.error('Token fetch failed:', errorText);
                            throw new Error(`Failed to fetch OAuth token: ${response.statusText} - ${errorText}`);
                        }
                        
                        const data = await response.json();
                        console.log('Token received, expires in:', data.expires_in);
                        
                        // Return token with extensions if present
                        const result: any = {
                            value: data.access_token,
                        };
                        
                        if (extensions) {
                            result.extensions = extensions;
                            console.log('Including OAuth extensions:', extensions);
                        }
                        
                        return result;
                    },
                },
                logLevel: logLevel.INFO,
            });
        } else {
            this.kafka = new Kafka({
                clientId,
                brokers: brokers.split(','),
                ssl: process.env.KAFKA_SSL === 'true',
                logLevel: logLevel.INFO,
            });
        }

        this.consumer = this.kafka.consumer({groupId: process.env.KAFKA_GROUP_ID ?? 'test-group'});
        this.producer = this.kafka.producer({
            createPartitioner: Partitioners.LegacyPartitioner,
        });
    }

    // Connect to Kafka brokers
    async connect() {
        console.log('Connecting to Kafka...');
        await this.consumer.connect();
        await this.producer.connect();
        console.log('Connected to Kafka!');
    }

    // Disconnect from Kafka
    async disconnect() {
        console.log('Disconnecting from Kafka...');
        await this.consumer.disconnect();
        await this.producer.disconnect();
        console.log('Disconnected from Kafka!');
    }

    // Read all messages from the specified topic
    async readMessages(topic: string, timeout: number = 5000, readFromBeginning: boolean = false): Promise<KafkaMessage[]> {
        const messages: KafkaMessage[] = [];
        let messageReceived = false;

        console.log(`Subscribing to topic: ${topic}`);
        await this.consumer.subscribe({ topic: topic, fromBeginning: readFromBeginning });

        const timeoutPromise = new Promise<KafkaMessage[]>((resolve) => {
            setTimeout(() => {
                resolve(messages);
            }, timeout);
        });

        const consumerPromise = new Promise<void>((resolve) => {
            (async () => {
                await this.consumer.run({
                    eachMessage: async ({ message }) => {
                        console.log('Message received:', {
                            key: message.key?.toString(),
                            value: message.value?.toString(),
                            headers: message.headers,
                        });
                        messages.push(message);
                        messageReceived = true;
                    },
                    autoCommit: false,
                });
                // Wait until at least one message is received
                while (!messageReceived) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
                resolve();
            })();
        });

        await Promise.race([consumerPromise, timeoutPromise]);
        return messages;
    }


    // Send a message to the specified topic
    async sendMessage(topic: string, key: string, value: string): Promise<void> {
        try {
            console.log(`Sending message to ${topic}:`, value);
            await this.producer.send({
                topic: topic,
                messages: [
                    { key: key, value: value },
                ],
            });
            console.log('Message sent!');
        } catch (error) {
            console.error('Error sending message:', error);
        }
    }
}

export { KafkaService };