export const RED: string = 'rgb(217, 33, 33)';
export const BLACK: string = 'rgba(0, 0, 0, 0.6)';
export const BLUE: string = 'rgb(0, 0, 255)';

export const PID_USER: string = "PIDB224";

export const KAFKA_SAM_REVISION_TEST_TOPIC: string = 'ddm.dev_test.samrevision';
export const KAFA_DISCIPLINE_TEST_TOPIC: string = 'ddm.dev_test.discipline';

export const STATUS_NEW: string = "new";
export const SAM_STATUS_ACTIVE: string = "active";
export const SAM_STATUS_INACTIVE: string = "inactive";
export const CHANGE_STATUS_CLOSED: string = "closed";
export const STATUS_IN_PROGRESS: string = "in Progress";
export const STATUS_IN_REVIEW = 'in Review';
export const STATUS_APPROVED = 'approved';

export const SYSTEM_AFFILIATION_ABBREVIATION: string = 'CPCM';
export const KGUEN_IN_RANGE: string = '901-01';

export const TEXT_WITH_600_CHARACTERS = 'One morning, when Gregor Samsa woke ' +
    'from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his ' +
    'armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and ' +
    'divided by arches into stiff sections. The bedding was hardly able to cover it and seemed ready to slide ' +
    'off any moment. His many legs, pitifully thin compared with the size of the rest of him, waved about ' +
    'helplessly as he looked. Whats happened to me? he thought. It wasnt a dream. His room, a proper human' +
    'room although a little too small, lay peacefully be from troubled dreams, he found himself transformed ' +
    'in his bed into a horrible vermin. He lay on his';

export const TEXT_WITH_31_CHARS: string = 'Lorem ipsum dolor sit amet, con';

export const TEXT_WITH_301_CHARS: string = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed' +
    ' diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem';

export const TEXT_WITH_1001_CHARS: string = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna ' +
    'aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ' +
    'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam ' +
    'et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy ' +
    'eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus ' +
    'est Lorem ipsum dolor sit amet. \n' +
    '\n' +
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu fe'

export const LOREM_IPSUM_295: string = 'Lorem:ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor' +
    'invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores' +
    'et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.';

export const LOREM_IPSUM_101: string = 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut la';

export const FORMAT_TYPE_FREE_TEXT_ID: number = 1;

export const FORMAT_TYPE_FREE_TEXT = 'Free Text Not Empty';

export const FORMAT_TYPE_SELECT_FROM_LIST_ID: number = 2;

export const FORMAT_TYPE_SELECT_FROM_LIST = 'Select From List';

export const FORMAT_TYPE_REGEX_ID: number = 3;

export const FORMAT_TYPE_REGEX = 'RegEx';

export const FORMAT_TYPE_NO_VALUE_ID: number = 4;

export const FORMAT_TYPE_NO_VALUE = 'no value';

export const DATA_SOURCE_SMARAGD_ID: number = 8;

export const SAM_TYPE_DIRECT_ID: number = 1;

export const DATA_TYPE_UNDEFINED_ID: number = 10;

export const SAM_TYPE_LEG_VERF_COMPONENT_ID: number = 6;
export const SAM_TYPE_LEG_VERF_VEHICLE_ID: number = 7;
export const DATA_TYPE_NUMERICAL_VALUE_ID: number = 1;
export const DATA_TYPE_NUMBER_ID: number = 12;
export const FEATURE_DATA_TYPE_DOCUMENT_ID: number = 11;
export const FORMAT_TYPE_BLANK_ID: number = -1;

/**
 * Data-TestIds used within the SAM_FACTORY using the SYSTEM_NAME Dropdown
 */
export const SAM_FACTORY_SYSTEM_NAME_IDS = {
    UNDEFINED: 'system-name-value-0',
    CBC: 'system-name-value-1',
    CERTUS: 'system-name-value-2',
    ISTDAWO: 'system-name-value-3',
    WISO: 'system-name-value-4',
    SMARAGD_CERT_XML: 'system-name-value-5',
    SMARAGD: 'system-name-value-8'
};

/**
 * Data-TestIds used within the SAM_FACTORY using the RULE_TYPE Dropdown
 */
export const RULE_TYPE_IDS = {
    UNDEFINED: "rule-type-value-4", // Cluster "undefined" should be selected
    FEATURE_TRANSFER: "rule-type-value-6", // Cluster "feature transfer function" should be selected
    LOCATION: "rule-type-value-12", // Cluster "feature transfer function" should be selected
    EXISTING: "rule-type-value-3", // Cluster "feature transfer function" should be selected
    ADDITION: "rule-type-value-7", // Cluster "mathematical function arithmetic" should be selected
    DEVIDE: "rule-type-value-10", // Cluster "mathematical function arithmetic" should be selected
    MIDVALUE: "rule-type-value-11", // Cluster "mathematical function arithmetic" should be selected
    MULTIPLY: "rule-type-value-9", // Cluster "mathematical function arithmetic" should be selected
    SUBSTRACT: "rule-type-value-8", // Cluster "mathematical function arithmetic" should be selected
    COUNT: "rule-type-value-2", // Cluster "mathematical function statistics" should be selected
    SUBSET: "rule-type-value-5", // Cluster "mathematical function statistics" should be selected
    UNION: "rule-type-value-1", // Cluster "mathematical function statistics" should be selected
};

/**
 * Data-TestIds used within the SAM_FACTORY using the SAM_TYPE Dropdown
 */
export const SAM_FACTORY_SAM_TYPE_IDS = {
    DIRECT: 'samTypeId-1',
    DERIVED: 'samTypeId-2',
    SUPER_CERT_XML: 'samTypeId-3',
    PNOC_CERTUS: 'samTypeId-4',
    UNDEFINED: 'samTypeId-5',
    LEG_VERF_COMPONENT: 'samTypeId-6',
    LEG_VERF_VEHICLE: 'samTypeId-7',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the Condition Dropdown
 */
export const SAM_FACTORY_CONDITION_IDS = {
    MAIN_MODULE: 'derivedFeatureCondition-value-1',
    MODULE: 'derivedFeatureCondition-value-2',
    POS: 'derivedFeatureCondition-value-4',
    PV: 'derivedFeatureCondition-value-5',
    SUB_MODULE: 'derivedFeatureCondition-value-3',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the Condition Dropdown
 */
export const SAM_FACTORY_CLUSTER_IDS = {
    UNDEFINED: 'derivedFeatureCluster-value-1',
    FEATURE_TRANSFER_FUNCTION: 'derivedFeatureCluster-value-6',
    IF_THEN_FUNCTION: 'derivedFeatureCluster-value-5',
    MATHEMATICAL_FUNCTION_ARITHMETIC: 'derivedFeatureCluster-value-3',
    MATHEMATICAL_FUNCTION_STATISTICS: 'derivedFeatureCluster-value-4',
    QUANTITY_FUNCTION: 'derivedFeatureCluster-value-2',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the DATA_FORMAT_TYPE Dropdown
 */
export const SAM_FACTORY_DATA_FORMAT_TYPE_IDS = {
    EMPTY: 'data-format-type-empty',
    FREE_TEXT_NOT_EMPTY: 'data-format-type-value-1',
    NO_VALUE: 'data-format-type-value-4',
    REG_EX: 'data-format-type-value-3',
    SELECT_FROM_LIST: 'data-format-type-value-2'
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature DATA_TYPE Dropdown
 */
export const SAM_FACTORY_DATA_TYPE_IDS = {
    DATE: 'featureDataType-9',
    UNDEFINED: 'featureDataType-10',
    NUMBER: 'featureDataType-12',
    DOCUMENT: 'featureDataType-11',
    FEATURE_DATA_TYPE_REGULAR_EXPRESSION: 'featureDataTypeRegularExpression',
    NUMERICAL_VALUE: 'featureDataType-1',
    NUMERICAL_INTERVAL: 'featureDataType-2'
}

/**
 * Data-TestIds used within the SAM_FACTORY using the SAM_TYPE Dropdown
 */
export const SAM_FACTORY_SYSTEM_TYPE_IDS = {
    DIRECT: 'samTypeId-1',
    DERIVED: 'samTypeId-2',
    SUPER_CERT_XML: 'samTypeId-3',
    PNOC_CERTUS: 'samTypeId-4',
    UNDEFINED: 'samTypeId-5',
    LEG_VERF_COMPONENT: 'samTypeId-6',
    LEG_VERF_VEHICLE: 'samTypeId-7',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature DATA_TYPE Dropdown
 */
export const SAM_FACTORY_APPLICATION_LAYER_IDS = {
    BOM_PART_POSV: 'derivedFeatureApplicationLayer-value-1',
    TOTAL_LAYER: 'derivedFeatureApplicationLayer-value-2',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature DISCIPLINE Dropdown
 */
export const SAM_FACTORY_DISCIPLINE_IDS = {
    ALCOHOL_INTERLOCK_DE: 'disciplineDe-3',
    TUEREN_SCHLOESSER_SCHARNIERE: 'disciplineDe-55',
    DOOR_LOCKS_AND_HINGES: 'disciplineEn-55',
    CRASH_DE: 'disciplineDe-9',
    HEATING_VENTILATION_AIR_CONDITIONING_DE: 'disciplineDe-28',
    MOTORHAUBENVERRIEGELUNG: 'disciplineDe-39',
    ABSCHLEPPEINRICHTUNG: 'disciplineDe-1',
}


/**
 * Data-TestIds used within the SAM_FACTORY using the feature CERTIFICATION Market Dropdown
 */
export const SAM_FACTORY_CERTIFICATION_MARKET_IDS = {
    INDIA_DE: 'certificationMarketDe-8',
    INDIA_EN:'certificationMarketEn-8',
    KOREA_DE: 'certificationMarketDe-4',
    AUSTRALIA_DE: 'certificationMarketDe-5',
    AUSTRALIA_EN: 'certificationMarketEn-5',
    CHINA_DE:'certificationMarketDe-3',
    CHINA_EN:'certificationMarketEn-3',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature Antriebe Dropdown
 */
export const SAM_FACTORY_ANTRIEBE_IDS={
    MILD_OR_FULL_HYBRID_OTTO:'antriebe-value-3',
    MILD_OR_FULL_HYBRID_DIESEL:'antriebe-value-4',
    DIESEL:'antriebe-value-2',
    OTTO: 'antriebe-value-1'
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature CERTUS MARKET Dropdown
 */
export const SAM_FACTORY_CERTUS_MARKET_IDS = {
    EU: 'certusMarket-value-4',
    CHN: 'certusMarket-value-2',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature CERTUS TOPIC Dropdown
 */
export const SAM_FACTORY_CERTUS_TOPIC_IDS = {
    LIGHTING: 'certusCertificateTopic-value-1',
    FUEL_TANK: 'certusCertificateTopic-value-5',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature CERTUS TYPE Dropdown
 */
export const SAM_FACTORY_CERTUS_TYPE_IDS = {
    TYPE_APPROVAL: 'certusCertificateType-value-Type-approval',
    CHN_MARK_CERTIFICATE: 'certusCertificateType-value-CHN-Mark-Certificate',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature CERTUS ADDITIONAL SPECIFICATION Dropdown
 */
export const SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS = {
   CERTIFICATES: 'certusAdditionalSpecification-value-5',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature CERTUS FUNCTION Dropdown
 */
export const SAM_FACTORY_CERTUS_FUNCTION_IDS = {
   CERTIFICATES: 'certusFunction-value-7',
}

/**
 * Data-TestIds used within the SAM_FACTORY using the feature LEGAL VERIFICATION DRAWING Dropdown
 */
export const SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS = {
   GE_NACHWEIS: 'legal-verification-drawing-value-1',
}