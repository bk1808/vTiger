import {expect, test} from "@playwright/test";
import {
    filterByAutoCompleteDropdown,
    goToSamCreateAndFillAllMandatoryFieldsAndSave,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Sam Revision Valid Until value field should always show \'-\'', () => {
    const VALID_UNTIL = '-';

    test('GIVEN Create Sam - History View - THEN Default Valid Until value is displayed', async ({page}) => {
        const samName: string = "TestName:";
        await goToSamCreateAndFillAllMandatoryFieldsAndSave(page, samName);

        // Select 'Sam History View' button and wait for a new browser window to open.
        const popupPromise = page.waitForEvent('popup');
        await page.getByTestId('history-button').click();
        const popup = await popupPromise;
        // The window opens on the SAM history page and the Valid Until field shows '-'.
        await expect(popup).toHaveURL(/.*sam-history/);
        await expect(popup.getByTestId('sam-revision-valid-until').locator('div > input')).toHaveValue(VALID_UNTIL);

        await popup.close();
    });

    test('GIVEN SAM with status Closed - THEN Default Valid Until value is displayed', async ({page}) => {
        const SAM_WITH_STATUS_CLOSED: string = 'SRM.0001';

        await goToSamDashBoard(page);

        // Search for SAM and open detail view of this SAM
        await page.getByTestId('sidebar-sam-button').click();

        await filterByAutoCompleteDropdown(page, SAM_WITH_STATUS_CLOSED, `SAM ID-selected-${SAM_WITH_STATUS_CLOSED}`, 'filter-feature-id', 'SAM ID');

        await page.getByText(SAM_WITH_STATUS_CLOSED).nth(1).click();

        // Redirecting to the SAM detail view page
        await expect(page).toHaveURL(/.*sam-detail/);
        // SAM Revision Valid Until field shows '-'.
        await expect(page.getByTestId('sam-revision-valid-until').locator('div > input')).toHaveValue(VALID_UNTIL);

        // Select 'Sam History View' button and wait for a new browser window to open.
        const popupPromise = page.waitForEvent('popup');
        await page.getByTestId('history-button').click();
        const popup = await popupPromise;
        // The window opens on the SAM history page of the SAM and the Valid Until field shows '-'.
        await expect(popup).toHaveURL(/.*sam-history\/cd536355-643e-4e34-91d5-0b9464a429b3/);
        await expect(popup.getByTestId('sam-revision-valid-until').locator('div > input')).toHaveValue(VALID_UNTIL);

        await popup.close();
    });
});
