import {expect, test} from "@playwright/test";
import {
    SAM_FACTORY_DATA_TYPE_IDS,
    SAM_FACTORY_SYSTEM_NAME_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_DISCIPLINE_IDS
} from "../utils/constants";
import {getSameDateInNextYear, goFromDetailViewToHistoryView, navigateToBaseUrl} from "../utils/testHelper";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const DISCIPLINE_ALCOHOL_INTERLOCK_DE = 'Alcohol Interlock (AI): Alcohol Interlock (AI)';

test('Trim and remove all unnecessary spaces in all free text input fields', async ({page}) => {
    const ONE_SPACE = ' ';
    const MULTIPLE_SPACES = '      ';

    const samNameInputValue = `SAM:FREE_${MULTIPLE_SPACES}TEXT_${ONE_SPACE}FIELDS${MULTIPLE_SPACES}`;
    const samNameExpectedValue = `SAM:FREE_${ONE_SPACE}TEXT_${ONE_SPACE}FIELDS`;

    await navigateToCreateSam(page);

    // Fill in all mandatory fields and all free text fields
    // and press "Submit"
    await page.getByTestId('summary').locator('div > textarea').first().fill(MULTIPLE_SPACES + 's' + MULTIPLE_SPACES +  'um' + MULTIPLE_SPACES);

    await fillSamFactoryFields(page, {
        fillMandatoryFieldsAutomatically: false,
        summary: MULTIPLE_SPACES + 's' + MULTIPLE_SPACES +  'um' + MULTIPLE_SPACES,
        targetDate: getSameDateInNextYear(),
        explanation: MULTIPLE_SPACES + 'e' + MULTIPLE_SPACES + 'xp' + MULTIPLE_SPACES,
        responsibleDisciplineDe: SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE,
        nameDe: samNameInputValue,
        nameEn: samNameInputValue,
        featureDataType: SAM_FACTORY_DATA_TYPE_IDS.UNDEFINED,
        masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD,
        samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
        supplementalInformationDe: MULTIPLE_SPACES + 's' + MULTIPLE_SPACES + 'upplementalInformationDe' + MULTIPLE_SPACES,
        supplementalInformationEn: MULTIPLE_SPACES + 's' + MULTIPLE_SPACES + 'upplementalInformationEn' + MULTIPLE_SPACES,
        defaultValue: MULTIPLE_SPACES + 'd' + MULTIPLE_SPACES + 'efaultValue' + MULTIPLE_SPACES,
        notesOnDefaultValue: MULTIPLE_SPACES + 'n' + MULTIPLE_SPACES + 'otesOnDefaultValue' + MULTIPLE_SPACES
    })

    await page.getByTestId('submit-button').click();
    // Redirecting to the SAM detail view page
    await expect(page).toHaveURL(/.*sam-detail/);

    // All free text fields should have trimmed and reduced space values
    await verifySamFactoryFields(page, {
        nameDe: samNameExpectedValue,
        nameEn: samNameExpectedValue,
        responsibleDisciplineDe: DISCIPLINE_ALCOHOL_INTERLOCK_DE,
        summary: 's' + ONE_SPACE + 'um',
        explanation: 'e' + ONE_SPACE + 'xp',
        supplementalInformationDe: 's' + ONE_SPACE + 'upplementalInformationDe',
        supplementalInformationEn: 's' + ONE_SPACE + 'upplementalInformationEn',
        defaultValue: 'd' + ONE_SPACE + 'efaultValue',
        notesOnDefaultValue: 'n' + ONE_SPACE + 'otesOnDefaultValue'
    })

    await goFromDetailViewToHistoryView(page);
    await verifySamFactoryFields(page, {
        nameDe: samNameExpectedValue,
        nameEn: samNameExpectedValue,
        responsibleDisciplineDe: DISCIPLINE_ALCOHOL_INTERLOCK_DE,
        summary: 's' + ONE_SPACE + 'um',
        explanation: 'e' + ONE_SPACE + 'xp',
        supplementalInformationDe: 's' + ONE_SPACE + 'upplementalInformationDe',
        supplementalInformationEn: 's' + ONE_SPACE + 'upplementalInformationEn',
        defaultValue: 'd' + ONE_SPACE + 'efaultValue',
        notesOnDefaultValue: 'n' + ONE_SPACE + 'otesOnDefaultValue'
    })
});