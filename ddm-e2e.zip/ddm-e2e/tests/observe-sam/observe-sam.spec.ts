import {test, expect} from "@playwright/test";
import {goToSamDashBoard, navigateToBaseUrl} from "../utils/testHelper";

// Store initial checkbox states for first two rows
let initialCheckboxStates: boolean[] = [];

test.beforeEach(async ({page}) => {
    // Navigate to base URL and SAM dashboard before each test
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    
    // Capture initial state of first two checkboxes only
    const firstCheckbox = page.locator('tbody tr:first-child input[type="checkbox"]').first();
    const secondCheckbox = page.locator('tbody tr:nth-child(2) input[type="checkbox"]').first();
    
    initialCheckboxStates = [
        await firstCheckbox.isChecked(),
        await secondCheckbox.isChecked()
    ];
});

test.afterEach(async ({page}) => {
    // Restore initial state of first two checkboxes
    const firstCheckbox = page.locator('tbody tr:first-child input[type="checkbox"]').first();
    const secondCheckbox = page.locator('tbody tr:nth-child(2) input[type="checkbox"]').first();
    
    const checkboxes = [firstCheckbox, secondCheckbox];
    
    for (let i = 0; i < checkboxes.length; i++) {
        const currentState = await checkboxes[i].isChecked();
        const initialState = initialCheckboxStates[i];
        
        // Only toggle if state has changed
        if (currentState !== initialState) {
            await checkboxes[i].click();
        }
    }
    
    // Save the restored state if any changes were made
    const observeButton = page.getByTestId('observe-sam-button');
    if (await observeButton.isEnabled()) {
        await observeButton.click();
        await page.getByTestId('confirmation-dialog-right-button').click();
        await expect(page.getByText(/Observed SAMs updated successfully/i)).toBeVisible({timeout: 10000});
    }
});

test.describe('Observe SAM in SAM Dashboard', () => {
    test('GIVEN SAMs are available in dashboard - WHEN user selects SAMs and clicks Observe button - THEN SAMs are added to observed list', async ({page}) => {
        await expect(page.getByRole('columnheader', {name: /My Observed SAMs/i})).toBeVisible();
        const observeButton = page.getByTestId('observe-sam-button');
        await expect(observeButton).toBeDisabled();
        
        const firstCheckbox = page.locator('tbody tr:first-child input[type="checkbox"]').first();
        const secondCheckbox = page.locator('tbody tr:nth-child(2) input[type="checkbox"]').first();
        
        // Toggle first checkbox - ensure it's in the opposite state
        if (await firstCheckbox.isChecked()) {
            await firstCheckbox.uncheck();
        }
        else await firstCheckbox.check();
        
        await expect(observeButton).toBeEnabled();
        
        // Toggle second checkbox - ensure it's in the opposite state
        if (await secondCheckbox.isChecked()) {
            await secondCheckbox.uncheck();
        }
        else await secondCheckbox.check();
        
        // Observe button should still be enabled (multiple SAMs selected)
        await expect(observeButton).toBeEnabled();
        await observeButton.click();
        
        await expect(page.getByTestId('confirmation-dialog-title')).toBeVisible();
        await expect(page.getByTestId('confirmation-dialog-content')).toContainText(/observe|add to observed/i);
        await page.getByTestId('confirmation-dialog-right-button').click();
        await expect(page.getByText(/Observed SAMs updated successfully/i)).toBeVisible({timeout: 10000});
        
        await expect(observeButton).toBeDisabled();
    });
    
    test('GIVEN SAMs are selected - WHEN user cancels observation dialog - THEN SAMs remain selected and not observed', async ({page}) => {
        const firstCheckbox = page.locator('tbody tr:first-child input[type="checkbox"]').first();
        let state = true;
     
        // Toggle checkbox and track its new state
        if (await firstCheckbox.isChecked()) {
            await firstCheckbox.uncheck();
            state=false;
        }
        else await firstCheckbox.check();
        
        const observeButton = page.getByTestId('observe-sam-button');
        await expect(observeButton).toBeEnabled();
        await observeButton.click(); 

        await expect(page.getByTestId('confirmation-dialog-title')).toBeVisible();
        await page.getByTestId('confirmation-dialog-left-button').click();
        await expect(page.getByTestId('confirmation-dialog-title')).not.toBeVisible();
        
        // Verify checkbox maintains its state (not reverted)
        if(state)await expect(firstCheckbox).toBeChecked();
        else await expect(firstCheckbox).not.toBeChecked();
        
        // Verify observe button is still enabled (changes not saved)
        await expect(observeButton).toBeEnabled();
    });
    
    test('GIVEN no SAMs observed states are changed - THEN observe button is disabled', async ({page}) => {
        const observeButton = page.getByTestId('observe-sam-button');
        const firstCheckbox = page.locator('tbody tr:first-child input[type="checkbox"]').first();
        let state=true;

        // Toggle checkbox state and track it
        if (await firstCheckbox.isChecked()) {
            await firstCheckbox.uncheck();
            state=false;
        } else await firstCheckbox.check();

        // Verify observe button is enabled (state changed)
        await expect(observeButton).toBeEnabled();
        
        // Toggle checkbox back to original state
        if(state) await firstCheckbox.uncheck();
        else await firstCheckbox.check();

        // Verify observe button is disabled (no net change in observed state)
        await expect(observeButton).toBeDisabled();
        
    });
});
