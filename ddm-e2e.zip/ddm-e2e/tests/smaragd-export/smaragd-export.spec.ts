import {expect, test} from "@playwright/test";
import {goToSmaragdExport, navigateToBaseUrl} from "../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe("Smaragd Export", () => {
    test('GIVEN user navigates to Smaragd Export - THEN the page is displayed', async ({page}) => {
        await goToSmaragdExport(page);
    })

    test('GIVEN user is on Smaragd Export page - THEN SAM Catalog is exported successfully', async ({page}) => {

        await goToSmaragdExport(page);

        const exportButton = await page.getByTestId("download");
        await expect(exportButton).toBeVisible();
        await expect(exportButton).toBeEnabled();

        const downloadPromise = page.waitForEvent('download');
        await exportButton.click();

        await page.$eval("[data-testid=download]", (button: HTMLButtonElement) => button.disabled);
        await expect(exportButton).toBeDisabled();

        const download = await downloadPromise;
        // https://playwright.dev/docs/api/class-download
        /**
         * Returns a readable stream for a successful download
         */
        await download.createReadStream()
            .then(res => {
                expect(res);
            });
    })
})