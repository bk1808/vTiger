import { JSONSchema7 } from "json-schema";

export const SAM_PROVISION_SCHEMA: JSONSchema7 = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "SAM",
    "type": "object",
    "properties": {
        "meta": {
            "type": "object",
            "properties": {
                "schema": {
                    "type": "object",
                    "properties": {
                        "version": {
                            "type": "string"
                        }
                    },
                    "required": ["version"]
                }
            },
            "required": ["schema"]
        },
        "sam": {
            "type": "object",
            "properties": {
                "samRevisionId": {
                    "type": "integer"
                },
                "samId": {
                    "type": "string"
                },
                "featureId": {
                    "type": "string"
                },
                "nameDe": {
                    "type": "string"
                },
                "nameEn": {
                    "type": "string"
                },
                "supplementalInformationDe": {
                    "type": ["string", "null"]
                },
                "supplementalInformationEn": {
                    "type": ["string", "null"]
                },
                "featureDataType": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": "string"
                        },
                        "nameEn": {
                            "type": "string"
                        }
                    },
                    "required": ["id", "nameDe", "nameEn"]
                },
                "markets": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    },
                    "minItems": 0
                },
                "masterDataSystem": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": "string"
                        },
                        "nameEn": {
                            "type": "string"
                        }
                    },
                    "required": ["id", "nameDe", "nameEn"]
                },
                "status": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": "string"
                        },
                        "nameEn": {
                            "type": "string"
                        },
                        "objectType": {
                            "type": "string"
                        }
                    },
                    "required": ["id", "nameDe", "nameEn", "objectType"]
                },
                "notesOnDefaultValue": {
                    "type": ["string", "null"]
                },
                "defaultValue": {
                    "type": ["string", "null"]
                },
                "regulation": {
                    "type": ["string", "null"]
                },
                "change": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "summary": {
                            "type": "string"
                        },
                        "explanation": {
                            "type": "string"
                        },
                        "status": {
                            "type": "object",
                            "properties": {
                                "id": {
                                    "type": "integer"
                                },
                                "nameDe": {
                                    "type": "string"
                                },
                                "nameEn": {
                                    "type": "string"
                                },
                                "objectType": {
                                    "type": "string"
                                }
                            },
                            "required": ["id", "nameDe", "nameEn", "objectType"]
                        },
                        "targetDate": {
                            "type": "string",
                            "format": "date-time"
                        },
                        "createdAt": {
                            "type": "string",
                            "format": "date-time"
                        }
                    },
                    "required": ["id", "summary", "explanation", "status", "targetDate", "createdAt"]
                },
                "responsibleDiscipline": {
                    "type": "object",
                    "properties": {
                        "classificationId": {
                            "type": "integer"
                        },
                        "levelOneId": {
                            "type": "integer"
                        },
                        "levelTwoId": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": "string"
                        },
                        "nameEn": {
                            "type": "string"
                        },
                        "cis2Id": {
                            "type": ["integer", "null"]
                        }
                    },
                    "required": ["classificationId", "levelOneId", "levelTwoId", "nameDe", "nameEn"]
                },
                "certificationTopic": {
                    "type": ["object", "null"],
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": "string"
                        },
                        "nameEn": {
                            "type": ["string", "null"]
                        }
                    },
                    "required": ["id", "nameDe", "nameEn"]
                },
                "kguens": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "integer"
                            },
                            "kgu": {
                                "type": "string"
                            },
                            "en": {
                                "type": "string"
                            }
                        },
                    },
                    "minItems": 0
                },
                "systemAffiliations": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "integer"
                            },
                            "abbreviation": {
                                "type": "string"
                            },
                            "name": {
                                "type": "string"
                            }
                        },
                    },
                    "minItems": 0
                },
                "legalVerificationDrawings": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "integer"
                            },
                            "incDesignation": {
                                "type": "string"
                            },
                            "abbreviation": {
                                "type": "string"
                            },
                            "strongAbbreviation": {
                                "type": "string"
                            }
                        },
                    },
                    "minItems": 0
                },
                "revision": {
                    "type": "integer"
                },
                "isSamInactive": {
                    "type": "boolean"
                },
                "samFormatType": {
                    "type": ["object", "null"],
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": ["string", "null"]
                        },
                        "nameEn": {
                            "type": ["string", "null"]
                        }
                    },
                    "required": ["id", "nameDe", "nameEn"]
                },
                "valueAmount": {
                    "type": ["string", "null"]
                },
                "valueDefinition": {
                    "type": ["string", "null"]
                },
                "validFrom": {
                    "type": ["string", "null"],
                    "format": "date-time"
                },
                "validUntil": {
                    "type": ["string", "null"],
                    "format": "date-time"
                },
                "migrationDate": {
                    "type": ["string", "null"],
                    "format": "date-time"
                },
                "sourceSystem": {
                    "type": ["string", "null"]
                },
                "creator": {
                    "type": ["string", "null"]
                },
                "approvalRequester": {
                    "type": ["string", "null"]
                },
                "approver": {
                    "type": ["string", "null"]
                },
                "samType": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "nameDe": {
                            "type": ["string", "null"]
                        },
                        "nameEn": {
                            "type": ["string", "null"]
                        }
                    },
                    "required": ["id", "nameDe", "nameEn"]
                },
                "derivedFeature": {
                    "type": ["object", "null"],
                    "properties": {
                        "ruleType": {
                            "type": ["object", "null"],
                            "properties": {
                                "id": {
                                    "type": "integer"
                                },
                                "nameDe": {
                                    "type": ["string", "null"]
                                },
                                "nameEn": {
                                    "type": ["string", "null"]
                                },
                                "abbreviation": {
                                    "type": ["string", "null"]
                                },
                                "cluster": {
                                    "type": ["object", "null"],
                                    "properties": {
                                        "id": {
                                            "type": "integer"
                                        },
                                        "nameDe": {
                                            "type": ["string", "null"]
                                        },
                                        "nameEn": {
                                            "type": ["string", "null"]
                                        }
                                    },
                                    "required": ["id", "nameDe", "nameEn"]
                                }
                            },
                            "required": ["id", "nameDe", "nameEn", "abbreviation", "cluster"]
                        },
                        "explanation": {
                            "type": ["string", "null"]
                        },
                        "fieldValues": {
                            "type": ["object", "null"],
                            "properties": {
                                "outputValue": {
                                    "type": ["string", "null"]
                                },
                                "position": {
                                    "type": ["string", "null"]
                                },
                                "delimiter": {
                                    "type": ["string", "null"]
                                },
                                "condition": {
                                    "type": ["object", "string", "null"],
                                    "properties": {
                                        "id": { "type": "integer" },
                                        "nameDe": { "type": ["string", "null"] },
                                        "nameEn": { "type": ["string", "null"] }
                                    },
                                    "required": ["id", "nameDe", "nameEn"]
                                },
                                "conditionValue": {
                                    "type": ["string", "null"]
                                },
                                "input1": {
                                    "type": ["string", "null"]
                                },
                                "input2": {
                                    "type": ["string", "null"]
                                },
                                "applicationLayer": {
                                    "type": ["object", "null"],
                                    "properties": {
                                        "id": {
                                            "type": "integer"
                                        },
                                        "nameDe": {
                                            "type": ["string", "null"]
                                        },
                                        "nameEn": {
                                            "type": ["string", "null"]
                                        }
                                    },
                                    "required": ["id", "nameDe", "nameEn"]
                                }
                            },
                            "required": ["input1", "applicationLayer"]
                        }
                    },
                    "required": ["ruleType", "explanation", "fieldValues"]
                },
                "certus": {
                    "type": ["object", "null"],
                    "properties": {
                        "market": {
                            "type": ["object", "null"],
                            "properties": {
                                "id": {
                                    "type": "integer"
                                },
                                "name": {
                                    "type": ["string", "null"]
                                }
                            },
                            "required": ["id", "name"]
                        },
                        "certificateTypes": {
                            "type": "array",
                            "items": {
                                "type": ["object", "null"],
                                "properties": {
                                    "id": {
                                        "type": "integer"
                                    },
                                    "type": {
                                        "type": ["string", "null"]
                                    }
                                },
                                "required": ["id", "type"]
                            }
                        },
                        "certificateTopic": {
                            "type": ["object", "null"],
                            "properties": {
                                "id": {
                                    "type": "integer"
                                },
                                "nameDe": {
                                    "type": ["string", "null"]
                                },
                                "nameEn": {
                                    "type": ["string", "null"]
                                }
                            },
                            "required": ["id", "nameDe", "nameEn"]
                        },
                        "additionalSpecification": {
                            "type": ["object", "null"],
                            "properties": {
                                "id": {
                                    "type": "integer"
                                },
                                "nameDe": {
                                    "type": ["string", "null"]
                                },
                                "nameEn": {
                                    "type": ["string", "null"]
                                },
                                "value": {
                                    "type": ["string", "null"]
                                }
                            },
                            "required": ["id", "nameDe", "nameEn", "value"]
                        }
                    },
                    "required": ["market", "certificateTypes", "certificateTopic", "additionalSpecification"]
                },
                "unit": {
                    "type": ["object", "null"],
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "value": {
                            "type": ["string", "null"]
                        }
                    },
                    "required": ["id", "value"]
                },
                "featureDataTypeRegularExpression": {
                    "type": ["object", "null"],
                    "properties": {
                        "id": {
                            "type": "integer"
                        },
                        "template": {
                            "type": ["string", "null"]
                        },
                        "value": {
                            "type": ["string", "null"]
                        }
                    },
                    "required": ["id", "template", "value"]
                }
            },
            "required": ["samRevisionId", "samId", "featureId", "nameDe", "nameEn", "supplementalInformationDe", "supplementalInformationEn", "featureDataType", "markets", "masterDataSystem", "status", "notesOnDefaultValue", "defaultValue", "change", "responsibleDiscipline", "certificationTopic", "revision", "isSamInactive", "samFormatType", "valueAmount", "validUntil", "approvalRequester", "approver", "samType", "derivedFeature", "certus", "unit", "featureDataTypeRegularExpression"]
        }
    },
    "required": ["meta", "sam"]
}

export const DISCIPLINE_SCHEMA: JSONSchema7 = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "properties": {
        "meta": {
            "type": "object",
            "properties": {
                "schema": {
                    "type": "object",
                    "properties": {
                        "version": {
                            "type": "string"
                        }
                    },
                    "required": ["version"]
                }
            },
            "required": ["schema"]
        },
        "disciplines": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {
                        "type": "integer"
                    },
                    "levelOneDiscipline": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "string"
                            },
                            "nameDe": {
                                "type": "string"
                            },
                            "nameEn": {
                                "type": "string"
                            }
                        },
                        "required": ["id", "nameDe", "nameEn"]
                    },
                    "levelTwoDiscipline": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "string"
                            },
                            "nameDe": {
                                "type": "string"
                            },
                            "nameEn": {
                                "type": "string"
                            }
                        },
                        "required": ["id", "nameDe", "nameEn"]
                    },
                    "prefix": {
                        "type": "string"
                    },
                    "certificationTopic": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "integer"
                            },
                            "nameDe": {
                                "type": "string"
                            },
                            "nameEn": {
                                "type": "string"
                            }
                        },
                        "required": ["id", "nameDe", "nameEn"]
                    },
                    "isActive": {
                        "type": "boolean"
                    },
                    "cis2Id": {
                        "type": ["string", "null", "array"],
                        "items": {
                            "type": "string"
                        }
                    }
                },
                "required": ["id", "levelOneDiscipline", "levelTwoDiscipline", "prefix", "certificationTopic", "isActive", "cis2Id"]
            }
        }
    },
    "required": ["meta", "disciplines"]
}