import test, {expect} from "@playwright/test";
import {
    STATUS_NEW,
    STATUS_IN_PROGRESS,
    CHANGE_STATUS_CLOSED,
    SAM_STATUS_INACTIVE,
    SAM_FACTORY_SYSTEM_NAME_IDS,
    DATA_SOURCE_SMARAGD_ID,
    SAM_TYPE_DIRECT_ID,
    DATA_TYPE_UNDEFINED_ID, KAFKA_SAM_REVISION_TEST_TOPIC, PID_USER
} from "../utils/constants";
import {
    getSameDateInNextYear,
    navigateToBaseUrl, reviseAndVerifyStatusOfSam, reviseSam,
    waitForSamStatus
} from "../utils/testHelper";
import {INPUT} from "@root/tests/utils/locators";
import {SAM_PROVISION_SCHEMA} from "@root/tests/full-process/utils/constants";
import {validateAndVerifySamProvision} from "@root/tests/provision/utils/testHelper";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {KafkaService} from "@root/tests/utils/kafkaService";
import {KafkaMessage} from "kafkajs";

// KafkaJS setup
const kafkaService = new KafkaService();
const postfix = Date.now();
const samName = `SAM-NAME:Test` + postfix;

test.describe('SAM Full Lifecycle', () => {

    // Setup before running the test
    test.beforeAll(async () => {
        // Connect to Kafka and subscribe to the topic
        await kafkaService.connect();

        // Wait a bit after connecting to ensure the consumer is fully subscribed
        await new Promise(resolve => setTimeout(resolve, 500)); // Adding a small delay
    });

    test('GIVEN a new SAM is created - THEN it goes through the full lifecycle from creation to inactive', async ({page}) => {
        // Set the timeout for this specific test to 5 minutes
        test.setTimeout(5 * 60 * 1000);

        await navigateToBaseUrl(page);

        // create a new sam revision
        await navigateToCreateSam(page);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: samName,
            nameEn: samName,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD,
            summary: 'summary',
            explanation: 'explanation'
        });

        await page.getByTestId('submit-button').click();

        // Redirecting to the SAM detail view page
        await expect(page).toHaveURL(/.*sam-detail/);

        await expect(page.getByTestId('detail-view-sam-revision').locator('input')).toHaveValue('1');
        await expect(page.getByTestId('detail-view-sam-status').locator('input')).toHaveValue(STATUS_NEW);
        await expect(page.getByTestId('detail-view-change-status').locator('input')).toHaveValue(STATUS_IN_PROGRESS);
        await expect(page.getByTestId('detail-view-creator').locator('input')).toHaveValue(PID_USER);

        await verifySamFactoryFields(page, {
            responsibleDisciplineDe: 'Alcohol Interlock (AI): Alcohol Interlock (AI)',
            responsibleDisciplineEn: 'Alcohol Interlock (AI): Alcohol Interlock (AI)',
            nameDe: samName,
            nameEn: samName,
            featureDataType: DATA_TYPE_UNDEFINED_ID.toString(),
            samType: SAM_TYPE_DIRECT_ID.toString(),
            summary: 'summary',
            explanation: 'explanation',
            masterDataSystem: DATA_SOURCE_SMARAGD_ID.toString(),
        })

        // Review process
        await reviseAndVerifyStatusOfSam(page);
        await expect(page.getByTestId('detail-view-approval-requester').locator('input')).toHaveValue(PID_USER);

        //read messages from kafka
        const messages: KafkaMessage[] = await kafkaService.readMessages(KAFKA_SAM_REVISION_TEST_TOPIC, 10000, true);
        console.log('Consumed messages:', messages);
        console.log('Consumed messages length:', messages.length);
        expect(messages).not.toBeNull();
        expect(messages.length).toBeGreaterThan(0);

        // define the expected SAM fields expected in the Kafka message
        const fieldPairs: Map<string, string> = new Map<string, string>([
            ["sam.nameDe", samName],
            ["sam.nameEn", samName],
            ["sam.featureDataType.id", "10"],
            ["sam.masterDataSystem.id", "8"],
            ["sam.masterDataSystem.nameDe", "Smaragd"],
            ["sam.masterDataSystem.nameEn", "Smaragd"],
            ["sam.status.id", "3"],
            ["sam.status.nameDe", "aktiv"],
            ["sam.status.nameEn", "active"],
            ["sam.status.objectType", "samRevision"],
            ["sam.responsibleDiscipline.classificationId", "3"],
            ["sam.responsibleDiscipline.levelOneId", "3"],
            ["sam.responsibleDiscipline.levelTwoId", "3"],
            ["sam.responsibleDiscipline.nameDe", "Alcohol Interlock (AI):Alcohol Interlock (AI)"],
            ["sam.responsibleDiscipline.nameEn", "Alcohol Interlock (AI):Alcohol Interlock (AI)"],
            ["sam.certificationTopic.id", "3"],
            ["sam.certificationTopic.nameDe", "Alcohol Interlock (AI)"],
            ["sam.certificationTopic.nameEn", "Alcohol Interlock (AI)"],
            ["sam.creator", PID_USER],
            ["sam.approvalRequester", PID_USER],
            ["sam.approver", "MISHRAD"],
            ["sam.samType.nameDe", "Direkt"],
            ["sam.samType.nameEn", "Direct"]
        ]);

        // Adding a small delay to wait for the message to be consumed
        await new Promise(resolve => setTimeout(resolve, 5000));
        const schemaVersion = process.env.KAFKA_SAM_PROVIDER_SCHEMA_VERSION;
        expect(await validateAndVerifySamProvision(schemaVersion,messages, SAM_PROVISION_SCHEMA, fieldPairs)).toBe(true);

        // Start Inactive process
        // click on 'revise -> set inactive'
        await page.getByTestId('Sam.DetailView.Revise.Button').click();
        await page.getByTestId('confirmation-dialog-right-button').click();

        // fill empty change fields
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            targetDate: getSameDateInNextYear(),
            summary: 'summary',
            explanation: 'explanation'
        })

        // click on submit
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-edit/);

        await expect(page.getByTestId('detail-view-sam-revision').locator('input')).toHaveValue('2');
        await expect(page.getByTestId('detail-view-sam-status').locator(INPUT)).toHaveValue(STATUS_NEW);
        await expect(page.getByTestId('detail-view-change-status').locator(INPUT)).toHaveValue(STATUS_IN_PROGRESS);

        // Review process
        await reviseSam(page);

        const conditionsMetInactiveClosed = await waitForSamStatus(page, SAM_STATUS_INACTIVE, CHANGE_STATUS_CLOSED);
        expect(conditionsMetInactiveClosed).toBe(true);
    });

    // Cleanup after the test is done
    test.afterAll(async () => {
        await kafkaService.disconnect();
    });
});