import {Page} from "@playwright/test";
import {getIsActiveInputCell, getValueInputCell} from "./selectors";
import {navigateToSystemAdministration} from "../../../common/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../common/constants";
import {INPUT} from "../../../../utils/locators";
import {SAM_FACTORY_DATA_TYPE_IDS} from "../../../../utils/constants";
import {navigateToBaseUrl} from "../../../../utils/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

export async function goToUnitTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('data-type-dashboard-button').click();
    await page.getByTestId('unit-button').click();
}

export async function fillOutAllTextFields(page: Page, value: string) {
    const valueInputCellLocator = getValueInputCell(page).locator('input');
    await valueInputCellLocator.click();
    await valueInputCellLocator.fill(value);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}

export async function addNewEntry(page: Page, input: string) {
    await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
    await fillOutAllTextFields(page, input);
}

export async function verifyInSamCreateUnit(page: Page, value: string, expectation: (page: Page) => Promise<void>) {
    await navigateToCreateSam(page);

    await page.getByTestId('featureDataTypeId').click();
    await page.getByTestId(SAM_FACTORY_DATA_TYPE_IDS.NUMBER).click();
    await page.getByTestId('unit').locator(INPUT).fill(value);
    await expectation(page);
}

export function getUnitTestId(valueInput: string) {
    return `unit-${valueInput}`;
}