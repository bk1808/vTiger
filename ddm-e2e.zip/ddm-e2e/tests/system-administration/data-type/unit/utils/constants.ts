export const UNIT_TEXT_SUCCESSFULLY_CREATED: string = 'Unit successfully created.';
export const UNIT_TEXT_SUCCESSFULLY_UPDATED: string = 'Unit successfully updated.';
export const UNIT_TEXT_SUCCESSFULLY_DELETED: string = 'Unit successfully deleted.';

export const UNIT_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY: string = "Unit must not be empty and the length must be at most 24";
export const UNIT_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Unit already exists";

export const LOREM_IPSUM_25_CHARS: string = "Lorem ipsum dolor sit ame"