import {expect, Locator, Page, test} from "@playwright/test";

import {getIsActiveInputCell, getValueInputCell} from "./utils/selectors";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {addNewEntry, fillOutAllTextFields, goToUnitTab, markCheckboxIsActivated} from "./utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {
    UNIT_TEXT_SUCCESSFULLY_CREATED,
    UNIT_TEXT_SUCCESSFULLY_DELETED,
    UNIT_TEXT_SUCCESSFULLY_UPDATED
} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToUnitTab(page);
});

test.describe('Unit created successfully', () => {
    test('GIVEN New Unit added - THEN all input fields are editable', async ({page}) => {
        const {
            valueInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(valueInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(valueInputCellLocator);
            // isActive
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Unit added - THEN Create success message appears', async ({page}) => {
        const input: string = 'A Unit';

        await addNewEntry(page, input);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_CREATED);
        await deleteEntry(page, input, UNIT_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN existing Unit in admin board - THEN Update success message appears', async ({page}) => {
        const valueInput:string = '1 Unit';
        const updateValueInput: string = 'Updated';

        await addNewEntry(page, valueInput);
        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_CREATED);

        // Update the new entry
        await page.getByTestId(`edit-button-${valueInput}`).click();
        await fillOutAllTextFields(page, updateValueInput);
        await markCheckboxIsActivated(page);

        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_UPDATED);
        await deleteEntry(page, `${updateValueInput}`, UNIT_TEXT_SUCCESSFULLY_DELETED);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const valueInputCellLocator = getValueInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        valueInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(valueInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(valueInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}