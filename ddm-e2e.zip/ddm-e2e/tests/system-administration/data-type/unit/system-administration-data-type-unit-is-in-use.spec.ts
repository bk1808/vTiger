import {expect, test} from "@playwright/test";
import {addNewEntry, getUnitTestId, goToUnitTab, markCheckboxIsActivated} from "./utils/testHelper";
import {saveEntryAndVerifySuccessMessage} from "../../common/testHelper";
import {UNIT_TEXT_SUCCESSFULLY_CREATED} from "./utils/constants";
import {
    getFeatureDataTypeRegularExpressionTestId
} from "../feature-data-type-regular-expression/common/utils/testHelper";
import {SAM_FACTORY_DATA_TYPE_IDS} from "../../../utils/constants";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await goToUnitTab(page);
});

test.describe('Create SAM with an activated Unit', () => {
    test('GIVEN SAM with Unit set - THEN Unit cannot be deleted in admin board', async ({page}) => {
        const valueInput: string = 'A Unit value';

        // Create an active Unit
        await goToUnitTab(page);
        await addNewEntry(page, valueInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_CREATED);
        // Unit can be deleted
        await expect(page.getByTestId(`delete-button-${valueInput}`)).toBeEnabled();

        // Create a SAM with the newly created Unit
        await navigateToCreateSam(page);
        await fillSamFactoryFields(page, {
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
            unit: getUnitTestId(valueInput),
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId('1,23457E+12'),
        });

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Unit cannot be deleted
        await goToUnitTab(page);
        await expect(page.getByTestId(`delete-button-${valueInput}`)).toBeDisabled();
    });
});