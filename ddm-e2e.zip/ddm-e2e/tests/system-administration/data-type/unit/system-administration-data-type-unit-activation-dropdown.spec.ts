import {expect, test, Page} from "@playwright/test";

import {
    addNewEntry, getUnitTestId,
    goToUnitTab,
    markCheckboxIsActivated,
    verifyInSamCreateUnit
} from "./utils/testHelper";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "../../common/testHelper";
import {UNIT_TEXT_SUCCESSFULLY_CREATED, UNIT_TEXT_SUCCESSFULLY_DELETED} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToUnitTab(page);
});

test.describe('Activation and Deactivation of Unit in Create SAM form', () => {
    const valueInput: string = 'AA Unit';

    test('GIVEN new activated unit -THEN unit value appears in dropdown', async ({page}) => {
        await addNewEntry(page, valueInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_CREATED);

        const verifyUnitVisibleInDropdown = async (page: Page) => expect(page.getByTestId(getUnitTestId(valueInput))).toBeVisible();
        await verifyInSamCreateUnit(page, valueInput,  verifyUnitVisibleInDropdown);

        await goToUnitTab(page);
        await deleteEntry(page, valueInput, UNIT_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN new activated unit -THEN unit value does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, valueInput);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_CREATED);

        const verifyUnitNotVisibleInDropdown = async (page: Page) => expect(page.getByTestId(getUnitTestId(valueInput))).not.toBeVisible();
        await verifyInSamCreateUnit(page, valueInput,  verifyUnitNotVisibleInDropdown);

        await goToUnitTab(page);
        await deleteEntry(page, valueInput, UNIT_TEXT_SUCCESSFULLY_DELETED);
    });
});
