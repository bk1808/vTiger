import {test} from "@playwright/test";
import {addNewEntry, goToUnitTab, markCheckboxIsActivated} from "./utils/testHelper";
import {
    LOREM_IPSUM_25_CHARS,
    UNIT_TEXT_MESSAGE_DUPLICATED_ENTRY,
    UNIT_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY,
    UNIT_TEXT_SUCCESSFULLY_CREATED, UNIT_TEXT_SUCCESSFULLY_DELETED,
} from "./utils/constants";
import {EMPTY_STRING} from "../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";

test.beforeEach(async ({page}) => {
    await goToUnitTab(page);
});

test.describe('Unit Input Validations', () => {
    test('GIVEN Unit empty - THEN Adding Unit not possible', async ({page}) => {
        await addNewEntry(page, EMPTY_STRING);
        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, UNIT_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Unit too long - THEN Adding Unit not possible', async ({page}) => {
        await addNewEntry(page, LOREM_IPSUM_25_CHARS);
        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, UNIT_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Unit duplicate - THEN Adding Unit not possible', async ({page}) => {
        const input = 'A Unit';

        await addNewEntry(page, input);
        await saveEntryAndVerifySuccessMessage(page, UNIT_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page, input);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, UNIT_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, input, UNIT_TEXT_SUCCESSFULLY_DELETED);
    });
});

