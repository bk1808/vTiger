export const NUMBER_TEXT_SUCCESSFULLY_CREATED: string = 'Number successfully created.';
export const NUMBER_TEXT_SUCCESSFULLY_UPDATED: string = 'Number successfully updated.';
export const NUMBER_TEXT_SUCCESSFULLY_DELETED: string = 'Number successfully deleted.';