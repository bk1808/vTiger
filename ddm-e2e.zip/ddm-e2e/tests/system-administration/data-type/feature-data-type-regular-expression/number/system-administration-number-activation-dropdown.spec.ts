import {expect, test, Page} from "@playwright/test";

import {
    addNewEntry, getFeatureDataTypeRegularExpressionTestId,
    markCheckboxIsActivated,
} from "../common/utils/testHelper";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "../../../common/testHelper";
import {NUMBER_TEXT_SUCCESSFULLY_CREATED, NUMBER_TEXT_SUCCESSFULLY_DELETED} from "./utils/constants";
import {goToNumberTab, verifyInSamCreateNumberValue} from "./utils/testHelper";

test.beforeEach(async ({page}) => {
    await goToNumberTab(page);
});

test.describe('Activation and Deactivation of Number in Create SAM form', () => {
    const templateInput: string = '+/- 4 Numbers';
    const valueInput: string = String.raw`^[+-]?\d{1,4}$`;
    const exampleInput: string = "1234";

    test('GIVEN new activated Number -THEN Number Value appears in dropdown', async ({page}) => {
        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, NUMBER_TEXT_SUCCESSFULLY_CREATED);

        const verifyNumberValueVisibleInDropdown = async (page: Page) => expect(page.getByTestId(getFeatureDataTypeRegularExpressionTestId(templateInput))).toBeVisible();
        await verifyInSamCreateNumberValue (page, templateInput,  verifyNumberValueVisibleInDropdown);

        await goToNumberTab(page);
        await deleteEntry(page, templateInput, NUMBER_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN new activated Number -THEN Number Value does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, templateInput, valueInput,exampleInput);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, NUMBER_TEXT_SUCCESSFULLY_CREATED);

        const verifyNumberValueNotVisibleInDropdown = async (page: Page) => expect(page.getByTestId(getFeatureDataTypeRegularExpressionTestId(templateInput))).not.toBeVisible();
        await verifyInSamCreateNumberValue(page, valueInput,  verifyNumberValueNotVisibleInDropdown);

        await goToNumberTab(page);
        await deleteEntry(page, templateInput, NUMBER_TEXT_SUCCESSFULLY_DELETED);
    });
});
