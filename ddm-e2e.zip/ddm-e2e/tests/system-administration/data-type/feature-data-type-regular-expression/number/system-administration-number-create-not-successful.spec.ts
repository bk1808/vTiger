import {test} from "@playwright/test";
import {addNewEntry, markCheckboxIsActivated} from "../common/utils/testHelper";
import {
    NUMBER_TEXT_SUCCESSFULLY_CREATED,
    NUMBER_TEXT_SUCCESSFULLY_DELETED,
} from "./utils/constants";
import {EMPTY_STRING} from "../../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../../common/testHelper";
import {
    FDTRE_EXAMPLE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    FDTRE_EXAMPLE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY,
    FDTRE_TEMPLATE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY,
    FDTRE_TEMPLATE_TEXT_MESSAGE_NO_UMLAUTS,
    FDTRE_VALUE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY, FDTRE_VALUE_TEXT_MESSAGE_NO_UMLAUTS,
    STRING_WITH_UMLAUTS
} from "../common/utils/constants";
import {goToNumberTab} from "./utils/testHelper";
import {LOREM_IPSUM_101, TEXT_WITH_31_CHARS} from "../../../../utils/constants";

test.beforeEach(async ({page}) => {
    await goToNumberTab(page);
});

 test.describe('Data Type Number Input Validations', () => {
    const templateInput: string = '+/- 4 Numbers';
    const valueInput: string = String.raw`^[+-]?\d{1,4}$`;
    const exampleInput: string = "1234";
    const aDifferentTemplateInput: string = '+/- 4 Numbers ; +/- 4 Numbers';
    const aDifferentValueInput: string = String.raw`^[+-]?\d{1,4}(;[+-]?\d{1,4})?$`;
    const aDifferentExampleInput: string = "-5678;+4321";

    test('GIVEN empty Template input - THEN Adding new Number not possible', async ({page}) => {

        await addNewEntry(page, EMPTY_STRING, valueInput, exampleInput);
        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN empty Value input - THEN Adding new Number not possible', async ({page}) => {
        await addNewEntry(page, templateInput, EMPTY_STRING, exampleInput);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN empty example input - THEN Adding new Number not possible', async ({page}) => {
        await addNewEntry(page, templateInput, valueInput, EMPTY_STRING);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_EXAMPLE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });


    test('GIVEN Template too long - THEN Adding Number not possible', async ({page}) => {
        await addNewEntry(page, LOREM_IPSUM_101, TEXT_WITH_31_CHARS, TEXT_WITH_31_CHARS);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Value too long - THEN Adding Number not possible', async ({page}) => {
        await addNewEntry(page, templateInput, LOREM_IPSUM_101, TEXT_WITH_31_CHARS);
        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Template duplicate - THEN Adding Number not possible', async ({page}) => {

        await addNewEntry(page, templateInput, valueInput , exampleInput);
        await saveEntryAndVerifySuccessMessage(page, NUMBER_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page,  templateInput, aDifferentValueInput, aDifferentExampleInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, templateInput, NUMBER_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN Value duplicate - THEN Adding Number not possible', async ({page}) => {

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await saveEntryAndVerifySuccessMessage(page, NUMBER_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page,  aDifferentTemplateInput, valueInput, aDifferentExampleInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, templateInput, NUMBER_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN example duplicate - THEN Adding Number not possible', async ({page}) => {

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await saveEntryAndVerifySuccessMessage(page, NUMBER_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page,  aDifferentTemplateInput, aDifferentValueInput, exampleInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_EXAMPLE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, templateInput, NUMBER_TEXT_SUCCESSFULLY_DELETED);
    });

     test('GIVEN Template contains umlauts - THEN Adding Number not possible', async ({page}) => {
         await addNewEntry(page, STRING_WITH_UMLAUTS, valueInput, exampleInput );
         await markCheckboxIsActivated(page);

         await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_NO_UMLAUTS);
     });

     test('GIVEN Value contains umlauts - THEN Adding Number not possible', async ({page}) => {
         await addNewEntry(page, templateInput, STRING_WITH_UMLAUTS, exampleInput);
         await markCheckboxIsActivated(page);

         await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_NO_UMLAUTS);
     });
 });