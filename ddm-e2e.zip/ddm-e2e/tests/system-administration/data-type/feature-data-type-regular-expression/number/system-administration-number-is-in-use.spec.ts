import {expect, test} from "@playwright/test";
import {addNewEntry, getFeatureDataTypeRegularExpressionTestId, markCheckboxIsActivated} from "../common/utils/testHelper";
import {saveEntryAndVerifySuccessMessage} from "../../../common/testHelper";
import {NUMBER_TEXT_SUCCESSFULLY_CREATED} from "./utils/constants";
import {goToNumberTab} from "./utils/testHelper";
import {getUnitTestId} from "../../unit/utils/testHelper";
import {SAM_FACTORY_DATA_TYPE_IDS} from "../../../../utils/constants";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await goToNumberTab(page);
});

test.describe('Create SAM with an activated Number', () => {
    test('GIVEN SAM with Number Value set - THEN Number cannot be deleted in admin board', async ({page}) => {
        const UNIT_OPTION_A: string = "A";
        const templateInput: string = '+/- 7 Numbers';
        const valueInput: string = String.raw`^[+-]?\d{1,7}$`;
        const exampleInput: string = "1234567";

        // Create an active Number
        await goToNumberTab(page);
        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, NUMBER_TEXT_SUCCESSFULLY_CREATED);
        // Number can be deleted
        await expect(page.getByTestId(`delete-button-${templateInput}`)).toBeEnabled();

        // Create a SAM with the newly created Number
        await navigateToCreateSam(page);

        await fillSamFactoryFields(page, {
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
            unit: getUnitTestId(UNIT_OPTION_A),
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId(templateInput),
        });

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Number cannot be deleted
        await goToNumberTab(page);
        await expect(page.getByTestId(`delete-button-${templateInput}`)).toBeDisabled();
    });
});