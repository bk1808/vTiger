import {test} from "@playwright/test";
import {addNewEntry, markCheckboxIsActivated} from "../common/utils/testHelper";
import {EMPTY_STRING} from "../../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../../common/testHelper";
import {goToDateTab} from "./utils/testHelper";
import {
    FDTRE_EXAMPLE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    FDTRE_EXAMPLE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY,
    FDTRE_TEMPLATE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY,
    FDTRE_TEMPLATE_TEXT_MESSAGE_NO_UMLAUTS,
    FDTRE_VALUE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY, FDTRE_VALUE_TEXT_MESSAGE_NO_UMLAUTS,
    STRING_WITH_UMLAUTS
} from "../common/utils/constants";
import {DATE_TEXT_SUCCESSFULLY_CREATED, DATE_TEXT_SUCCESSFULLY_DELETED} from "./utils/constants";
import {LOREM_IPSUM_101} from "../../../../utils/constants";

test.beforeEach(async ({page}) => {
    await goToDateTab(page);
});

 test.describe('Data Type Date Input Validations', () => {
     const templateInput: string = 'DD Mon YYYY';
     const valueInput: string = String.raw`^\d{2}[\s.-][A-Za-z]{3}[\s.-]\d{4}$`;
     const exampleInput: string = "17 Oct 2050";
     const aDifferentTemplateInput: string = 'DD-Mon-YYYY';
     const aDifferentValueInput: string = String.raw`^\d{2}\s[A-Za-z]{3}\s\d{4}$`;
     const aDifferentExampleInput: string = "05 Feb 2055";

    test('GIVEN empty Template input - THEN Adding new Date not possible', async ({page}) => {

        await addNewEntry(page, EMPTY_STRING, valueInput, exampleInput);
        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN empty Value input - THEN Adding new Date not possible', async ({page}) => {
        await addNewEntry(page, templateInput, EMPTY_STRING, exampleInput);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN empty example input - THEN Adding new Date not possible', async ({page}) => {
        await addNewEntry(page, templateInput, valueInput, EMPTY_STRING);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_EXAMPLE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Template too long - THEN Adding Date not possible', async ({page}) => {
        await addNewEntry(page, LOREM_IPSUM_101, valueInput, exampleInput);
        // await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Value too long - THEN Adding Date not possible', async ({page}) => {
        await addNewEntry(page, templateInput, LOREM_IPSUM_101, exampleInput);
        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY);
    });

    test('GIVEN Template duplicate - THEN Adding Date not possible', async ({page}) => {

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page,  templateInput, aDifferentValueInput, aDifferentExampleInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, templateInput, DATE_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN Value duplicate - THEN Adding Date not possible', async ({page}) => {

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page,  aDifferentTemplateInput, valueInput, aDifferentExampleInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, templateInput, DATE_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN Example duplicate - THEN Adding Date not possible', async ({page}) => {

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page,  aDifferentTemplateInput, aDifferentValueInput, exampleInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_EXAMPLE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, templateInput, DATE_TEXT_SUCCESSFULLY_DELETED);
    });

     test('GIVEN Template contains umlauts - THEN Adding Date not possible', async ({page}) => {
         await addNewEntry(page, STRING_WITH_UMLAUTS, valueInput, exampleInput);

         await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_TEMPLATE_TEXT_MESSAGE_NO_UMLAUTS);
     });

     test('GIVEN Value contains umlauts - THEN Adding Date not possible', async ({page}) => {
         await addNewEntry(page, templateInput, STRING_WITH_UMLAUTS, exampleInput);
         await markCheckboxIsActivated(page);

         await verifyThatEntryCannotBeSavedAndCancelEditing(page, FDTRE_VALUE_TEXT_MESSAGE_NO_UMLAUTS);
     });
 });