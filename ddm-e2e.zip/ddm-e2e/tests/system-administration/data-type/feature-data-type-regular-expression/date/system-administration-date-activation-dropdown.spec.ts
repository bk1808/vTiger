import {expect, Page, test} from "@playwright/test";

import {
    addNewEntry,
    getFeatureDataTypeRegularExpressionTestId,
    markCheckboxIsActivated,
} from "../common/utils/testHelper";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "../../../common/testHelper";
import {goToDateTab, verifyInSamCreateDateTemplate} from "./utils/testHelper";
import {DATE_TEXT_SUCCESSFULLY_CREATED, DATE_TEXT_SUCCESSFULLY_DELETED} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToDateTab(page);
});

test.describe('Activation and Deactivation of Date in Create SAM form', () => {
    const templateInput: string = 'AADate';
    const valueInput: string = 'AADate';
    const exampleInput: string = 'AADate';

    test('GIVEN new activated Date -THEN Date Template appears in dropdown', async ({page}) => {
        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);

        const verifyDateTemplateVisibleInDropdown = async (page: Page) => expect(page.getByTestId(getFeatureDataTypeRegularExpressionTestId(templateInput))).toBeVisible();
        await verifyInSamCreateDateTemplate(page, templateInput, verifyDateTemplateVisibleInDropdown);

        await goToDateTab(page);
        await deleteEntry(page, templateInput, DATE_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN new activated Date -THEN Date Template does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, templateInput, valueInput, exampleInput);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);

        const verifyNumberValueNotVisibleInDropdown = async (page: Page) => expect(page.getByTestId(getFeatureDataTypeRegularExpressionTestId(templateInput))).not.toBeVisible();
        await verifyInSamCreateDateTemplate(page, templateInput, verifyNumberValueNotVisibleInDropdown);

        await goToDateTab(page);
        await deleteEntry(page, templateInput, DATE_TEXT_SUCCESSFULLY_DELETED);
    });
});
