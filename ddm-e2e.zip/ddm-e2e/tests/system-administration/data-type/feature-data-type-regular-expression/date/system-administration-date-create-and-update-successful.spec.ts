import {expect, Locator, Page, test} from "@playwright/test";

import {getIsActiveInputCell, getTemplateInputCell, getValueInputCell} from "../common/utils/selectors";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../../common/testHelper";
import {addNewEntry, fillOutAllTextFields, markCheckboxIsActivated} from "../common/utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../common/constants";
import {goToDateTab} from "./utils/testHelper";
import {
    DATE_TEXT_SUCCESSFULLY_CREATED,
    DATE_TEXT_SUCCESSFULLY_DELETED,
    DATE_TEXT_SUCCESSFULLY_UPDATED
} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToDateTab(page);
});

test.describe('Date created successfully', () => {
    test('GIVEN Add New Date input fields - THEN all input fields are editable', async ({page}) => {
        const {
            templateInputCellLocator,
            valueInputCellLocator,
            exampleInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(templateInputCellLocator, valueInputCellLocator, exampleInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(templateInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(valueInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(exampleInputCellLocator);
            // isActive
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN Add New Date input fields - THEN Create success message appears', async ({page}) => {
        const templateInput: string = 'AADate';
        const valueInput: string = 'AADate';
        const exampleInput: string = 'AADate';

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);
        await deleteEntry(page, templateInput, DATE_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN existing Date in admin board - THEN Update success message appears', async ({page}) => {
        const templateInput: string = 'ADate';
        const valueInput: string = 'ADate';
        const exampleInput: string = 'ADate';
       
        const updateTemplateInput: string = 'AUpdatedDate';
        const updateValueInput: string = 'AUpdatedDate';
        const updateExampleInput: string = 'AUpdatedDate';

        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);

        // Update the new entry
        await page.getByTestId(`edit-button-${templateInput}`).click();
        await fillOutAllTextFields(page, updateTemplateInput, updateValueInput, updateExampleInput);
        await markCheckboxIsActivated(page);

        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_UPDATED);
        await deleteEntry(page, `${updateTemplateInput}`, DATE_TEXT_SUCCESSFULLY_DELETED);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const templateInputCellLocator = getTemplateInputCell(page, dataRowIndex).locator('input');
    const valueInputCellLocator = getValueInputCell(page, dataRowIndex).locator('input');
    const exampleInputCellLocator = getValueInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        templateInputCellLocator,
        valueInputCellLocator,
        exampleInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(templateInputCellLocator: Locator, valueInputCellLocator: Locator, exampleInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(templateInputCellLocator).not.toBeVisible();
    await expect(valueInputCellLocator).not.toBeVisible();
    await expect(exampleInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}