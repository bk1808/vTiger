import {Page} from "@playwright/test";
import {navigateToSystemAdministration} from "../../../../common/testHelper";
import {SAM_FACTORY_DATA_TYPE_IDS} from "@root/tests/utils/constants";
import {INPUT} from "@root/tests/utils/locators";
import {navigateToBaseUrl} from "@root/tests/utils/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

export async function goToDateTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('data-type-dashboard-button').click();
    await page.getByTestId('date-button').click();
}

export async function verifyInSamCreateDateTemplate(page: Page, value: string, expectation: (page: Page) => Promise<void>) {
    await navigateToCreateSam(page);

    await page.getByTestId('featureDataTypeId').click();
    await page.getByTestId(SAM_FACTORY_DATA_TYPE_IDS.DATE).click();
    await page.getByTestId(SAM_FACTORY_DATA_TYPE_IDS.FEATURE_DATA_TYPE_REGULAR_EXPRESSION).locator(INPUT).fill(value);
    await expectation(page);
}