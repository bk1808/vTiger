export const DATE_TEXT_SUCCESSFULLY_CREATED: string = 'Date successfully created.';
export const DATE_TEXT_SUCCESSFULLY_UPDATED: string = 'Date successfully updated.';
export const DATE_TEXT_SUCCESSFULLY_DELETED: string = 'Date successfully deleted.';