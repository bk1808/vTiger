import {expect, test} from "@playwright/test";
import {addNewEntry, getFeatureDataTypeRegularExpressionTestId, markCheckboxIsActivated} from "../common/utils/testHelper";
import {saveEntryAndVerifySuccessMessage} from "../../../common/testHelper";
import {goToDateTab} from "./utils/testHelper";
import {DATE_TEXT_SUCCESSFULLY_CREATED} from "./utils/constants";
import {SAM_FACTORY_DATA_TYPE_IDS} from "../../../../utils/constants";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await goToDateTab(page);
});

test.describe('Create SAM with an activated Date', () => {
    test('GIVEN SAM with Date Tenplate set - THEN Date cannot be deleted in admin board', async ({page}) => {
        const templateInput: string = 'DD MON YYYY';
        const valueInput: string = String.raw`^\d{2}\s[A-Z]{3}\s\d{4}$`;
        const exampleInput: string = "20 SEP 2060";

        // Create an active Date
        await goToDateTab(page);
        await addNewEntry(page, templateInput, valueInput, exampleInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, DATE_TEXT_SUCCESSFULLY_CREATED);
        // Date can be deleted
        await expect(page.getByTestId(`delete-button-${templateInput}`)).toBeEnabled();

        // Create a SAM with the newly created Number
        await navigateToCreateSam(page);
        await fillSamFactoryFields(page, {
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.DATE,
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId(templateInput),
        });

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Number cannot be deleted
        await goToDateTab(page);
        await expect(page.getByTestId(`delete-button-${templateInput}`)).toBeDisabled();
    });
});