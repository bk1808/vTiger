import {Page} from "@playwright/test";
import {selectDIVByRoleAndDataFieldAndColAndRowIndex} from "../../../../../utils/selector";

export function getTemplateInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "template", 0, dataRowIndex);
}

export function getValueInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "value", 1, dataRowIndex);
}

export function getExampleInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "example", 2, dataRowIndex);
}

export function getIsActiveInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 3, dataRowIndex);
}