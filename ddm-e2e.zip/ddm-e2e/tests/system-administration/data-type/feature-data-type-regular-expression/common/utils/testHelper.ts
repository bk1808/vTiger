import {Page} from "@playwright/test";
import {getExampleInputCell, getIsActiveInputCell, getTemplateInputCell, getValueInputCell} from "./selectors";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../../common/constants";

export async function fillOutAllTextFields(page: Page, template: string, value: string, example: string) {
    const templateInputCellLocator = getTemplateInputCell(page).locator('input');
    await templateInputCellLocator.click();
    await templateInputCellLocator.fill(template);

   
    const valueInputCellLocator = getValueInputCell(page).locator('input');
    await valueInputCellLocator.click();
    await valueInputCellLocator.fill(value);

    const exampleInputCellLocator = getExampleInputCell(page).locator('input');
    await exampleInputCellLocator.click();
    await exampleInputCellLocator.fill(example);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}

export async function addNewEntry(page: Page, template: string, value: string, example: string) {
    await page.waitForTimeout(1000);
    await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
    await fillOutAllTextFields(page, template, value, example);
}

export function getFeatureDataTypeRegularExpressionTestId(templateInput: string) {
    return `featureDataTypeRegularExpression-${templateInput}`;
}
