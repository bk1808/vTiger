export const FDTRE_VALUE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY: string = "Value must not be empty and the length must be at most 100";
export const FDTRE_EXAMPLE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY: string = "Example must not be empty";
export const FDTRE_TEMPLATE_TEXT_MESSAGE_MAX_LENGTH_NOT_EMPTY: string = "Template must not be empty and the length must be at most 100";
export const FDTRE_VALUE_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Value already exists";
export const FDTRE_TEMPLATE_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Template already exists";
export const FDTRE_EXAMPLE_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Example already exists";
export const FDTRE_TEMPLATE_TEXT_MESSAGE_NO_UMLAUTS: string = "Template must not contain umlauts";
export const FDTRE_VALUE_TEXT_MESSAGE_NO_UMLAUTS: string = "Value must not contain umlauts";

export const STRING_WITH_UMLAUTS: string = "ÄÖÜäöüLorem ipsum dolor sit amet, consetetur sadipscing elitr"