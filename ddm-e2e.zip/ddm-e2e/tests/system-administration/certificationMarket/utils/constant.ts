export const CERTIFICATION_MARKET_CREATE_SUCCESS="Certification Market successfully created";
export const CERTIFICATION_MARKET_DELETE_SUCCESS="Certification Market successfully deleted.";
export const CERTIFICATION_MARKET_UPDATE_SUCCESS="Certification Market successfully updated.";
export const CERTIFICATION_MARKET_NAMEDE_VALIDATION="Name (DE) must not be empty, cannot have Umlauts or be longer than 40 characters";
export const CERTIFICATION_MARKET_NAMEEN_VALIDATION="Name (EN) must not be empty, cannot have Umlauts or be longer than 40 characters";
export const CERTIFICATION_MARKET_NAMEDE_DUPLICATION="Name (DE) already exists";
export const CERTIFICATION_MARKET_NAMEEN_DUPLICATION="Name (EN) already exists";