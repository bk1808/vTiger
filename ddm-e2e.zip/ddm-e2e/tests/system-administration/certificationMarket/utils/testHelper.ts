import {expect, Page} from "@playwright/test";
import { navigateToBaseUrl } from "@root/tests/utils/testHelper";
import { navigateToSystemAdministration } from "../../common/testHelper";
import { ADD_BUTTON_DATA_TEST_ID } from "../../common/constants";
import { getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell } from "./selector";

export async function navigateToCertificationMarketSystemAdministration(page: Page) {
    // Select "System administration" in the side bar
    await page.getByTestId('sidebar-system-administration-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*administration-system/);
    await expect(page.getByTestId('system-administration-view')).toBeVisible();
    await page.getByTestId('certification-market-dashboard-button').click();
}

export async function goToCertificationMarketTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('certification-market-dashboard-button').click();
}

export async function addNewEntry(page: Page, nameEn: string, nameDe: string) {
    const addButton= page.getByTestId(ADD_BUTTON_DATA_TEST_ID);
    await addButton.click();
    await fillOutAllTextFields(page, nameDe, nameEn);
}

export async function fillOutAllTextFields(page: Page, nameDe: string, nameEn: string) {
    const nameDeInputCellLocator = getNameDeInputCell(page).locator('input');
    await nameDeInputCellLocator.click();
    await nameDeInputCellLocator.fill(nameDe);

    const nameEnInputCellLocator = getNameEnInputCell(page).locator('input');
    await nameEnInputCellLocator.click();
    await nameEnInputCellLocator.fill(nameEn);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}
