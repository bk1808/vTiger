import {expect, Locator, Page, test} from "@playwright/test";
import {addNewEntry, fillOutAllTextFields, goToCertificationMarketTab, markCheckboxIsActivated} from "./utils/testHelper";
import {getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell} from "./utils/selector";
import { ADD_BUTTON_DATA_TEST_ID } from "../common/constants";
import { checkIfFieldVisibleEditableEmpty, deleteEntry, saveEntryAndVerifySuccessMessage, verifyThatEntryCannotBeSavedAndCancelEditing } from "../common/testHelper";
import { CERTIFICATION_MARKET_CREATE_SUCCESS, CERTIFICATION_MARKET_DELETE_SUCCESS, CERTIFICATION_MARKET_UPDATE_SUCCESS } from "./utils/constant";



test.beforeEach(async ({page}) => {
    await goToCertificationMarketTab(page);
});

test.describe('Certification Market created successfully', () => {
    test('GIVEN New Certification Market added - THEN all input fields are editable', async ({page}) => {
        const {
            nameEnInputCellLocator,
            nameDeInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(nameEnInputCellLocator, nameDeInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(nameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(nameDeInputCellLocator);
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Certification Market added - THEN success message appears', async ({page}) => {
        const nameEn = 'ACertName EN 1';
        const nameDe = 'ACertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_CREATE_SUCCESS);
        await deleteEntry(page, nameEn, CERTIFICATION_MARKET_DELETE_SUCCESS);
    });

    test('GIVEN existing Certification Market in admin board - THEN Update success message appears', async ({page}) => {
        const nameEn = 'AACertMName EN 2';
        const nameDe = 'AACertMName DE 2';
        const updatedNameEn = 'AACertMUpdated Name EN';
        const updatedNameDe = 'AACertMUpdated Name DE';

        // Add initial entry
        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_CREATE_SUCCESS);

        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await markCheckboxIsActivated(page);

        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_UPDATE_SUCCESS);
        await deleteEntry(page, updatedNameEn, CERTIFICATION_MARKET_DELETE_SUCCESS);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const nameEnInputCellLocator = getNameEnInputCell(page, dataRowIndex).locator('input');
    const nameDeInputCellLocator = getNameDeInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        nameEnInputCellLocator,
        nameDeInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(nameEnInputCellLocator: Locator, nameDeInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(nameEnInputCellLocator).not.toBeVisible();
    await expect(nameDeInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}
