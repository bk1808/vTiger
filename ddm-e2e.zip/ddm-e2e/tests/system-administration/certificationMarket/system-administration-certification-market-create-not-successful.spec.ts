import {test} from "@playwright/test";
import { addNewEntry, goToCertificationMarketTab } from "./utils/testHelper";
import { verifyThatEntryCannotBeSavedAndCancelEditing } from "../common/testHelper";
import { CERTIFICATION_MARKET_NAMEDE_VALIDATION, CERTIFICATION_MARKET_NAMEEN_VALIDATION } from "./utils/constant";


test.beforeEach(async ({page}) => {
    await goToCertificationMarketTab(page);
});

test.describe('Certification Market Create validations', () => {
    test('Given NameEn empty - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = '';
        const nameDe = 'CertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEEN_VALIDATION)
    });

    test('Given NameDe empty - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = '';
        const nameEn = 'CertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEDE_VALIDATION)
    });
    
    test('Given NameDe has umlauts - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = 'Strömbeam';
        const nameEn = 'CertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEDE_VALIDATION)
    });
   
    test('Given NameEn has umlauts - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = 'Strömbeam';
        const nameDe = 'CertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEEN_VALIDATION)
    });

    test('Given NameEn is more than 40 characters - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = 'PhantomGlide X9000 | StealthBeam Pro Series by LuminX';
        const nameDe = 'CertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEEN_VALIDATION)
    });

    test('Given NameDe is more than 40 characters - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = 'PhantomGlide X9000 | StealthBeam Pro Series by LuminX';
        const nameEn = 'CertName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEDE_VALIDATION)
    });
});
