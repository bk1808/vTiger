import {test} from "@playwright/test";
import { addNewEntry, fillOutAllTextFields, goToCertificationMarketTab } from "./utils/testHelper";
import { deleteEntry, saveEntryAndVerifySuccessMessage, verifyThatEntryCannotBeSavedAndCancelEditing } from "../common/testHelper";
import { CERTIFICATION_MARKET_CREATE_SUCCESS, CERTIFICATION_MARKET_DELETE_SUCCESS, CERTIFICATION_MARKET_NAMEDE_VALIDATION, CERTIFICATION_MARKET_NAMEEN_VALIDATION } from "./utils/constant";


test.beforeEach(async ({page}) => {
    await goToCertificationMarketTab(page);
});

const nameEn = 'ACertName EN';
const nameDe = 'ACertName DE';

test.describe('Certification Market Update validations', () => {
    test('Given edited NameEn empty - THEN error message appears and saving not possible', async ({page}) => {
        const updatedNameEn = '';
        const updatedNameDe = 'AUpdated Name DE';

        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_CREATE_SUCCESS);
        
        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEEN_VALIDATION)

        await deleteEntry(page, nameEn, CERTIFICATION_MARKET_DELETE_SUCCESS);
    });

    test('Given edited NameDe empty - THEN error message appears and saving not possible', async ({page}) => {
        const updatedNameEn = 'AUpdated Name EN';
        const updatedNameDe = '';

        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_CREATE_SUCCESS);
        
        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTIFICATION_MARKET_NAMEDE_VALIDATION)

        await deleteEntry(page, nameEn, CERTIFICATION_MARKET_DELETE_SUCCESS);
    });
});
