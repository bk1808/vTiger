import {expect, test} from "@playwright/test";
import { addNewEntry, goToCertificationMarketTab } from "./utils/testHelper";
import { fillSamFactoryFields, navigateToCreateSam } from "@root/tests/create-sam/utils/samCreationTestHelper";
import { SAM_FACTORY_CERTIFICATION_MARKET_IDS, SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "@root/tests/utils/constants";
import { saveEntryAndVerifySuccessMessage } from "../common/testHelper";
import { CERTIFICATION_MARKET_CREATE_SUCCESS } from "./utils/constant";

test.beforeEach(async ({page}) => {
    await goToCertificationMarketTab(page);
});

test.describe('Use existing Certification Market in SAM creation', () => {
    test('GIVEN SAM with Certification Market set - THEN Certification Market cannot be deleted in admin board', async ({page}) => {

        await navigateToCreateSam(page);

        // Fill SAM creation form with the existing certus function
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
            certificationMarketDe:SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_DE
        });

        // Submit SAM creation form
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Navigate back to Certus Function board
        await goToCertificationMarketTab(page);
        await expect(page.getByTestId("delete-button-India")).toBeDisabled();
    });
});