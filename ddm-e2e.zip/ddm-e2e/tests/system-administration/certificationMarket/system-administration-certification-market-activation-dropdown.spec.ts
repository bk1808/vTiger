import {expect, Page, test} from "@playwright/test";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "@root/tests/system-administration/common/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";
import { addNewEntry, goToCertificationMarketTab, markCheckboxIsActivated } from "./utils/testHelper";
import { CERTIFICATION_MARKET_CREATE_SUCCESS, CERTIFICATION_MARKET_DELETE_SUCCESS } from "./utils/constant";
import { SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "@root/tests/utils/constants";


test.beforeEach(async ({page}) => {
    await goToCertificationMarketTab(page);
});

test.describe('Certification Market activation and deactivation', () => {
    const nameEn1 = 'Activation CertTest EN 1';
    const nameDe1 = 'Activation CertTest DE 1';

    const nameEn2 = 'Deactivation CertTest EN 2';
    const nameDe2 = 'Deactivation CertTest DE 2';

    test('GIVEN new activated Certification Market - THEN it appears in dropdown', async ({page}) => {
        await addNewEntry(page, nameEn1, nameDe1);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_CREATE_SUCCESS);

        const option = await createSamwithCertificationMarket(page,nameDe1)
        await expect(option).toBeVisible();
        await option.click();

        await goToCertificationMarketTab(page);
        await deleteEntry(page, nameEn1, CERTIFICATION_MARKET_DELETE_SUCCESS);
    });

    test('GIVEN new deactivated Certification Market - THEN it does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, nameEn2, nameDe2);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, CERTIFICATION_MARKET_CREATE_SUCCESS);

        const option = await createSamwithCertificationMarket(page,nameEn2)
        await expect(option).toBeHidden();

        await goToCertificationMarketTab(page);
        await deleteEntry(page, nameEn2, CERTIFICATION_MARKET_DELETE_SUCCESS);
    });
});

const createSamwithCertificationMarket = async(page:Page,name:string) => {
    await navigateToCreateSam(page);
    await page.getByTestId('samTypeId').click();
    await page.getByTestId(SAM_FACTORY_SAM_TYPE_IDS.DIRECT).click();

    await page.getByTestId('masterDataSystemId').click();
    await page.getByTestId(SAM_FACTORY_SYSTEM_NAME_IDS.CBC).click();

    await page.getByTestId('certificationMarketDe').click();
    return page.locator('li.MuiAutocomplete-option', { hasText: name });
}