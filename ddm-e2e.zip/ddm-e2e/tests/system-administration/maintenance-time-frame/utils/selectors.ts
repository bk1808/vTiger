import { Page } from '@playwright/test';
import { selectDIVByRoleAndDataFieldAndColAndRowIndex } from '../../../utils/selector';


export function getStartTimeInputCell(page: Page, dataRowIndex: number = 0) {
  return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, 'gridcell', 'startDateTime', 0, dataRowIndex);
}

export function getDurationInputCell(page: Page, dataRowIndex: number = 0) {
  return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, 'gridcell', 'duration', 1, dataRowIndex);
}

