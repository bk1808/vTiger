export const DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON: string = 'add-maintenance-time-frame-button';
export const DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON:string='edit-maintenance-time-frame-button';
export const DATA_TEST_ID_MAINTENANCE_TIME_FRAME_BANNER:string='maintenance-time-frame-banner';

export const MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED: string = 'Maintenance Time Frame successfully created.';
export const MAINTENANCE_TIME_FRAME_SUCCESSFULLY_UPDATED: string = 'Maintenance Time Frame successfully updated.';
export const MAINTENANCE_TIME_FRAME_SUCCESSFULLY_DELETED: string = 'Maintenance Time Frame successfully deleted.';

export const MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_START_DATE_TIME_WRONG: string = 'Start date time format must be MM/DD/YYYY HH:MM (a|p)m';
export const MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG: string = 'Duration must be between 0 and 24 hours';
