import { expect, Locator, Page } from '@playwright/test';
import { getDurationInputCell, getStartTimeInputCell } from './selectors';
import { DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON, DATA_TEST_ID_MAINTENANCE_TIME_FRAME_BANNER, MAINTENANCE_TIME_FRAME_SUCCESSFULLY_DELETED } from './constants';
import { navigateToSystemAdministration } from '../../common/testHelper';
import { navigateToBaseUrl } from '@root/tests/utils/testHelper';
import {format} from "date-fns";

export async function fillOutMaintenanceTimeFrame(page: Page, startdatetime: string, duration: string) {
  const date = new Date(startdatetime); 
  if(isNaN(date.getTime())){
    await page.getByTestId('mtf-date-time-picker').click();
    await page.getByTestId('mtf-date-time-picker').type(startdatetime);
    return;
  }
  await fillDateTime(page, date);

  const durationInputCellLocator = getDurationInputCell(page).locator('input');
  await durationInputCellLocator.fill(duration);
    
}

export async function fillDateTime(page: Page, date: Date) {
  await page.getByTestId('mtf-date-time-picker').click();
  await page.getByTestId('mtf-date-time-picker').fill(format(date, 'MM/dd/yyyy hh:mm a'));
}

export async function fillOutSelectedMaintenanceTimeFrame(page: Page,option:string, value: string) {
  if(option==="startdatetime"){
    const startdatetimeCellLocator = getStartTimeInputCell(page).locator('input');
    await startdatetimeCellLocator.fill(value);
  }
  else {
    const durationInputCellLocator = getDurationInputCell(page).locator('input');
    await durationInputCellLocator.fill(value);
  }
}

export async function getFutureDatetime() {
  const futureTime = new Date(Date.now() + 2 * 60 * 60 * 1000); // 2 hours later
  return format(futureTime, 'MM/dd/yyyy hh:mm a');
}

export async function checkIfFieldVisibleEditable(cell: Locator) {
    await expect(cell).toBeVisible();
    await expect(cell).toBeEditable();
}

export async function clickAddMaintenanceTimeFrameButton(page: Page,startDateTimeInput:string,durationInput:string){
  const addButton = page.getByTestId(DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON);
  await addButton.click();

  if(startDateTimeInput || durationInput) await fillOutMaintenanceTimeFrame(page, startDateTimeInput, durationInput);
}

export async function verifyEntryInDataGridAndDowntimeBanner(page: Page, expectedData: { startDateTime: string; duration: string }) {
    await page.waitForFunction(() => {
        const rows = document.querySelectorAll('.MuiDataGrid-row');
        return rows.length > 0;
    });

    const targetRow = page.locator('.MuiDataGrid-row').filter({
        has: page.locator(`[data-field="startDateTime"]:has-text("${expectedData.startDateTime}")`)
    });

    await expect(targetRow.locator('[data-field="startDateTime"]')).toHaveText(expectedData.startDateTime);
    await expect(targetRow.locator('[data-field="duration"]')).toHaveText(expectedData.duration);
    await expect(targetRow).toBeInViewport();

    await expect(page.getByTestId(DATA_TEST_ID_MAINTENANCE_TIME_FRAME_BANNER)).toBeVisible()
}

export function getMaintenanceTimeFrameInputLocators(page: Page, dataRowIndex: number = 0) {
  const startTimeInputCellLocator = getStartTimeInputCell(page, dataRowIndex).locator('input');
  const durationInputCellLocator = getDurationInputCell(page, dataRowIndex).locator('input');
  return {
    startTimeInputCellLocator,
    durationInputCellLocator
  };
}

export async function navigateToMaintenanceDashboard(page:Page) {
  await navigateToBaseUrl(page);
  await navigateToSystemAdministration(page);
  await expect(page.getByTestId('maintenance-time-frame-dashboard-button')).toBeVisible();
  await page.getByTestId('maintenance-time-frame-dashboard-button').click();
}

export async function deleteMaintenanceTimeFrame(page:Page) {
  await page.getByTestId(`delete-maintenance-time-frame-button`).click();
  await page.getByText(MAINTENANCE_TIME_FRAME_SUCCESSFULLY_DELETED).isVisible();
}