import { test,expect } from '@playwright/test';
import { clickAddMaintenanceTimeFrameButton, deleteMaintenanceTimeFrame, getFutureDatetime, getMaintenanceTimeFrameInputLocators, navigateToMaintenanceDashboard, verifyEntryInDataGridAndDowntimeBanner } from './utils/testHelper';
import { MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED } from './utils/constants';
import { checkIfFieldVisibleEditableEmpty, saveEntryAndVerifySuccessMessage, verifyThatEntryCannotBeSavedAndCancelEditing } from '../common/testHelper';
import { EMPTY_STRING } from '../common/constants';

test.beforeEach(async ({ page }) => {
    await navigateToMaintenanceDashboard(page)
});

test.describe('MaintenanceTimeFrame input validation', () => {
    test('GIVEN new MaintenanceTimeFrame input fields - THEN all input fields are editable', async ({ page }) => {
        const {
            startTimeInputCellLocator,
            durationInputCellLocator
        } = getMaintenanceTimeFrameInputLocators(page);
    
        await clickAddMaintenanceTimeFrameButton(page,EMPTY_STRING,EMPTY_STRING);
    
        await checkIfFieldVisibleEditableEmpty(startTimeInputCellLocator);
        await checkIfFieldVisibleEditableEmpty(durationInputCellLocator);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page);

        await expect(startTimeInputCellLocator).not.toBeVisible();
        await expect(durationInputCellLocator).not.toBeVisible();
    
    });

    test('GIVEN new MaintenanceTimeFrame input fields - THEN success message appears', async ({ page }) => {
        const startDateTimeInput = await getFutureDatetime();
        const durationInput = '1';
    
        await clickAddMaintenanceTimeFrameButton(page,startDateTimeInput,durationInput);
        await saveEntryAndVerifySuccessMessage(page, MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED);
        
        await verifyEntryInDataGridAndDowntimeBanner(page, {
            startDateTime: startDateTimeInput,
            duration: durationInput
        });
        await deleteMaintenanceTimeFrame(page)
    });
})