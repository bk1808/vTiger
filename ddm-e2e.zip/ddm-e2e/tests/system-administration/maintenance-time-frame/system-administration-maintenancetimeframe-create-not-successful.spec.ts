import { test } from '@playwright/test';
import { clickAddMaintenanceTimeFrameButton, getFutureDatetime, navigateToMaintenanceDashboard } from './utils/testHelper';
import { EMPTY_STRING } from '../common/constants';
import {  verifyThatEntryCannotBeSavedAndCancelEditing } from '../common/testHelper';
import { MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_START_DATE_TIME_WRONG } from './utils/constants';

test.beforeEach(async ({ page }) => {
    await navigateToMaintenanceDashboard(page)
});

test.describe('MaintenanceTimeFrame input validation', () => {

    test('Given startDateTime empty - THEN error message appears and saving not possible', async ({ page }) => {
        await clickAddMaintenanceTimeFrameButton(page,EMPTY_STRING, '2');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, '');
    });

    test('Given startDateTime wrong format - THEN error message appears and saving not possible', async ({ page }) => {
        await clickAddMaintenanceTimeFrameButton(page,'INVALID-DATE', '2');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_START_DATE_TIME_WRONG);
    });

    test('Given duration empty - THEN error message appears and saving not possible', async ({ page }) => {
        const startDateTimeInput = await getFutureDatetime();
        await clickAddMaintenanceTimeFrameButton(page, startDateTimeInput, " ");
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG);
    });

    test('Given negative duration - THEN error message appears and saving not possible', async ({ page }) => {
        const startDateTimeInput = await getFutureDatetime();
        await clickAddMaintenanceTimeFrameButton(page, startDateTimeInput, '-2');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG);
    });

    test('Given non-numeric duration - THEN error message appears and saving not possible', async ({ page }) => {
        const startDateTimeInput = await getFutureDatetime();
        await clickAddMaintenanceTimeFrameButton(page, startDateTimeInput, 'abc');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG);
    });
})