import { test } from '@playwright/test';

import { 
    saveEntryAndVerifySuccessMessage
} from '../common/testHelper'
import {
    DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON,
  DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON,
  MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED,
  MAINTENANCE_TIME_FRAME_SUCCESSFULLY_UPDATED
} from './utils/constants';

import { 
    checkIfFieldVisibleEditable, 
    clickAddMaintenanceTimeFrameButton, 
    deleteMaintenanceTimeFrame, 
    fillOutSelectedMaintenanceTimeFrame, 
    getFutureDatetime, 
    getMaintenanceTimeFrameInputLocators, 
    navigateToMaintenanceDashboard, 
    verifyEntryInDataGridAndDowntimeBanner 
} from './utils/testHelper';

test.beforeEach(async ({ page }) => {
    await navigateToMaintenanceDashboard(page);

    const addButton = page.getByTestId(DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON);
    await page.waitForTimeout(1000);
    let isEnabled = await addButton.isEnabled()
    if(isEnabled){
        const startDateTimeInput = await getFutureDatetime();
        const durationInput = '1';
            
        await clickAddMaintenanceTimeFrameButton(page,startDateTimeInput,durationInput);
        await saveEntryAndVerifySuccessMessage(page, MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED);
    }
});

test.describe('MaintenanceTimeFrame input validation', () => {
    test('GIVEN existing MaintenanceTimeFrame - THEN all input fields are editable', async ({ page }) => {
        const {
        startTimeInputCellLocator,
        durationInputCellLocator
        } = getMaintenanceTimeFrameInputLocators(page);

        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        
        await checkIfFieldVisibleEditable(startTimeInputCellLocator);
        await checkIfFieldVisibleEditable(durationInputCellLocator);
    });
      
    test('GIVEN edit button is clicked on existing MaintenanceTimeFrame  - THEN success message appears after saving', async ({ page }) => {
        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        const startDateTimeInput = await getFutureDatetime();
        const durationInput = '0.04';
    
        await fillOutSelectedMaintenanceTimeFrame(page, "startdatetime",startDateTimeInput);
        await fillOutSelectedMaintenanceTimeFrame(page, "duration",durationInput);
        await saveEntryAndVerifySuccessMessage(page, MAINTENANCE_TIME_FRAME_SUCCESSFULLY_UPDATED);
        await verifyEntryInDataGridAndDowntimeBanner(page, {
            startDateTime: startDateTimeInput,
            duration: durationInput
        });

        await deleteMaintenanceTimeFrame(page)
    });
});