import { test } from '@playwright/test';
import { clickAddMaintenanceTimeFrameButton, deleteMaintenanceTimeFrame, fillOutSelectedMaintenanceTimeFrame, getFutureDatetime, navigateToMaintenanceDashboard } from './utils/testHelper';
import { EMPTY_STRING } from '../common/constants';
import {  saveEntryAndVerifySuccessMessage, verifyThatEntryCannotBeSavedAndCancelEditing } from '../common/testHelper';
import { DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON, DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON, MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG, MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_START_DATE_TIME_WRONG } from './utils/constants';

test.beforeEach(async ({ page }) => {
    await navigateToMaintenanceDashboard(page);
    
    const addButton = page.getByTestId(DATA_TEST_ID_ADD_MAINTENANCE_TIME_FRAME_BUTTON);
    await page.waitForTimeout(1000);
    let isEnabled = await addButton.isEnabled()
    if(isEnabled){
        const startDateTimeInput = await getFutureDatetime();
        const durationInput = '1';
            
        await clickAddMaintenanceTimeFrameButton(page,startDateTimeInput,durationInput);
        await saveEntryAndVerifySuccessMessage(page, MAINTENANCE_TIME_FRAME_SUCCESSFULLY_CREATED);
    }
});

test.describe('MaintenanceTimeFrame input validation', () => {
    test('GIVEN existing MaintenanceTimeFrame with startDateTime empty - THEN error appears and saving disabled', async ({ page }) => {
        
        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        await fillOutSelectedMaintenanceTimeFrame(page, "startdatetime",EMPTY_STRING);
    
        await verifyThatEntryCannotBeSavedAndCancelEditing(
            page, 
            MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_START_DATE_TIME_WRONG
        );
    });
    
    test('GIVEN existing MaintenanceTimeFrame with startDateTime having wrong format - THEN error appears and saving disabled', async ({ page }) => {
        
        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        await fillOutSelectedMaintenanceTimeFrame(page, "startdatetime",'2025-04-23');

        await verifyThatEntryCannotBeSavedAndCancelEditing(
            page, 
            MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_START_DATE_TIME_WRONG
        );
    });

    test('GIVEN existing MaintenanceTimeFrame with duration being empty - THEN error appears and saving disabled', async ({ page }) => {

        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        await fillOutSelectedMaintenanceTimeFrame(page, "duration",EMPTY_STRING);
        
        await verifyThatEntryCannotBeSavedAndCancelEditing(
            page, 
            MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG
        );
    });

    test('GIVEN existing MaintenanceTimeFrame with duration being negative - THEN error appears and saving disabled', async ({ page }) => {

        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        await fillOutSelectedMaintenanceTimeFrame(page, "duration",'-2');
        await verifyThatEntryCannotBeSavedAndCancelEditing(
            page, 
            MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG
        );
    });
    
    test('GIVEN existing MaintenanceTimeFrame with duration as non-numeric - THEN error appears and saving disabled', async ({ page }) => {

        await page.getByTestId(DATA_TEST_ID_EDIT_MAINTENANCE_TIME_FRAME_BUTTON).click();
        await fillOutSelectedMaintenanceTimeFrame(page, "duration",'abc');
        await verifyThatEntryCannotBeSavedAndCancelEditing(
            page, 
            MAINTENANCE_TIME_FRAME_TEXT_MESSAGE_DURATION_WRONG
        );

        await deleteMaintenanceTimeFrame(page)
    });
});