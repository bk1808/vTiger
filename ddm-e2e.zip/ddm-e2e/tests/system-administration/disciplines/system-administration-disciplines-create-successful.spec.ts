import {expect, Locator, Page, test} from "@playwright/test";

import {
    getCertificationTopicNameCell, getIsActiveCell,
    getLevelOneDisciplineNameDeInputCell,
    getLevelOneDisciplineNameEnInputCell,
    getLevelTwoDisciplineNameDeInputCell, getLevelTwoDisciplineNameEnInputCell, getPrefixCell
} from "./utils/selectors";
import {
    addLevelTwoDisciplineButtonClick,
    createRandomNamesForLevelTwoAndPrefix,
    fillOutLevelTwoAndPrefixInputFieldsWhenAddingLevelTwo,
    saveDisciplineAndVerifySuccessMessage
} from "./utils/testHelper";
import {
    checkIfFieldVisibleEditableEmpty,
    navigateToSystemAdministration,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../common/testHelper";
import {
    DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON,
    DATA_TEST_ID_ADD_LEVEL_TWO_BUTTON,
    DISCIPLINE_TEXT_SUCCESSFULLY_CREATED
} from "./utils/constants";
import {navigateToBaseUrl} from "../../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const levelOneDisciplineNameDeInputCellLocator = getLevelOneDisciplineNameDeInputCell(page, dataRowIndex).locator('input');
    const levelOneDisciplineNameEnInputCellLocator = getLevelOneDisciplineNameEnInputCell(page, dataRowIndex).locator('input');
    const levelTwoDisciplineNameDeInputCellLocator = getLevelTwoDisciplineNameDeInputCell(page, dataRowIndex).locator('input');
    const levelTwoDisciplineNameEnInputCellLocator = getLevelTwoDisciplineNameEnInputCell(page, dataRowIndex).locator('input');
    const prefixInputCellLocator = getPrefixCell(page, dataRowIndex).locator('input');
    const certificationTopicNameInputCellLocator = getCertificationTopicNameCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveCell(page, dataRowIndex).locator('input');
    return {
        levelOneDisciplineNameDeInputCellLocator,
        levelOneDisciplineNameEnInputCellLocator,
        levelTwoDisciplineNameDeInputCellLocator,
        levelTwoDisciplineNameEnInputCellLocator,
        prefixInputCellLocator,
        certificationTopicNameInputCellLocator,
        isActiveInputCellLocator
    };
}

test.describe('Disciplines created successfully', () => {
    test('GIVEN New Level 1 Discipline added - THEN all input fields are editable', async ({page}) => {
        const EMPTY_STRING = "";

        const {
            levelOneDisciplineNameDeInputCellLocator,
            levelOneDisciplineNameEnInputCellLocator,
            levelTwoDisciplineNameDeInputCellLocator,
            levelTwoDisciplineNameEnInputCellLocator,
            prefixInputCellLocator,
            certificationTopicNameInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.waitForTimeout(1000);
        await page.getByTestId(DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(levelOneDisciplineNameDeInputCellLocator, levelOneDisciplineNameEnInputCellLocator, levelTwoDisciplineNameDeInputCellLocator, levelTwoDisciplineNameEnInputCellLocator, prefixInputCellLocator, certificationTopicNameInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(levelOneDisciplineNameDeInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(levelOneDisciplineNameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(levelTwoDisciplineNameDeInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(levelTwoDisciplineNameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(prefixInputCellLocator);
            // certificationTopicName
            await expect(certificationTopicNameInputCellLocator).toBeVisible();
            await expect(certificationTopicNameInputCellLocator).toHaveValue(EMPTY_STRING)
            await expect(certificationTopicNameInputCellLocator).toBeEditable();
            // isActive
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Level 2 Discipline added - THEN all input fields are editable', async ({page}) => {
        const {
            levelOneDisciplineNameDeInputCellLocator,
            levelOneDisciplineNameEnInputCellLocator,
            levelTwoDisciplineNameDeInputCellLocator,
            levelTwoDisciplineNameEnInputCellLocator,
            prefixInputCellLocator,
            certificationTopicNameInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page, 1);

        await addLevelTwoDisciplineButtonClick(page);
        await verifyThatAllFieldsAreEditableAndCertainFieldsAlreadyFilled();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(levelOneDisciplineNameDeInputCellLocator, levelOneDisciplineNameEnInputCellLocator, levelTwoDisciplineNameDeInputCellLocator, levelTwoDisciplineNameEnInputCellLocator, prefixInputCellLocator, certificationTopicNameInputCellLocator, isActiveInputCellLocator);

        async function verifyThatAllFieldsAreEditableAndCertainFieldsAlreadyFilled() {
            // Editable & Not Empty
            await checkIfFieldVisibleEditableButNotEmpty(levelOneDisciplineNameDeInputCellLocator);
            await checkIfFieldVisibleEditableButNotEmpty(levelOneDisciplineNameEnInputCellLocator);
            await checkIfFieldVisibleEditableButNotEmpty(certificationTopicNameInputCellLocator);
            // Editable & Empty
            await checkIfFieldVisibleEditableEmpty(levelTwoDisciplineNameDeInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(levelTwoDisciplineNameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(prefixInputCellLocator);
            // isActive
            await expect(isActiveInputCellLocator).toBeEnabled();
        }
    });

    // TODO - Fix this test when feature improvements are done
    // test('GIVEN New Level 1 Discipline added - THEN success message appears', async ({page}) => {
    //     await page.getByTestId(DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON).click();
    //     await fillOutAllTextFieldsWhenAddLevelOne(page, 'ABC', 'ABC', 'ABC', 'ABC', 'abc')
    //     await markCheckboxIsActivated(page);
    //     await saveDisciplineAndVerifySuccessMessage(page, DISCIPLINE_TEXT_SUCCESSFULLY_CREATED);
    // });

    test('GIVEN New Level 2 Discipline added - THEN success message appears', async ({page}) => {
        const {
            levelTwoDisciplineNameDe,
            levelTwoDisciplineNameEn,
            prefixName
        } = createRandomNamesForLevelTwoAndPrefix();

        await addLevelTwoDisciplineButtonClick(page);
        await fillOutLevelTwoAndPrefixInputFieldsWhenAddingLevelTwo(page, levelTwoDisciplineNameDe, levelTwoDisciplineNameEn, prefixName);
        await saveDisciplineAndVerifySuccessMessage(page, DISCIPLINE_TEXT_SUCCESSFULLY_CREATED);
    });
});

async function checkIfFieldVisibleEditableButNotEmpty(cell: Locator) {
    await expect(cell).toBeVisible();
    await expect(cell).not.toBeEmpty();
    await expect(cell).toBeEditable();
}

async function verifyThatInputFieldsDisappear(levelOneDisciplineNameDeInputCellLocator: Locator, levelOneDisciplineNameEnInputCellLocator: Locator, levelTwoDisciplineNameDeInputCellLocator: Locator, levelTwoDisciplineNameEnInputCellLocator: Locator, prefixInputCellLocator: Locator, certificationTopicNameInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(levelOneDisciplineNameDeInputCellLocator).not.toBeVisible();
    await expect(levelOneDisciplineNameEnInputCellLocator).not.toBeVisible();
    await expect(levelTwoDisciplineNameDeInputCellLocator).not.toBeVisible();
    await expect(levelTwoDisciplineNameEnInputCellLocator).not.toBeVisible();
    await expect(prefixInputCellLocator).not.toBeVisible();
    await expect(certificationTopicNameInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}
