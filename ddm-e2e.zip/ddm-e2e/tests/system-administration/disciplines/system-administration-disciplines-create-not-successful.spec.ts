import {Page, test} from "@playwright/test";
import {
    DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON,
    DISCIPLINE_TEXT_MESSAGE_LEVEL_ONE_100_DE,
    DISCIPLINE_TEXT_MESSAGE_LEVEL_ONE_100_EN,
    DISCIPLINE_TEXT_MESSAGE_LEVEL_TWO_100_DE,
    DISCIPLINE_TEXT_MESSAGE_LEVEL_TWO_100_EN, DISCIPLINE_TEXT_MESSAGE_PREFIX_EXACTLY_THREE_CHARS,
} from "./utils/constants";
import {
    fillOutAllTextFieldsWhenAddLevelOne
} from "./utils/testHelper";
import {navigateToSystemAdministration, verifyThatEntryCannotBeSavedAndCancelEditing} from "../common/testHelper";
import {navigateToBaseUrl} from "../../utils/testHelper";
import {LOREM_IPSUM_295} from "../../utils/constants";

const PREFIX_NAME_TWO_CHARS: string = 'SB';
const PREFIX_NAME_THREE_CHARS: string = 'KIO';
const PREFIX_NAME_FOUR_CHARS: string = 'SBBB';
const LEVEL_0NE_DISCIPLINE_NAME_DE = 'Some Level One Discipline DE';
const LEVEL_0NE_DISCIPLINE_NAME_EN = 'Some Level One Discipline EN';
const LEVEL_TWO_DISCIPLINE_NAME_DE = 'Some Level Two Discipline DE';
const LEVEL_TWO_DISCIPLINE_NAME_EN = 'Some Level Two Discipline EN';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
});

async function addLevelOneDisciplineButtonClick(page: Page) {
    await page.waitForTimeout(1000);
    await page.getByTestId(DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON).click();
}

test.describe('Discipline Input Validations', () => {
    test('GIVEN Level 1 Name DE too long - THEN Adding Discipline not possible', async ({page}) => {

        await addLevelOneDisciplineButtonClick(page);
        await fillOutAllTextFieldsWhenAddLevelOne(page, LOREM_IPSUM_295, LEVEL_0NE_DISCIPLINE_NAME_EN, LEVEL_TWO_DISCIPLINE_NAME_DE, LEVEL_TWO_DISCIPLINE_NAME_EN, PREFIX_NAME_THREE_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, DISCIPLINE_TEXT_MESSAGE_LEVEL_ONE_100_DE);
    });

    test('GIVEN Level 1 Name EN too long - THEN Adding Discipline not possible', async ({page}) => {

        await addLevelOneDisciplineButtonClick(page);
        await fillOutAllTextFieldsWhenAddLevelOne(page, LEVEL_0NE_DISCIPLINE_NAME_DE, LOREM_IPSUM_295, LEVEL_TWO_DISCIPLINE_NAME_DE, LEVEL_TWO_DISCIPLINE_NAME_EN, PREFIX_NAME_THREE_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, DISCIPLINE_TEXT_MESSAGE_LEVEL_ONE_100_EN)
    });

    test('GIVEN Level 2 Name DE too long - THEN Adding Discipline not possible', async ({page}) => {

        await addLevelOneDisciplineButtonClick(page);
        await fillOutAllTextFieldsWhenAddLevelOne(page, LEVEL_0NE_DISCIPLINE_NAME_DE, LEVEL_0NE_DISCIPLINE_NAME_EN, LOREM_IPSUM_295, LEVEL_TWO_DISCIPLINE_NAME_EN, PREFIX_NAME_THREE_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, DISCIPLINE_TEXT_MESSAGE_LEVEL_TWO_100_DE)
    });

    test('GIVEN Level 2 Name EN too long - THEN Adding Discipline not possible ', async ({page}) => {

        await addLevelOneDisciplineButtonClick(page);
        await fillOutAllTextFieldsWhenAddLevelOne(page, LEVEL_0NE_DISCIPLINE_NAME_DE, LEVEL_0NE_DISCIPLINE_NAME_EN, LEVEL_TWO_DISCIPLINE_NAME_DE, LOREM_IPSUM_295, PREFIX_NAME_THREE_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, DISCIPLINE_TEXT_MESSAGE_LEVEL_TWO_100_EN)
    });

    test('GIVEN Prefix too short - THEN Adding Discipline not possible ', async ({page}) => {

        await addLevelOneDisciplineButtonClick(page);
        await fillOutAllTextFieldsWhenAddLevelOne(page, LEVEL_0NE_DISCIPLINE_NAME_DE, LEVEL_0NE_DISCIPLINE_NAME_EN, LEVEL_TWO_DISCIPLINE_NAME_DE, LEVEL_TWO_DISCIPLINE_NAME_EN, PREFIX_NAME_TWO_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, DISCIPLINE_TEXT_MESSAGE_PREFIX_EXACTLY_THREE_CHARS)
    });

    test('GIVEN Prefix too long - THEN Adding Discipline not possible', async ({page}) => {

        await addLevelOneDisciplineButtonClick(page);
        await fillOutAllTextFieldsWhenAddLevelOne(page, LEVEL_0NE_DISCIPLINE_NAME_DE, LEVEL_0NE_DISCIPLINE_NAME_EN, LEVEL_TWO_DISCIPLINE_NAME_DE, LEVEL_TWO_DISCIPLINE_NAME_EN, PREFIX_NAME_FOUR_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, DISCIPLINE_TEXT_MESSAGE_PREFIX_EXACTLY_THREE_CHARS)
    });
});
