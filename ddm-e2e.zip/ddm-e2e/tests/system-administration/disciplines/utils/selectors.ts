import {Page} from "@playwright/test";
import {selectDIVByRoleAndDataFieldAndColAndRowIndex} from "../../../utils/selector";

export function getLevelOneDisciplineNameDeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "levelOneDisciplineNameDe", 2, dataRowIndex);
}

export function getLevelOneDisciplineNameEnInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "levelOneDisciplineNameEn", 3, dataRowIndex);
}

export function getLevelTwoDisciplineNameDeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "levelTwoDisciplineNameDe", 5, dataRowIndex);
}

export function getLevelTwoDisciplineNameEnInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "levelTwoDisciplineNameEn", 6, dataRowIndex);
}

export function getPrefixCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "prefix", 7, dataRowIndex);
}

export function getCertificationTopicNameCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "certificationTopicName", 8, dataRowIndex);
}

export function getIsActiveCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 9, dataRowIndex);
}