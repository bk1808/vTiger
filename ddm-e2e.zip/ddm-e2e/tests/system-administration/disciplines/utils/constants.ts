export const DISCIPLINE_TEXT_MESSAGE_LEVEL_ONE_100_DE: string = "Level 1 Discipline DE must not be empty and the length must be at most 100";
export const DISCIPLINE_TEXT_MESSAGE_LEVEL_ONE_100_EN: string = "Level 1 Discipline EN must not be empty and the length must be at most 100";
export const DISCIPLINE_TEXT_MESSAGE_LEVEL_TWO_100_DE: string = "Level 2 Discipline DE must not be empty and the length must be at most 100";
export const DISCIPLINE_TEXT_MESSAGE_LEVEL_TWO_100_EN: string = "Level 2 Discipline EN must not be empty and the length must be at most 100";
export const DISCIPLINE_TEXT_MESSAGE_PREFIX_EXACTLY_THREE_CHARS: string = "Prefix must not be empty and must be exactly 3 characters in length";

export const DISCIPLINE_TEXT_SUCCESSFULLY_CREATED: string = 'Discipline successfully created.';
export const DISCIPLINE_TEXT_SUCCESSFULLY_UPDATED: string = 'Discipline successfully updated.';
export const DISCIPLINE_TEXT_SUCCESSFULLY_DELETED: string = 'Discipline successfully deleted.';

export const DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON: string = 'add-level-one-discipline-button';
export const DATA_TEST_ID_ADD_LEVEL_TWO_BUTTON: string = 'add-level-two-discipline-button';