import {Page} from "@playwright/test";
import {
    getCertificationTopicNameCell,
    getIsActiveCell,
    getLevelOneDisciplineNameDeInputCell,
    getLevelOneDisciplineNameEnInputCell,
    getLevelTwoDisciplineNameDeInputCell,
    getLevelTwoDisciplineNameEnInputCell,
    getPrefixCell
} from "./selectors";

const CERTIFICATION_TOPIC: string = 'Bremse';

export function createRandomNamesForLevelTwoAndPrefix() {
    let randomString = Math.random().toString(36).slice(2, 7);
    const levelTwoDisciplineNameDe = 'A' + randomString;
    let randomString2 = Math.random().toString(36).slice(2, 7);
    const levelTwoDisciplineNameEn = 'A' + randomString2;
    let randomString3 = Math.random().toString(26).slice(2, 4).toUpperCase();
    const prefixName = 'X' + randomString3;
    return {levelTwoDisciplineNameDe, levelTwoDisciplineNameEn, prefixName};
}

export async function fillOutLevelTwoAndPrefixInputFieldsWhenAddingLevelTwo(page: Page, levelTwoDisciplineNameDe: string, levelTwoDisciplineNameEn: string, prefixName: string) {
    const levelTwoDisciplineNameDeInputCellLocator = getLevelTwoDisciplineNameDeInputCell(page, 1).locator('input');
    const levelTwoDisciplineNameEnInputCellLocator = getLevelTwoDisciplineNameEnInputCell(page, 1).locator('input');
    const prefixInputCellLocator = getPrefixCell(page, 1).locator('input');

    await levelTwoDisciplineNameDeInputCellLocator.fill(levelTwoDisciplineNameDe);
    await levelTwoDisciplineNameEnInputCellLocator.fill(levelTwoDisciplineNameEn);
    await prefixInputCellLocator.fill(prefixName);
    await getIsActiveCell(page, 1).locator('input').click();
}

export async function fillOutAllTextFieldsWhenAddLevelOne(page: Page, levelOneDisciplineNameDe: string, levelOneDisciplineNameEn: string, levelTwoDisciplineNameDe: string, levelTwoDisciplineNameEn: string, prefix: string) {
    const levelOneDisciplineNameDeInputCellLocator = getLevelOneDisciplineNameDeInputCell(page).locator('input');
    const levelOneDisciplineNameEnInputCellLocator = getLevelOneDisciplineNameEnInputCell(page).locator('input');
    const levelTwoDisciplineNameDeInputCellLocator = getLevelTwoDisciplineNameDeInputCell(page).locator('input');
    const levelTwoDisciplineNameEnInputCellLocator = getLevelTwoDisciplineNameEnInputCell(page).locator('input');
    const prefixInputCellLocator = getPrefixCell(page).locator('input');

    await levelOneDisciplineNameDeInputCellLocator.fill(levelOneDisciplineNameDe);
    await levelOneDisciplineNameEnInputCellLocator.fill(levelOneDisciplineNameEn);
    await levelTwoDisciplineNameDeInputCellLocator.fill(levelTwoDisciplineNameDe);
    await levelTwoDisciplineNameEnInputCellLocator.fill(levelTwoDisciplineNameEn);
    await prefixInputCellLocator.fill(prefix);

    // Note: Need to add a small timeout to give the Browser time to render the popup otherwise it will get stuck due to its behaviour and to quick re-call of it
    await page.waitForTimeout(1000);

    await getCertificationTopicNameCell(page).click();
    await page.getByTestId(CERTIFICATION_TOPIC).click();
}

export async function saveDisciplineAndVerifySuccessMessage(page: Page, successMessage: string) {
    await page.getByTestId('SaveIcon').click();
    // TODO commented for now because we have a windows-reload that overwrites the success message. Once we have another implementation, we can uncomment this
    // TODO then refactor using the saveEntryAndVerifySuccessMessage function from common/testHelper.ts
    // await expect(page.getByText(successMessage)).toBeVisible();
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveCell(page).locator('input').check();
}
export async function addLevelTwoDisciplineButtonClick(page: Page) {
    await page.waitForTimeout(1000);
    const firstRow = page.locator('div[role="row"][data-rowindex="0"]');
    const button = firstRow.locator('div[role="gridcell"][data-colindex="0"]');
    await button.click();
}
