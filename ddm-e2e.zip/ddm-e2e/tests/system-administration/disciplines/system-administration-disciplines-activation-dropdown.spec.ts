import {expect, Locator, test} from "@playwright/test";
import {
    addLevelTwoDisciplineButtonClick,
    createRandomNamesForLevelTwoAndPrefix, fillOutAllTextFieldsWhenAddLevelOne,
    fillOutLevelTwoAndPrefixInputFieldsWhenAddingLevelTwo,
    saveDisciplineAndVerifySuccessMessage
} from "./utils/testHelper";
import {
    getIsActiveCell,
} from "./utils/selectors";
import {INPUT} from "../../utils/locators";
import {
    DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON, DATA_TEST_ID_ADD_LEVEL_TWO_BUTTON,
    DISCIPLINE_TEXT_SUCCESSFULLY_CREATED,
    DISCIPLINE_TEXT_SUCCESSFULLY_DELETED,
    DISCIPLINE_TEXT_SUCCESSFULLY_UPDATED
} from "./utils/constants";
import {navigateToSystemAdministration} from "../common/testHelper";
import {navigateToBaseUrl} from "../../utils/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
});

test.describe('Activation and Deactivation of Disciplines in Create SAM form', () => {
    test('GIVEN  new Sam - THEN discipline included in or excluded from Create-SAM dropdown list', async ({page}) => {
        // Create discipline by using the 'Add Level 1' button' and activate it
        // Discipline is then displayed in the disciplines dropdown of the create-SAM form
        const {
            levelTwoDisciplineNameDe: levelTwoDeFirst,
            levelTwoDisciplineNameEn: levelTwoEnFirst,
            prefixName: prefixFirst
        } = createRandomNamesForLevelTwoAndPrefix();
        const {
            levelTwoDisciplineNameDe: levelTwoDeSecond,
            levelTwoDisciplineNameEn: levelTwoEnSecond,
            prefixName: prefixSecond
        } = createRandomNamesForLevelTwoAndPrefix();
        const levelOneDisciplineNameDe = 'AAA';
        const levelOneDisciplineNameEn = 'AAA';

        await page.waitForTimeout(1000);
        await page.getByTestId(DATA_TEST_ID_ADD_LEVEL_ONE_BUTTON).click();
        await fillOutAllTextFieldsWhenAddLevelOne(page, levelOneDisciplineNameDe, levelOneDisciplineNameEn, levelTwoDeFirst, levelTwoEnFirst, prefixFirst);
        const isActiveInputCellLocatorLevelOne = getIsActiveCell(page).locator('input');
        await activateDisciplineAndVerifyThatDisciplineDisplayedInDropdown(isActiveInputCellLocatorLevelOne, levelTwoDeFirst, levelTwoEnFirst, DISCIPLINE_TEXT_SUCCESSFULLY_CREATED);

        // Edit the first created discipline and deactivate it
        await navigateToSystemAdministration(page);
        await page.getByTestId('EditIcon').first().click();
        await deactivateDisciplineAndSave(isActiveInputCellLocatorLevelOne, DISCIPLINE_TEXT_SUCCESSFULLY_UPDATED);

        // Discipline is not displayed in the disciplines dropdown of the create-SAM form
        await verifyThatDiscplineIsNotDisplayedInCreateSamDropdown(levelTwoDeFirst, levelTwoEnFirst);

        // Create second discipline by using the 'Add Level 2' button' in the row containing the first discipline
        // Second discpline is already deactivated like the first one
        await navigateToSystemAdministration(page);
        await page.waitForTimeout(1000);
        await addLevelTwoDisciplineButtonClick(page)
        await fillOutLevelTwoAndPrefixInputFieldsWhenAddingLevelTwo(page, levelTwoDeSecond, levelTwoEnSecond, prefixSecond);
        await saveDisciplineAndVerifySuccessMessage(page, DISCIPLINE_TEXT_SUCCESSFULLY_CREATED);

        // Second Discipline is then not displayed in the disciplines dropdown of the create-SAM form
        await verifyThatDiscplineIsNotDisplayedInCreateSamDropdown(levelTwoDeSecond, levelTwoEnSecond);

        // Edit the second discipline and activate it
        await navigateToSystemAdministration(page);
        await page.getByTestId('EditIcon').nth(1).click();
        const isActiveInputCellLocatorLevelTwo = getIsActiveCell(page, 1).locator('input');

        // Second Discipline is then not displayed in the disciplines dropdown of the create-SAM form
        await activateDisciplineAndVerifyThatDisciplineDisplayedInDropdown(isActiveInputCellLocatorLevelTwo, levelTwoDeSecond, levelTwoEnSecond, DISCIPLINE_TEXT_SUCCESSFULLY_UPDATED);

        // Delete both disciplines
        await navigateToSystemAdministration(page);
        await page.getByTestId('DeleteIcon').first().click();
        await expect(page.getByText(DISCIPLINE_TEXT_SUCCESSFULLY_DELETED)).toBeVisible();
        await page.getByTestId('DeleteIcon').first().click();
        await expect(page.getByText(DISCIPLINE_TEXT_SUCCESSFULLY_DELETED)).toBeVisible();

        async function activateDisciplineAndVerifyThatDisciplineDisplayedInDropdown(isActiveInputCellLocator: Locator, levelTwoDisciplineNameDe: string, levelTwoDisciplineNameEn: string, successMessage: string) {
            await isActiveInputCellLocator.click();
            await expect(page.getByTestId('CheckBoxIcon')).toBeVisible();

            await saveDisciplineAndVerifySuccessMessage(page, successMessage);

            await navigateToCreateSam(page);

            await page.getByTestId('disciplineId-de').click();
            await page.getByTestId('disciplineId-de').locator(INPUT).fill(levelOneDisciplineNameDe);
            await page.getByRole('option', {name: `${levelOneDisciplineNameDe}: ${levelTwoDisciplineNameDe}`}).isVisible();
            await page.getByRole('option', {name: `${levelOneDisciplineNameEn}: ${levelTwoDisciplineNameEn}`}).isVisible();
        }

        async function verifyThatDiscplineIsNotDisplayedInCreateSamDropdown(levelTwoDisciplineNameDe: string, levelTwoDisciplineNameEn: string) {
            await navigateToCreateSam(page);

            await page.getByTestId('disciplineId-de').click();
            await page.getByTestId('disciplineId-de').locator(INPUT).fill(levelOneDisciplineNameDe);
            await page.getByRole('option', {name: `${levelOneDisciplineNameDe}: ${levelTwoDisciplineNameDe}`}).isHidden();
            await page.getByRole('option', {name: `${levelOneDisciplineNameEn}: ${levelTwoDisciplineNameEn}`}).isHidden();
        }

        async function deactivateDisciplineAndSave(isActiveInputCellLocator: Locator, successMessage: string) {
            await isActiveInputCellLocator.click();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();

            await saveDisciplineAndVerifySuccessMessage(page, successMessage);
        }
    });
});
