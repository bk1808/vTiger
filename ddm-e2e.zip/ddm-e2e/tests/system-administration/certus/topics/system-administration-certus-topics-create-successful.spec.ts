import {expect, Locator, Page, test} from "@playwright/test";
import {addNewEntry, goToCertusTopicTab, markCheckboxIsActivated} from "./utils/testHelper";
import {getIsActiveInputCell, getTopicNameDeInputCell, getTopicNameEnInputCell} from "./utils/selectors";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {CERTUS_TOPIC_TEXT_SUCCESSFULLY_CREATED, CERTUS_TOPIC_TEXT_SUCCESSFULLY_DELETED} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToCertusTopicTab(page);
});

test.describe('Certus Certificate Topics created successfully', () => {
    test('GIVEN New Certifcate Topic added - THEN all input fields are editable', async ({page}) => {
        const {
            topicNameDeInputCellLocator,
            topicNameEnInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(topicNameDeInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(topicNameEnInputCellLocator);
            // isActive
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(topicNameDeInputCellLocator, topicNameEnInputCellLocator, isActiveInputCellLocator);
    });

    test('GIVEN New Certificate Topic added - THEN success message appears', async ({page}) => {
        const inputNameDe = 'A Topic';
        const inputNameEn = 'A Topic';

        await addNewEntry(page, inputNameDe, inputNameEn);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_TOPIC_TEXT_SUCCESSFULLY_CREATED);
        await deleteEntry(page, inputNameDe, CERTUS_TOPIC_TEXT_SUCCESSFULLY_DELETED);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const topicNameDeInputCellLocator = getTopicNameDeInputCell(page, dataRowIndex).locator('input');
    const topicNameEnInputCellLocator = getTopicNameEnInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        topicNameDeInputCellLocator,
        topicNameEnInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(topicNameDeInputCellLocator: Locator, topicNameEnInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(topicNameDeInputCellLocator).not.toBeVisible();
    await expect(topicNameEnInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}