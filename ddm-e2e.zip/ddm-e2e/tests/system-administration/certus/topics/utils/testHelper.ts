import {Page} from "@playwright/test";
import {navigateToSystemAdministration} from "../../../common/testHelper";
import {getIsActiveInputCell, getTopicNameDeInputCell, getTopicNameEnInputCell} from "./selectors";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../common/constants";
import {navigateToBaseUrl} from "../../../../utils/testHelper";

export async function goToCertusTopicTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('certus-dashboard-button').click();
    await page.getByTestId('certus-topic-button').click();
}

export async function addNewEntry(page: Page, nameDe: string, nameEn: string) {
    await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
    await fillOutAllTextFields(page, nameDe, nameEn);
}

export async function fillOutAllTextFields(page: Page, nameDe: string, nameEn: string) {
    const topicNameDeInputCellLocator = getTopicNameDeInputCell(page).locator('input');
    await topicNameDeInputCellLocator.fill(nameDe);

    const topicNameEnInputCellLocator = getTopicNameEnInputCell(page).locator('input');
    await topicNameEnInputCellLocator.fill(nameEn);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}
