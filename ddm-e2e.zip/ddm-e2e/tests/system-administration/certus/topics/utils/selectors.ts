import {Page} from "@playwright/test";
import {selectDIVByRoleAndDataFieldAndColAndRowIndex} from "../../../../utils/selector";

export function getTopicNameDeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "nameDe", 0, dataRowIndex);
}

export function getTopicNameEnInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "nameEn", 1, dataRowIndex);
}

export function getIsActiveInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 2, dataRowIndex);
}