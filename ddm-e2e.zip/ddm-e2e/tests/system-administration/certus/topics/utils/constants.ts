export const CERTUS_TOPIC_TEXT_SUCCESSFULLY_CREATED: string = 'Certificate Topic successfully created.';
export const CERTUS_TOPIC_TEXT_SUCCESSFULLY_UPDATED: string = 'Certificate Topic successfully updated.';
export const CERTUS_TOPIC_TEXT_SUCCESSFULLY_DELETED: string = 'Certificate Topic successfully deleted.';

export const CERTUS_TOPIC_DE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY: string = "Certificate Topic DE must not be empty and the length must be at most 1000";
export const CERTUS_TOPIC_EN_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY: string = "Certificate Topic EN must not be empty and the length must be at most 1000";
export const CERTUS_TOPIC_DE_TEXT_MESSAGE_NO_UMLAUTS: string = "Certificate Topic DE must not contain umlauts";
export const CERTUS_TOPIC_EN_TEXT_MESSAGE_NO_UMLAUTS: string = "Certificate Topic EN must not contain umlauts";
export const CERTUS_TOPIC_DE_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Certificate Topic DE already exists";
export const CERTUS_TOPIC_EN_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Certificate Topic EN already exists";