import {test} from "@playwright/test";
import {EMPTY_STRING, LOREM_IPSUM_MORE_THAN_1000_CHARS} from "../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {addNewEntry, goToCertusTopicTab} from "./utils/testHelper";
import {
    CERTUS_TOPIC_DE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    CERTUS_TOPIC_DE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY,
    CERTUS_TOPIC_DE_TEXT_MESSAGE_NO_UMLAUTS, CERTUS_TOPIC_EN_TEXT_MESSAGE_DUPLICATED_ENTRY,
    CERTUS_TOPIC_EN_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY,
    CERTUS_TOPIC_EN_TEXT_MESSAGE_NO_UMLAUTS,
    CERTUS_TOPIC_TEXT_SUCCESSFULLY_CREATED, CERTUS_TOPIC_TEXT_SUCCESSFULLY_DELETED,
} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToCertusTopicTab(page);
});

test.describe('Certus Certificate Topic Input Validations', () => {
    const validInputNameEn = 'Name En';
    const validInputNameDe = 'Name De';

    test('GIVEN Certificate Topic Name De  empty - THEN Adding Certificate Topic not possible', async ({page}) => {
        await addNewEntry(page, EMPTY_STRING, validInputNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_DE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY);
    });

    test('GIVEN Certificate Topic Name En  empty - THEN Adding Certificate Topic not possible', async ({page}) => {
        await addNewEntry(page, 'Name De',  EMPTY_STRING);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_EN_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY);
    });

    test('GIVEN Certificate Topic Name De too long - THEN Adding Certificate Topic not possible', async ({page}) => {
        await addNewEntry(page, LOREM_IPSUM_MORE_THAN_1000_CHARS, validInputNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_DE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY);
    });

    test('GIVEN Certificate Topic Name En too long - THEN Adding Certificate Topic not possible', async ({page}) => {
        await addNewEntry(page, validInputNameDe, LOREM_IPSUM_MORE_THAN_1000_CHARS);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_EN_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY);
    });

    test('GIVEN Certificate Topic Name De contains umlauts - THEN Adding Certificate Topic not possible', async ({page}) => {
        await addNewEntry(page, 'Topic ÖäÜ', validInputNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_DE_TEXT_MESSAGE_NO_UMLAUTS);
    });

    test('GIVEN Certificate Topic Name En contains umlauts - THEN Adding Certificate Topic not possible', async ({page}) => {
        await addNewEntry(page, validInputNameDe, 'Topic ÖäÜ');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_EN_TEXT_MESSAGE_NO_UMLAUTS);
    });

    test('GIVEN Certificate Topic De duplicate - THEN Adding Certificate Topic not possible', async ({page}) => {
        const inputNameDe = 'A TopicTopicTopicTopicTopicTopicTopicTopicTopic';

        await addNewEntry(page, inputNameDe, validInputNameEn);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_TOPIC_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page, inputNameDe, 'Some Other Input Name En');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_DE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, inputNameDe, CERTUS_TOPIC_TEXT_SUCCESSFULLY_DELETED);
    })

    ;test('GIVEN Certificate Topic En duplicate - THEN Adding Certificate Topic not possible', async ({page}) => {
        const inputNameEn = 'A TopicTopicTopicTopicTopicTopicTopicTopicTopic';

        await addNewEntry(page, validInputNameDe, inputNameEn);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_TOPIC_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page, 'Some Other Input Name De', inputNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TOPIC_EN_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, validInputNameDe, CERTUS_TOPIC_TEXT_SUCCESSFULLY_DELETED);
    });
});
