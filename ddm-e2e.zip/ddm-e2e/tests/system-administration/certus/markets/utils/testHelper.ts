import {expect, Page} from "@playwright/test";
import {
    selectDIVByRoleAndDataFieldAndColAndRowIndex,
    selectTableRowByRoleAndDataFieldAndColAndRowIndex
} from "../../../../utils/selector";

export async function navigateToCertusSystemAdministration(page: Page, SecondaryTabTestId: string) {
    // Select "System administration" in the side bar
    await page.getByTestId('sidebar-system-administration-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*administration-system/);
    await expect(page.getByTestId('system-administration-view')).toBeVisible();
    await page.getByTestId('certus-dashboard-button').click()
    await page.getByTestId(SecondaryTabTestId).click() // go to Tab
}

export async function fillInMarketFieldsWithName(page: Page, name: string) {
    const nameInputCellLocator = selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "name", 0, 0).locator('input');
    await nameInputCellLocator.click();
    await nameInputCellLocator.fill(name);
}

export async function markCheckboxIsActivated(page: Page) {
    const isActiveInputCellLocator = selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 1, 0).locator('input');
    await isActiveInputCellLocator.click();
}

export async function fillInValuesIntoRow(page: Page, rowContent: string, newValue: string) {
    await page.getByTestId(`edit-button-${rowContent}`).click()
    await fillInMarketFieldsWithName(page, newValue);
}

