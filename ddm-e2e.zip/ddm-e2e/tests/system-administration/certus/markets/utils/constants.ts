export const CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED: string = 'Market successfully created';
export const CERTUS_MARKET_TEXT_SUCCESSFULLY_UPDATED: string = 'Market successfully updated';
export const CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED: string = 'Market successfully deleted';

export const CERTUS_MARKET_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Entry already exists";
export const CERTUS_MARKET_TEXT_MESSAGE_ENTRY_INVALID: string = "Market Name must not be empty, cannot have Umlauts or be longer than 1000 characters";