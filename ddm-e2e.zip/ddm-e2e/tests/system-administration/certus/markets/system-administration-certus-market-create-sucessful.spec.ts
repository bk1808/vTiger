import {test} from "@playwright/test";
import {
    fillInMarketFieldsWithName,
    markCheckboxIsActivated,
    navigateToCertusSystemAdministration
} from "./utils/testHelper";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "../../common/testHelper";
import {CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED, CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED} from "./utils/constants";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {navigateToBaseUrl} from "../../../utils/testHelper";

const tabName = "certus-markets-button";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCertusSystemAdministration(page,tabName);
});

test.describe('Given new market added - then success message appears', () => {
    test('GIVEN click Market - THEN Entry can be saved and deleted and success message appears', async ({page}) => {
        const name = 'NewName';

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page,name);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED);
        await deleteEntry(page, name, CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED);
    });
});
