import {test} from "@playwright/test";
import {
    fillInMarketFieldsWithName,
    fillInValuesIntoRow,
    navigateToCertusSystemAdministration
} from "./utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {
    CERTUS_MARKET_TEXT_MESSAGE_DUPLICATED_ENTRY, CERTUS_MARKET_TEXT_MESSAGE_ENTRY_INVALID,
    CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED,
    CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED
} from "./utils/constants";
import {navigateToBaseUrl} from "../../../utils/testHelper";

const tabName = "certus-markets-button";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCertusSystemAdministration(page,tabName);

});

test.describe('Given existing market edited - then entry cannot be saved an unsuccessful message appears', () => {
    test('GIVEN Edit a Row with Umlauts - THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        const marketNameToBeEdited = 'AA Market';
        const wrongValueWithUmlaute = 'AÄ Market'

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page, marketNameToBeEdited);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED);

        await fillInValuesIntoRow(page, marketNameToBeEdited, wrongValueWithUmlaute);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_MARKET_TEXT_MESSAGE_ENTRY_INVALID);

        await deleteEntry(page, marketNameToBeEdited, CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED);
    });

    test('GIVEN Edit a Row with duplicate - THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        const marketNameToBeEdited = "A Market";
        const duplicate = "CAN";

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page, marketNameToBeEdited);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED);

        await fillInValuesIntoRow(page, marketNameToBeEdited, duplicate);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_MARKET_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, marketNameToBeEdited, CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED);
    });
});
