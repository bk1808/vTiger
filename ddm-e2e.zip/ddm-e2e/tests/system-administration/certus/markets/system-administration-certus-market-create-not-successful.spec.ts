import {expect, test} from "@playwright/test";
import {
    fillInMarketFieldsWithName,
    markCheckboxIsActivated,
    navigateToCertusSystemAdministration
} from "./utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID, LOREM_IPSUM_MORE_THAN_1000_CHARS} from "../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {
    CERTUS_MARKET_TEXT_MESSAGE_DUPLICATED_ENTRY,
    CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED,
    CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED
} from "./utils/constants";
import {navigateToBaseUrl} from "../../../utils/testHelper";

const tabName = "certus-markets-button";
test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCertusSystemAdministration(page,tabName);
});

test.describe('Given new market added - then failure message appears', () => {
    test('GIVEN click Market and using Umlaute- THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        const name = 'NewNÄÜme';

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page,name);
        await expect(page.getByLabel('Save')).toBeDisabled();
    });

    test('GIVEN click Market and using Duplicate - THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        const name = 'USA';

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page,name);
        await expect(page.getByLabel('Save')).toBeDisabled();
    });

    test('GIVEN click Market and name to long - THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        let tooLong = LOREM_IPSUM_MORE_THAN_1000_CHARS

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page,tooLong);
        await expect(page.getByLabel('Save')).toBeDisabled();
    });

    test('GIVEN click Market and name blank - THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        let empty = ''
        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page,empty);
        await expect(page.getByLabel('Save')).toBeDisabled();
    });

    test('GIVEN Market duplicate - THEN all input fields are editable but save cannot be clicked', async ({page}) => {
        const nameInput = 'A Market';

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page, nameInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page, nameInput);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_MARKET_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, nameInput, CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED);
    });
});
