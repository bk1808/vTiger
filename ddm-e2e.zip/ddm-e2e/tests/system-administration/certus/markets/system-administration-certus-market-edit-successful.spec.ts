import {test} from "@playwright/test";
import {
    fillInMarketFieldsWithName,
    fillInValuesIntoRow, markCheckboxIsActivated,
    navigateToCertusSystemAdministration
} from "./utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
} from "../../common/testHelper";
import {
    CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED,
    CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED, CERTUS_MARKET_TEXT_SUCCESSFULLY_UPDATED
} from "./utils/constants";
import {navigateToBaseUrl} from "../../../utils/testHelper";


const tabName = "certus-markets-button";


test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCertusSystemAdministration(page,tabName);

});

test.describe('Given market edited - then success message appears', () => {
    test('GIVEN Edit a Row with correct value - THEN Entry can be saved and success message appears', async ({page}) => {
        const marketNameToBeEdited = 'AA Market';
        const correctInput = 'AReallyNewElement';

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await fillInMarketFieldsWithName(page, marketNameToBeEdited);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_MARKET_TEXT_SUCCESSFULLY_CREATED);

        await fillInValuesIntoRow(page, marketNameToBeEdited, correctInput);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_MARKET_TEXT_SUCCESSFULLY_UPDATED);

        await deleteEntry(page, correctInput, CERTUS_MARKET_TEXT_SUCCESSFULLY_DELETED);
    });
});
