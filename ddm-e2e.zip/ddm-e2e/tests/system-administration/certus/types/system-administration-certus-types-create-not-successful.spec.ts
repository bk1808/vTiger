import {test} from "@playwright/test";
import {addNewEntry, goToCertusTypeTab, markCheckboxIsActivated} from "./utils/testHelper";
import {
    CERTUS_TYPE_TEXT_MESSAGE_DUPLICATED_ENTRY,
    CERTUS_TYPE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY,
    CERTUS_TYPE_TEXT_MESSAGE_NO_UMLAUTS, CERTUS_TYPE_TEXT_SUCCESSFULLY_CREATED, CERTUS_TYPE_TEXT_SUCCESSFULLY_DELETED,
} from "./utils/constants";
import {EMPTY_STRING, LOREM_IPSUM_MORE_THAN_1000_CHARS} from "../../common/constants";
import {
    deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";

test.beforeEach(async ({page}) => {
    await goToCertusTypeTab(page);
});

test.describe('Certus Certificate Type Input Validations', () => {
    test('GIVEN Certificate Type empty - THEN Adding Certificate Type not possible', async ({page}) => {
        await addNewEntry(page, EMPTY_STRING);

        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TYPE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY);
    });

    test('GIVEN Certificate Type too long - THEN Adding Certificate Type not possible', async ({page}) => {
        await addNewEntry(page, LOREM_IPSUM_MORE_THAN_1000_CHARS);

        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TYPE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY);
    });

    test('GIVEN Certificate Type contains umlauts - THEN Adding Certificate Type not possible', async ({page}) => {
        await addNewEntry(page, 'Type Ö');

        await markCheckboxIsActivated(page);

        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TYPE_TEXT_MESSAGE_NO_UMLAUTS);
    });

    test('GIVEN Certificate Type duplicate - THEN Adding Certificate Type not possible', async ({page}) => {
        const input = 'A Type';

        await addNewEntry(page, input);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_TYPE_TEXT_SUCCESSFULLY_CREATED);

        await addNewEntry(page, input);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, CERTUS_TYPE_TEXT_MESSAGE_DUPLICATED_ENTRY);

        await deleteEntry(page, input, CERTUS_TYPE_TEXT_SUCCESSFULLY_DELETED);
    });
});

