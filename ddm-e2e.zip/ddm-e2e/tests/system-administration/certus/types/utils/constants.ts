export const CERTUS_TYPE_TEXT_SUCCESSFULLY_CREATED: string = 'Certificate Type successfully created.';
export const CERTUS_TYPE_TEXT_SUCCESSFULLY_UPDATED: string = 'Certificate Type successfully updated.';
export const CERTUS_TYPE_TEXT_SUCCESSFULLY_DELETED: string = 'Certificate Type successfully deleted.';

export const CERTUS_TYPE_TEXT_MESSAGE_MAX_1000_CHARS_NOT_EMPTY: string = "Certificate Type must not be empty and the length must be at most 1000";
export const CERTUS_TYPE_TEXT_MESSAGE_NO_UMLAUTS: string = "Certificate Type must not contain umlauts";
export const CERTUS_TYPE_TEXT_MESSAGE_DUPLICATED_ENTRY: string = "Certificate Type already exists";