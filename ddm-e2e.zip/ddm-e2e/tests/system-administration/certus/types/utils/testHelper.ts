import {Page} from "@playwright/test";
import {getIsActiveInputCell, getTypeInputCell} from "./selectors";
import {navigateToSystemAdministration} from "../../../common/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../common/constants";
import {navigateToBaseUrl} from "../../../../utils/testHelper";

export async function goToCertusTypeTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('certus-dashboard-button').click();
    await page.getByTestId('certus-type-button').click();
}

export async function fillOutAllTextFields(page: Page, type: string) {
    const typeInputCellLocator = getTypeInputCell(page).locator('input');
    await typeInputCellLocator.fill(type);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}

export async function addNewEntry(page: Page, input: string) {
    await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
    await fillOutAllTextFields(page, input);
}
