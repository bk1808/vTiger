import {Page} from "@playwright/test";
import {selectDIVByRoleAndDataFieldAndColAndRowIndex} from "../../../../utils/selector";

export function getTypeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "type", 0, dataRowIndex);
}

export function getIsValidInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isValid", 1, dataRowIndex);
}

export function getIsActiveInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 2, dataRowIndex);
}