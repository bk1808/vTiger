import {expect, Locator, Page, test} from "@playwright/test";

import {
    CERTUS_TYPE_TEXT_SUCCESSFULLY_CREATED,
    CERTUS_TYPE_TEXT_SUCCESSFULLY_DELETED,
} from "./utils/constants";
import {getIsActiveInputCell, getIsValidInputCell, getTypeInputCell} from "./utils/selectors";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {addNewEntry, goToCertusTypeTab, markCheckboxIsActivated} from "./utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";

test.beforeEach(async ({page}) => {
    await goToCertusTypeTab(page);
});

test.describe('Certus Certificate Types created successfully', () => {
    test('GIVEN New Certifcate Type added - THEN all input fields are editable', async ({page}) => {
        const {
            typeInputCellLocator,
            isValidInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(typeInputCellLocator, isValidInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(typeInputCellLocator);
            // isValid
            await expect(isValidInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxIcon')).toBeVisible();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon').nth(1)).not.toBeVisible();
            // isActive
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Certifcate Type added - THEN success message appears', async ({page}) => {
        const input = 'A Type';

        await addNewEntry(page, input);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_TYPE_TEXT_SUCCESSFULLY_CREATED);
        await deleteEntry(page, input, CERTUS_TYPE_TEXT_SUCCESSFULLY_DELETED);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const typeInputCellLocator = getTypeInputCell(page, dataRowIndex).locator('input');
    const isValidInputCellLocator = getIsValidInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        typeInputCellLocator,
        isValidInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(typeInputCellLocator: Locator, isValidInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(typeInputCellLocator).not.toBeVisible();
    await expect(isValidInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}