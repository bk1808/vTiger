import {expect, Page} from "@playwright/test";
import {navigateToSystemAdministration} from "../../../common/testHelper";
import {getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell, getValeInputCell} from "./selector";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../common/constants";
import {navigateToBaseUrl} from "../../../../utils/testHelper";

export async function navigateToCertusSystemAdministration(page: Page, SecondaryTabTestId: string) {
    // Select "System administration" in the side bar
    await page.getByTestId('sidebar-system-administration-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*administration-system/);
    await expect(page.getByTestId('system-administration-view')).toBeVisible();
    await page.getByTestId('certus-dashboard-button').click()
    await page.getByTestId(SecondaryTabTestId).click() // go to Tab

}

export async function goToCertusAdditionalSpecificationTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('certus-dashboard-button').click();
    await page.getByTestId('certus-additional-specification-button').click();
}

export async function addNewEntry(page: Page, nameDe: string, nameEn: string, value: string) {
    await page.waitForTimeout(1000);
    await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
    await fillOutAllTextFields(page, nameDe, nameEn, value);
}

export async function fillOutAllTextFields(page: Page, nameDe: string, nameEn: string, value: string) {
    const nameDeInputCellLocator = getNameDeInputCell(page).locator('input');
    await nameDeInputCellLocator.fill(nameDe);

    const nameEnInputCellLocator = getNameEnInputCell(page).locator('input');
    await nameEnInputCellLocator.fill(nameEn);

    const valueInputCellLocator = getValeInputCell(page).locator('input');
    await valueInputCellLocator.fill(value);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}
