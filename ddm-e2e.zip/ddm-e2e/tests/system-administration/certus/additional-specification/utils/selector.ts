import {Locator, Page} from "@playwright/test";
import {
    selectDIVByRoleAndDataFieldAndColAndRowIndex,
    selectTableRowByRoleAndDataFieldAndColAndRowIndex
} from "../../../../utils/selector";

export function getNameDeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "nameDe", 0, dataRowIndex);
}

export function getNameEnInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "nameEn", 1, dataRowIndex);
}

export function getValeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "value", 2, dataRowIndex);
}

export function getIsActiveInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 3, dataRowIndex);
}