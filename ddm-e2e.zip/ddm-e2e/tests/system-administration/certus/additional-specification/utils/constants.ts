export const CERTUS_ADDITIONAL_SPECIFICATION_TITLE: string = 'Additional Specification';
export const CERTUS_ADDITIONAL_SPECIFICATION_EXISTING_NAME_DE: string = 'Name (DE) already exists';
export const CERTUS_ADDITIONAL_SPECIFICATION_EXISTING_NAME_EN: string = 'Name (EN) already exists';
export const CERTUS_ADDITIONAL_SPECIFICATION_EXISTING_VALUE: string = 'Value already exists';

export const CERTUS_ADDITIONAL_SPECIFICATION_VALIDATION_TEXT_INVALID_NAME_DE: string = 'Name (DE) must not be empty, cannot have Umlauts or be longer than 40 characters';
export const CERTUS_ADDITIONAL_SPECIFICATION_VALIDATION_TEXT_INVALID_NAME_EN: string = 'Name (EN) must not be empty, cannot have Umlauts or be longer than 40 characters';
export const CERTUS_ADDITIONAL_SPECIFICATION_VALIDATION_TEXT_INVALID_VALUE: string = 'Value must not be empty, cannot have Umlauts or be longer than 40 characters';

export const CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS: string = 'Additional Specification successfully created';
export const CERTUS_ADDITIONAL_SPECIFICATION_UPDATE_SUCCESS: string = 'Additional Specification successfully updated.';
export const CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS: string = 'Additional Specification successfully deleted.';
export const CERTUS_ADDITIONAL_SPECIFICATION_CREATE_TEXT: string = 'Add Additional Specification';
