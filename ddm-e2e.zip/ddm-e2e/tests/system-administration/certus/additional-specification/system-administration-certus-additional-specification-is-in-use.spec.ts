import {expect, test} from "@playwright/test";
import {goToCertusAdditionalSpecificationTab} from "./utils/testHelper";
import {SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS} from "../../../utils/constants";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await goToCertusAdditionalSpecificationTab(page);
});

test.describe('Use existing Certus Additional Specification in SAM creation', () => {
    test('GIVEN SAM with Certus Additional Specification set - THEN Certus Additional Specification cannot be deleted in admin board', async ({page}) => {
        // Navigate to SAM creation form
        await navigateToCreateSam(page);

        // Fill SAM creation form with the existing additional specification
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
            certusMarket: "certusMarket-value-4", // EU
            certusCertificateTopic: "certusCertificateTopic-value-1", // LIGHTING
            certusCertificateType: "certusCertificateType-value-Type-approval", // Type-approval
            certusAdditionalSpecification: "certusAdditionalSpecification-value-5", // Certificates
            certusFunction:"certusFunction-value-7" //Stop lamp
        });

        // Submit SAM creation form
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Navigate back to Certus Additional Specification board
        await goToCertusAdditionalSpecificationTab(page);
        await expect(page.getByTestId("delete-button-Certificates")).toBeDisabled();
    });
});