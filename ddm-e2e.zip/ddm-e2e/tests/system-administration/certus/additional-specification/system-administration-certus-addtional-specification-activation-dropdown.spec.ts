import {expect, test} from "@playwright/test";
import {
    addNewEntry,
    goToCertusAdditionalSpecificationTab,
    markCheckboxIsActivated
} from "./utils/testHelper";

import {
    CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS,
    CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS
} from "./utils/constants";
import {SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS} from "../../../utils/constants";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "@root/tests/system-administration/common/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";


test.beforeEach(async ({page}) => {
    await goToCertusAdditionalSpecificationTab(page);
});

test.describe('Certus Additional Specification activation and deactivation', () => {
    const nameEn1 = 'Activation Test EN 1';
    const nameDe1 = 'Activation Test DE 1';
    const value1 = 'Activation Test Value 1';

    const nameEn2 = 'Deactivation Test EN 2';
    const nameDe2 = 'Deactivation Test DE 2';
    const value2 = 'Deactivation Test Value 2';

    test('GIVEN new activated additional specification - THEN it appears in dropdown', async ({page}) => {
        await addNewEntry(page, nameDe1, nameEn1, value1);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS);

        await navigateToCreateSam(page);
        await page.getByTestId('samTypeId').click();
        await page.getByTestId(SAM_FACTORY_SAM_TYPE_IDS.DIRECT).click();

        await page.getByTestId('masterDataSystemId').click();
        await page.getByTestId(SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS).click();

        await page.getByTestId('certusAdditionalSpecification').click();
        const option = page.locator('li.MuiAutocomplete-option', { hasText: nameEn1 });
        await expect(option).toBeVisible();
        await option.click();

        await goToCertusAdditionalSpecificationTab(page);
        await deleteEntry(page, nameEn1, CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS);
    });

    test('GIVEN new deactivated additional specification - THEN it does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, nameDe2, nameEn2, value2);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS);

        await navigateToCreateSam(page);
        await page.getByTestId('samTypeId').click();
        await page.getByTestId(SAM_FACTORY_SAM_TYPE_IDS.DIRECT).click();

        await page.getByTestId('masterDataSystemId').click();
        await page.getByTestId(SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS).click();

        await page.getByTestId('certusAdditionalSpecification').click();
        const option = page.locator('li.MuiAutocomplete-option', { hasText: nameEn2 });
        await expect(option).toBeHidden();

        await goToCertusAdditionalSpecificationTab(page);
        await deleteEntry(page, nameEn2, CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS);
    });
});