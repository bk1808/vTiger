import {expect, Locator, Page, test} from "@playwright/test";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {addNewEntry, fillOutAllTextFields, goToCertusAdditionalSpecificationTab, markCheckboxIsActivated} from "./utils/testHelper";
import {getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell, getValeInputCell} from "./utils/selector";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {
    CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS,
    CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS,
    CERTUS_ADDITIONAL_SPECIFICATION_UPDATE_SUCCESS
} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToCertusAdditionalSpecificationTab(page);
});

test.describe('Certus Additional Specification created successfully', () => {
    test('GIVEN New Additional Specification added - THEN all input fields are editable', async ({page}) => {
        const {
            nameEnInputCellLocator,
            nameDeInputCellLocator,
            valueInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(nameEnInputCellLocator, nameDeInputCellLocator, valueInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(nameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(nameDeInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(valueInputCellLocator);
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Additional Specification added - THEN success message appears', async ({page}) => {
        const nameEn = 'AName EN 1';
        const nameDe = 'AName DE 1';
        const value = 'AValue 1';

        await addNewEntry(page, nameEn, nameDe, value);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS);
        await deleteEntry(page, nameDe, CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS);
    });

    test('GIVEN existing Additional Specification in admin board - THEN Update success message appears', async ({page}) => {
        const nameEn = 'AAName EN 2';
        const nameDe = 'AAName DE 2';
        const value = 'AAValue 2';
        const updatedNameEn = 'AUpdated Name EN';
        const updatedNameDe = 'AUpdated Name DE';
        const updatedValue = 'AUpdated Value';

        // Add initial entry
        await addNewEntry(page, nameEn, nameDe, value);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_ADDITIONAL_SPECIFICATION_CREATE_SUCCESS);

        // Update the entry
        await page.getByTestId(`edit-button-${nameDe}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn, updatedValue);
        await markCheckboxIsActivated(page);

        await saveEntryAndVerifySuccessMessage(page, CERTUS_ADDITIONAL_SPECIFICATION_UPDATE_SUCCESS);
        await deleteEntry(page, updatedNameEn, CERTUS_ADDITIONAL_SPECIFICATION_DELETE_SUCCESS);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const nameEnInputCellLocator = getNameEnInputCell(page, dataRowIndex).locator('input');
    const nameDeInputCellLocator = getNameDeInputCell(page, dataRowIndex).locator('input');
    const valueInputCellLocator = getValeInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        nameEnInputCellLocator,
        nameDeInputCellLocator,
        valueInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(nameEnInputCellLocator: Locator, nameDeInputCellLocator: Locator, valueInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(nameEnInputCellLocator).not.toBeVisible();
    await expect(nameDeInputCellLocator).not.toBeVisible();
    await expect(valueInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}
