import {test} from "@playwright/test";
import {
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {addNewEntry, goToCertusFunctionTab} from "./utils/testHelper";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {
    CERTUS_FUNCTION_NAMEDE_VALIDATION,
    CERTUS_FUNCTION_NAMEEN_VALIDATION
} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToCertusFunctionTab(page);
});

test.describe('Certus Function validations', () => {
    test('Given NameEn empty - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = '';
        const nameDe = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTUS_FUNCTION_NAMEEN_VALIDATION)
    });

    test('Given NameDe empty - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = '';
        const nameEn = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTUS_FUNCTION_NAMEDE_VALIDATION)
    });
    
    test('Given NameDe has umlauts - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = 'Strömbeam';
        const nameEn = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTUS_FUNCTION_NAMEDE_VALIDATION)
    });
   
    test('Given NameEn has umlauts - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = 'Strömbeam';
        const nameDe = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTUS_FUNCTION_NAMEEN_VALIDATION)
    });

    test('Given NameEn is more than 40 characters - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = 'PhantomGlide X9000 | StealthBeam Pro Series by LuminX';
        const nameDe = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTUS_FUNCTION_NAMEEN_VALIDATION)
    });

    test('Given NameDe is more than 40 characters - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = 'PhantomGlide X9000 | StealthBeam Pro Series by LuminX';
        const nameEn = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,CERTUS_FUNCTION_NAMEDE_VALIDATION)
    });
});
