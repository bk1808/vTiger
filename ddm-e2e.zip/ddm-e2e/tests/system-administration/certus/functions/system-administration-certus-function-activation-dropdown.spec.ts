import {expect, Locator, Page, test} from "@playwright/test";
import {
    addNewEntry,
    goToCertusFunctionTab,
    markCheckboxIsActivated
} from "./utils/testHelper";

import {
    CERTUS_FUNCTION_CREATE_SUCCESS,
    CERTUS_FUNCTION_DELETE_SUCCESS
} from "./utils/constants";
import {SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS} from "../../../utils/constants";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "@root/tests/system-administration/common/testHelper";
import {navigateToCreateSam, selectCertusCertificateTopic} from "@root/tests/create-sam/utils/samCreationTestHelper";


test.beforeEach(async ({page}) => {
    await goToCertusFunctionTab(page);
});

test.describe('Certus Function activation and deactivation', () => {
    const nameEn1 = 'Activation Test EN 1';
    const nameDe1 = 'Activation Test DE 1';

    const nameEn2 = 'Deactivation Test EN 2';
    const nameDe2 = 'Deactivation Test DE 2';

    test('GIVEN new activated certus function - THEN it appears in dropdown', async ({page}) => {
        await addNewEntry(page, nameEn1, nameDe1);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_FUNCTION_CREATE_SUCCESS);

        const option = await createSamwithCertusLighting(page,nameEn1)
        await expect(option).toBeVisible();
        await option.click();

        await goToCertusFunctionTab(page);
        await deleteEntry(page, nameEn1, CERTUS_FUNCTION_DELETE_SUCCESS);
    });

    test('GIVEN new deactivated certus function - THEN it does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, nameEn2, nameDe2);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, CERTUS_FUNCTION_CREATE_SUCCESS);

        const option = await createSamwithCertusLighting(page,nameEn2)
        await expect(option).toBeHidden();

        await goToCertusFunctionTab(page);
        await deleteEntry(page, nameEn2, CERTUS_FUNCTION_DELETE_SUCCESS);
    });
});

const createSamwithCertusLighting = async(page:Page,name:string) => {
    await navigateToCreateSam(page);
    await page.getByTestId('samTypeId').click();
    await page.getByTestId(SAM_FACTORY_SAM_TYPE_IDS.DIRECT).click();

    await page.getByTestId('masterDataSystemId').click();
    await page.getByTestId(SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS).click();

    await selectCertusCertificateTopic(page, "certusCertificateTopic-value-1");
    await page.getByTestId('certusFunction').click();
    return page.locator('li.MuiAutocomplete-option', { hasText: name });
}