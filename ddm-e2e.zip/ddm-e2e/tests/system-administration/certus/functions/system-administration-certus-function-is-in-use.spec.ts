import {expect, test} from "@playwright/test";
import {goToCertusFunctionTab} from "./utils/testHelper";
import {SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS} from "../../../utils/constants";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await goToCertusFunctionTab(page);
});

test.describe('Use existing Certus Function in SAM creation', () => {
    test('GIVEN SAM with Certus Function set - THEN Certus Function cannot be deleted in admin board', async ({page}) => {
        // Navigate to SAM creation form
        await navigateToCreateSam(page);

        // Fill SAM creation form with the existing certus function
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
            certusMarket: "certusMarket-value-4", // EU
            certusCertificateTopic: "certusCertificateTopic-value-1", // LIGHTING
            certusCertificateType: "certusCertificateType-value-Type-approval", // Type-approval
            certusAdditionalSpecification: "certusAdditionalSpecification-value-5", // Certificates
            certusFunction:"certusFunction-value-7" //Stop lamp
        });

        // Submit SAM creation form
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Navigate back to Certus Function board
        await goToCertusFunctionTab(page);
        await expect(page.getByTestId("delete-button-Stop lamp")).toBeDisabled();
    });
});