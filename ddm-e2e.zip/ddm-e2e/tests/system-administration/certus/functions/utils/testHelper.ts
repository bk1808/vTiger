import {expect, Page} from "@playwright/test";
import {navigateToSystemAdministration} from "../../../common/testHelper";
import {getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell} from "./selector";
import {ADD_BUTTON_DATA_TEST_ID} from "../../../common/constants";
import {navigateToBaseUrl} from "../../../../utils/testHelper";

export async function navigateToCertusSystemAdministration(page: Page, SecondaryTabTestId: string) {
    // Select "System administration" in the side bar
    await page.getByTestId('sidebar-system-administration-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*administration-system/);
    await expect(page.getByTestId('system-administration-view')).toBeVisible();
    await page.getByTestId('certus-dashboard-button').click()
    await page.getByTestId(SecondaryTabTestId).click() // go to Tab

}

export async function goToCertusFunctionTab(page: Page) {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('certus-dashboard-button').click();
    await page.getByTestId('certus-function-button').click();
}

export async function addNewEntry(page: Page, nameEn: string, nameDe: string) {
    const addButton= page.getByTestId(ADD_BUTTON_DATA_TEST_ID);
    await addButton.click();
    await fillOutAllTextFields(page, nameDe, nameEn);
}

export async function fillOutAllTextFields(page: Page, nameDe: string, nameEn: string) {
    const nameDeInputCellLocator = getNameDeInputCell(page).locator('input');
    const nameEnInputCellLocator = getNameEnInputCell(page).locator('input');

    await nameDeInputCellLocator.fill(nameDe);
    await nameEnInputCellLocator.fill(nameEn);
}

export async function markCheckboxIsActivated(page: Page) {
    await getIsActiveInputCell(page).locator('input').check();
}
