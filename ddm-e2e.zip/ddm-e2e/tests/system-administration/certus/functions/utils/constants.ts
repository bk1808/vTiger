export const CERTUS_FUNCTION_CREATE_SUCCESS="Function successfully created";
export const CERTUS_FUNCTION_DELETE_SUCCESS="Function successfully deleted.";
export const CERTUS_FUNCTION_UPDATE_SUCCESS="Function successfully updated.";
export const CERTUS_FUNCTION_NAMEDE_VALIDATION="Name (DE) must not be empty, cannot have Umlauts or be longer than 40 characters";
export const CERTUS_FUNCTION_NAMEEN_VALIDATION="Name (EN) must not be empty, cannot have Umlauts or be longer than 40 characters"