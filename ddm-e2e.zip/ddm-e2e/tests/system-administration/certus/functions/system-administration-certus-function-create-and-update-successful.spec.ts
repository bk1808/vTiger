import {expect, Locator, Page, test} from "@playwright/test";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../../common/testHelper";
import {addNewEntry, fillOutAllTextFields, goToCertusFunctionTab, markCheckboxIsActivated} from "./utils/testHelper";
import {getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell} from "./utils/selector";
import {ADD_BUTTON_DATA_TEST_ID} from "../../common/constants";
import {
    CERTUS_FUNCTION_CREATE_SUCCESS,
    CERTUS_FUNCTION_DELETE_SUCCESS,
    CERTUS_FUNCTION_UPDATE_SUCCESS
} from "./utils/constants";

test.beforeEach(async ({page}) => {
    await goToCertusFunctionTab(page);
});

test.describe('Certus Function created successfully', () => {
    test('GIVEN New Function added - THEN all input fields are editable', async ({page}) => {
        const {
            nameEnInputCellLocator,
            nameDeInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(nameEnInputCellLocator, nameDeInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(nameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(nameDeInputCellLocator);
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Function added - THEN success message appears', async ({page}) => {
        const nameEn = 'AName EN 1';
        const nameDe = 'AName DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_FUNCTION_CREATE_SUCCESS);
        await deleteEntry(page, nameEn, CERTUS_FUNCTION_DELETE_SUCCESS);
    });

    test('GIVEN existing Function in admin board - THEN Update success message appears', async ({page}) => {
        const nameEn = 'AAName EN 2';
        const nameDe = 'AAName DE 2';
        const updatedNameEn = 'AUpdated Name EN';
        const updatedNameDe = 'AUpdated Name DE';

        // Add initial entry
        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, CERTUS_FUNCTION_CREATE_SUCCESS);

        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await markCheckboxIsActivated(page);

        await saveEntryAndVerifySuccessMessage(page, CERTUS_FUNCTION_UPDATE_SUCCESS);
        await deleteEntry(page, updatedNameEn, CERTUS_FUNCTION_DELETE_SUCCESS);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const nameEnInputCellLocator = getNameEnInputCell(page, dataRowIndex).locator('input');
    const nameDeInputCellLocator = getNameDeInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        nameEnInputCellLocator,
        nameDeInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(nameEnInputCellLocator: Locator, nameDeInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(nameEnInputCellLocator).not.toBeVisible();
    await expect(nameDeInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}
