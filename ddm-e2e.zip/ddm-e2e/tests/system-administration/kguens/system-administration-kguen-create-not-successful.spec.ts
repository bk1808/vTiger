import {Page, test} from "@playwright/test";
import {fillOutKguEn, navigateToSystemAdministration} from "./utils/testHelper";
import {
    DATA_TEST_ID_ADD_KGUEN_BUTTON, KGUEN_TEXT_MESSAGE_DUPLICATED_ENTRY,
    KGUEN_TEXT_MESSAGE_EN_WRONG,
    KGUEN_TEXT_MESSAGE_KGU_WRONG
} from "./utils/constants";
import {
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../common/testHelper";
import {EMPTY_STRING} from "../common/constants";
import {navigateToBaseUrl} from "../../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.waitForTimeout(1000);
    await page.getByTestId('kgu-en-dashboard-button').click();
});

async function clickAddKguenButton(page: Page) {
    await page.waitForTimeout(1000);
    await page.getByTestId(DATA_TEST_ID_ADD_KGUEN_BUTTON).click();
}

test.describe('Kgu-En input validation for invalid data', () => {
    test('Given Kgu empty - THEN error message appears and saving not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, EMPTY_STRING, '11');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_KGU_WRONG);
    });

    test('Given Kgu too long - THEN error message appears and saving not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, '0000000', '11');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_KGU_WRONG);
    });

    test('Given Kgu too short - THEN error message appears and saving not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, '00', '11');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_KGU_WRONG);
    });

    test('Given Kgu has Letters - THEN error message appears and saving not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, '00B', '11');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_KGU_WRONG);
    });

    test('Given EN empty - THEN error message appears and savin not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, '000', EMPTY_STRING);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_EN_WRONG);
    });

    test('Given EN too long - THEN error message appears and savin not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, '000', '111');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_EN_WRONG);
    });

    test('Given EN too short - THEN error message appears and savin not possible', async ({page}) => {
        await clickAddKguenButton(page);
        await fillOutKguEn(page, '000', '1');
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_EN_WRONG);
    });

    test('GIVEN KGU-EN duplicate - THEN Adding Certificate Type not possible', async ({page}) => {
        const inputKgu = '000';
        const inputEn = '00';

        await clickAddKguenButton(page);
        await fillOutKguEn(page, inputKgu, inputEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page, KGUEN_TEXT_MESSAGE_DUPLICATED_ENTRY);
    });
});
