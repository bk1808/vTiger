import {Page, test} from "@playwright/test";
import {
    deleteKguen,
    fillOutKguenAndIsActive,
    navigateToSystemAdministration,
    verifyKguenInSamDropdown
} from "./utils/testHelper";
import {DATA_TEST_ID_ADD_KGUEN_BUTTON, KGUEN_TEXT_SUCCESSFULLY_CREATED} from "./utils/constants";
import {navigateToBaseUrl} from "../../utils/testHelper";
import {saveEntryAndVerifySuccessMessage} from "../common/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.getByTestId('kgu-en-dashboard-button').click();
});

async function addKguenButtonClick(page: Page) {
    await page.waitForTimeout(1000);
    await page.getByTestId(DATA_TEST_ID_ADD_KGUEN_BUTTON).click();
}

test.describe("KGU-ENs in Sam Create Dropdown", () => {
    test("GIVEN Active Kguen - THEN KGU-EN included in Create-Sam dropdown list", async ({page}) => {
        const kgu = '000';
        const en = 'AA';

        await addKguenButtonClick(page);
        await fillOutKguenAndIsActive(page, kgu, en, true);
        await saveEntryAndVerifySuccessMessage(page, KGUEN_TEXT_SUCCESSFULLY_CREATED);

        await navigateToCreateSam(page);
        await verifyKguenInSamDropdown(page, kgu, en, true);

        //delete the kguen
        await navigateToSystemAdministration(page);
        await page.getByTestId('kgu-en-dashboard-button').click();
        await page.getByLabel("Go to next page").click(); //neccessary because the created kguen is on the second page.
        await deleteKguen(page, kgu, en);

        //kguen should not be visible in the dropdown
        await navigateToCreateSam(page);
        await verifyKguenInSamDropdown(page, kgu, en, false);
    })

    test("Given inactive Kgu-En - Then Kgu-En not in Dropdown for Sam Create", async ({page}) => {

        const kgu = '000';
        const en = 'BB';

        await addKguenButtonClick(page);
        await fillOutKguenAndIsActive(page, kgu, en, false);
        await saveEntryAndVerifySuccessMessage(page, KGUEN_TEXT_SUCCESSFULLY_CREATED);

        await navigateToCreateSam(page);
        await verifyKguenInSamDropdown(page, kgu, en, false);

        //delete the kguen
        await navigateToSystemAdministration(page);
        await page.getByTestId('kgu-en-dashboard-button').click();
        await page.getByLabel("Go to next page").click(); //neccessary because the created kguen is on the second page.
        await deleteKguen(page, kgu, en);

        //kguen should not be visible in the dropdown
        await navigateToCreateSam(page);
        await verifyKguenInSamDropdown(page, kgu, en, false);
    })
});
