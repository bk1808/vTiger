import {expect, Locator, Page, test} from "@playwright/test";
import {
    fillOutKguenAndIsActive,
    navigateToSystemAdministration
} from "./utils/testHelper";
import {
    getKguInputCell,
    getEnInputCell,
    getIsActiveCell
} from "./utils/selectors";
import {
    DATA_TEST_ID_ADD_KGUEN_BUTTON,
    KGUEN_TEXT_SUCCESSFULLY_CREATED,
    KGUEN_TEXT_SUCCESSFULLY_DELETED
} from "./utils/constants";
import {
    checkIfFieldVisibleEditableEmpty, deleteEntry,
    saveEntryAndVerifySuccessMessage,
    verifyThatEntryCannotBeSavedAndCancelEditing
} from "../common/testHelper";
import {navigateToBaseUrl} from "../../utils/testHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToSystemAdministration(page);
    await page.waitForTimeout(1000);
    await page.getByTestId('kgu-en-dashboard-button').click();
});

test.describe('KGU-EN table is editable with success messages', () => {
    test('GIVEN new Kgu-En - THEN all input fields are editable', async ({page}) => {
        const {
            kguInputCellLocator,
            enInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.waitForTimeout(1000);
        await page.getByTestId(DATA_TEST_ID_ADD_KGUEN_BUTTON).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(kguInputCellLocator, enInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(kguInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(enInputCellLocator);
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN new Kgu-En - THEN success message appears', async ({page}) => {
        await page.waitForTimeout(1000);
        await page.getByTestId(DATA_TEST_ID_ADD_KGUEN_BUTTON).click();
        const kguInput = '000';
        const enInput = '01';

        await deleteEntry(page, `${kguInput}-${enInput}`, KGUEN_TEXT_SUCCESSFULLY_DELETED);
        await fillOutKguenAndIsActive(page, kguInput, enInput, true);
        await saveEntryAndVerifySuccessMessage(page, KGUEN_TEXT_SUCCESSFULLY_CREATED);
    });
});

async function verifyThatInputFieldsDisappear(kguInputCellLocator: Locator, enInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(kguInputCellLocator).not.toBeVisible();
    await expect(enInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const kguInputCellLocator = getKguInputCell(page, dataRowIndex).locator('input');
    const enInputCellLocator = getEnInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveCell(page, dataRowIndex).locator('input');
    return {
        kguInputCellLocator,
        enInputCellLocator,
        isActiveInputCellLocator
    };
}
