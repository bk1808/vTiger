import {Page} from "@playwright/test";
import {selectDIVByRoleAndDataFieldAndColAndRowIndex} from "../../../utils/selector";

export function getKguInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "kgu", 0, dataRowIndex);
}

export function getEnInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "en", 1, dataRowIndex);
}

export function getIsActiveCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 2, dataRowIndex);
}