export const DATA_TEST_ID_ADD_KGUEN_BUTTON: string = 'add-kgu-en-button';

export const KGUEN_TEXT_SUCCESSFULLY_CREATED: string = 'Kgu-En successfully created.';
export const KGUEN_TEXT_SUCCESSFULLY_UPDATED: string = 'Kgu-En successfully updated.';
export const KGUEN_TEXT_SUCCESSFULLY_DELETED: string = 'Kgu-En successfully deleted..';

export const KGUEN_TEXT_MESSAGE_KGU_WRONG: string = 'KGU must be a 3-digit number';
export const KGUEN_TEXT_MESSAGE_EN_WRONG: string = 'The EN must be exactly 2 characters long and consist of only numbers or letters';
export const KGUEN_TEXT_MESSAGE_DUPLICATED_ENTRY: string = 'This combination of KGU and EN already exists.';