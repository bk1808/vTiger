import {expect, Page} from "@playwright/test";
import {
    getKguInputCell,
    getEnInputCell,
    getIsActiveCell
} from "./selectors";
import {SAM_FACTORY_SYSTEM_NAME_IDS} from "../../../utils/constants";

export async function navigateToSystemAdministration(page: Page) {
    // Select "System administration" in the side bar
    await page.getByTestId('sidebar-system-administration-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*administration-system/);
    await expect(page.getByTestId('system-administration-view')).toBeVisible();
    await expect(page.getByTestId('kgu-en-dashboard-button')).toBeVisible();
}

export async function fillOutKguenAndIsActive(page: Page, kgu: string, en: string, isActive: boolean) {
    const kguCellLocator = getKguInputCell(page).locator('input');
    const enInputCellLocator = getEnInputCell(page).locator('input');
    const isActiveInputCellLocator = getIsActiveCell(page).locator('input');

    await kguCellLocator.fill(kgu);
    await enInputCellLocator.fill(en);
    await isActiveInputCellLocator.setChecked(isActive);
}

export async function fillOutKguEn(page: Page, kgu: string, en: string) {
    const kguCellLocator = getKguInputCell(page).locator('input');
    const enInputCellLocator = getEnInputCell(page).locator('input');

    await kguCellLocator.fill(kgu);
    await enInputCellLocator.fill(en);
}

export async function verifyKguenInSamDropdown(page: Page, kgu: string, en: string, shouldBeInDropdown: boolean) {
    await page.getByText('DATA SOURCE').isVisible();
    await page.getByTestId("masterDataSystemId").click()
    await page.getByTestId(SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD).click()
    await expect(page.getByTestId("kguens")).toBeVisible()
    await expect(page.getByTestId("kguens")).toBeEditable()
    await page.getByTestId('kguens').click();
    await page.getByTestId('kguens').locator('div > input').fill(`${kgu}-${en}`);

    if (shouldBeInDropdown) {
        await expect(page.getByTestId(`${kgu}-${en}`)).toBeVisible();
    } else {
        await expect(page.getByTestId(`${kgu}-${en}`)).not.toBeVisible();
    }
}

export async function deleteKguen(page: Page, kgu: string, en: string) {
    const row = page.getByTestId(`${kgu}-${en}`);
    await row.getByTestId('DeleteIcon').click();
    await expect(page.getByText("Kgu-En successfully deleted.")).toBeVisible();
}
