import {expect, Locator, Page} from "@playwright/test";

export async function navigateToSystemAdministration(page: Page) {
    // Select "System administration" in the side bar
    await page.getByTestId('sidebar-system-administration-button').click();
    await expect(page).toHaveURL(/.*administration-system/);
    await expect(page.getByTestId('system-administration-view')).toBeVisible();
}

export async function checkIfFieldVisibleEditableEmpty(cell: Locator) {
    await expect(cell).toBeVisible();
    await expect(cell).toBeEmpty();
    await expect(cell).toBeEditable();
}

export async function verifyThatEntryCannotBeSavedAndCancelEditing(page: Page, message: string = '') {
    await expect(page.getByLabel('Save')).toBeDisabled();
    if (message != null && message != "") {
        await expect(page.getByText(message)).toBeVisible();
    }
    await expect(page.getByLabel('Cancel')).toBeEnabled();
    await page.getByLabel('Cancel').click();
}

export async function saveEntryAndVerifySuccessMessage(page: Page, successMessage: string) {
    const icon = await page.getByTestId('SaveIcon');
    await icon.waitFor({state: "visible"});

    // Note: Need to add a small timeout to give the Browser time to render otherwise this tests fails due to actions taken in milliseconds (There is surely a better way)
    await page.waitForTimeout(1000);

    await icon.click();
    await expect(page.getByText(successMessage)).toBeVisible();
}

export async function deleteEntry(page: Page, input: string, successMessage: string) {
    await page.waitForTimeout(1000);
    await page.getByTestId(`delete-button-${input}`).click();
    await page.getByText(successMessage).isVisible();
}