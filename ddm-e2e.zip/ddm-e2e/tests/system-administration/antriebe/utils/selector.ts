import {Page} from "@playwright/test";
import { selectDIVByRoleAndDataFieldAndColAndRowIndex } from "@root/tests/utils/selector";

export function getNameDeInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "nameDe", 0, dataRowIndex);
}

export function getNameEnInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "nameEn", 1, dataRowIndex);
}

export function getIsActiveInputCell(page: Page, dataRowIndex: number = 0) {
    return selectDIVByRoleAndDataFieldAndColAndRowIndex(page, "gridcell", "isActive", 2, dataRowIndex);
}