export const ANTRIEBE_CREATE_SUCCESS="Antriebe successfully created";
export const ANTRIEBE_DELETE_SUCCESS="Antriebe successfully deleted.";
export const ANTRIEBE_UPDATE_SUCCESS="Antriebe successfully updated.";
export const ANTRIEBE_NAMEDE_VALIDATION="Name (DE) must not be empty, cannot have Umlauts or be longer than 500 characters";
export const ANTRIEBE_NAMEEN_VALIDATION="Name (EN) must not be empty, cannot have Umlauts or be longer than 500 characters";
export const ANTRIEBE_NAMEDE_DUPLICATION="Name (DE) already exists";
export const ANTRIEBE_NAMEEN_DUPLICATION="Name (EN) already exists";