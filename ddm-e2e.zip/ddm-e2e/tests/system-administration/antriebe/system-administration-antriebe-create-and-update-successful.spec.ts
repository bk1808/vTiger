import {expect, Locator, Page, test} from "@playwright/test";
import {addNewEntry, fillOutAllTextFields, goToAntriebeMarketTab, markCheckboxIsActivated} from "./utils/testHelper";
import {getIsActiveInputCell, getNameDeInputCell, getNameEnInputCell} from "./utils/selector";
import { ADD_BUTTON_DATA_TEST_ID } from "../common/constants";
import { checkIfFieldVisibleEditableEmpty, deleteEntry, saveEntryAndVerifySuccessMessage, verifyThatEntryCannotBeSavedAndCancelEditing } from "../common/testHelper";
import { ANTRIEBE_CREATE_SUCCESS, ANTRIEBE_DELETE_SUCCESS, ANTRIEBE_UPDATE_SUCCESS } from "./utils/constant";



test.beforeEach(async ({page}) => {
    await goToAntriebeMarketTab(page);
});

test.describe('Antriebe created successfully', () => {
    test('GIVEN New Antriebe added - THEN all input fields are editable', async ({page}) => {
        const {
            nameEnInputCellLocator,
            nameDeInputCellLocator,
            isActiveInputCellLocator
        } = getLocatorsOfAllInputFields(page);

        await page.getByTestId(ADD_BUTTON_DATA_TEST_ID).click();
        await verifyThatInputFieldsAreChangeableByUser();
        await verifyThatEntryCannotBeSavedAndCancelEditing(page);
        await verifyThatInputFieldsDisappear(nameEnInputCellLocator, nameDeInputCellLocator, isActiveInputCellLocator);

        async function verifyThatInputFieldsAreChangeableByUser() {
            await checkIfFieldVisibleEditableEmpty(nameEnInputCellLocator);
            await checkIfFieldVisibleEditableEmpty(nameDeInputCellLocator);
            await expect(isActiveInputCellLocator).toBeEnabled();
            await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        }
    });

    test('GIVEN New Antriebe added - THEN success message appears', async ({page}) => {
        const nameEn = 'Name EN 1';
        const nameDe = 'Name DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_CREATE_SUCCESS);
        await deleteEntry(page, nameEn, ANTRIEBE_DELETE_SUCCESS);
    });

    test('GIVEN existing Antriebe in admin board - THEN Update success message appears', async ({page}) => {
        const nameEn = 'AName EN 2';
        const nameDe = 'AName DE 2';
        const updatedNameEn = 'AAUpdated Name EN';
        const updatedNameDe = 'AAUpdated Name DE';

        // Add initial entry
        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_CREATE_SUCCESS);

        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await markCheckboxIsActivated(page);

        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_UPDATE_SUCCESS);
        await deleteEntry(page, updatedNameEn, ANTRIEBE_DELETE_SUCCESS);
    });
});

function getLocatorsOfAllInputFields(page: Page, dataRowIndex: number = 0) {
    const nameEnInputCellLocator = getNameEnInputCell(page, dataRowIndex).locator('input');
    const nameDeInputCellLocator = getNameDeInputCell(page, dataRowIndex).locator('input');
    const isActiveInputCellLocator = getIsActiveInputCell(page, dataRowIndex).locator('input');
    return {
        nameEnInputCellLocator,
        nameDeInputCellLocator,
        isActiveInputCellLocator
    };
}

async function verifyThatInputFieldsDisappear(nameEnInputCellLocator: Locator, nameDeInputCellLocator: Locator, isActiveInputCellLocator: Locator) {
    await expect(nameEnInputCellLocator).not.toBeVisible();
    await expect(nameDeInputCellLocator).not.toBeVisible();
    await expect(isActiveInputCellLocator).not.toBeVisible();
}
