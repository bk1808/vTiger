import {test} from "@playwright/test";
import { addNewEntry, goToAntriebeMarketTab } from "./utils/testHelper";
import { verifyThatEntryCannotBeSavedAndCancelEditing } from "../common/testHelper";
import { ANTRIEBE_NAMEDE_VALIDATION, ANTRIEBE_NAMEEN_VALIDATION } from "./utils/constant";
import { LOREM_IPSUM_MORE_THAN_1000_CHARS } from "../common/constants";


test.beforeEach(async ({page}) => {
    await goToAntriebeMarketTab(page);
});

test.describe('Antriebe Create validations', () => {
    test('Given NameEn empty - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = '';
        const nameDe = 'Name DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEEN_VALIDATION)
    });

    test('Given NameDe empty - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = '';
        const nameEn = 'Name EN 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEDE_VALIDATION)
    });
    
    test('Given NameDe has umlauts - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = 'Strömbeam';
        const nameEn = 'Name EN 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEDE_VALIDATION)
    });
   
    test('Given NameEn has umlauts - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = 'Strömbeam';
        const nameDe = 'Name DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEEN_VALIDATION)
    });

    test('Given NameEn is more than 500 characters - THEN error message appears and saving not possible', async ({page}) => {
        const nameEn = LOREM_IPSUM_MORE_THAN_1000_CHARS;
        const nameDe = 'Name DE 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEEN_VALIDATION)
    });

    test('Given NameDe is more than 500 characters - THEN error message appears and saving not possible', async ({page}) => {
        const nameDe = LOREM_IPSUM_MORE_THAN_1000_CHARS;
        const nameEn = 'Name EN 1';

        await addNewEntry(page, nameEn, nameDe);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEDE_VALIDATION)
    });
});
