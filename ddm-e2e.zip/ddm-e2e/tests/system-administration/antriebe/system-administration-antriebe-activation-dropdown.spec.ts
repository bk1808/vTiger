import {expect, Page, test} from "@playwright/test";
import {deleteEntry, saveEntryAndVerifySuccessMessage} from "@root/tests/system-administration/common/testHelper";
import {navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";
import { addNewEntry, goToAntriebeMarketTab, markCheckboxIsActivated } from "./utils/testHelper";
import { ANTRIEBE_CREATE_SUCCESS, ANTRIEBE_DELETE_SUCCESS } from "./utils/constant";
import { SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS } from "@root/tests/utils/constants";


test.beforeEach(async ({page}) => {
    await goToAntriebeMarketTab(page);
});

test.describe('Antriebe activation and deactivation', () => {
    const nameEn1 = 'Activation Test EN 1';
    const nameDe1 = 'Activation Test DE 1';

    const nameEn2 = 'Deactivation Test EN 2';
    const nameDe2 = 'Deactivation Test DE 2';

    test('GIVEN new activated Antriebe - THEN it appears in dropdown', async ({page}) => {
        await addNewEntry(page, nameEn1, nameDe1);
        await markCheckboxIsActivated(page);
        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_CREATE_SUCCESS);

        const option = await createSamwithCertificationMarket(page,nameEn1)
        await expect(option).toBeVisible();
        await option.click();

        await goToAntriebeMarketTab(page);
        await deleteEntry(page, nameEn1, ANTRIEBE_DELETE_SUCCESS);
    });

    test('GIVEN new deactivated Antriebe - THEN it does not appear in dropdown', async ({page}) => {
        await addNewEntry(page, nameEn2, nameDe2);
        // Do not mark the checkbox as activated
        await expect(page.getByTestId('CheckBoxOutlineBlankIcon')).toBeVisible();
        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_CREATE_SUCCESS);

        const option = await createSamwithCertificationMarket(page,nameEn2)
        await expect(option).toBeHidden();

        await goToAntriebeMarketTab(page);
        await deleteEntry(page, nameEn2, ANTRIEBE_DELETE_SUCCESS);
    });
});

const createSamwithCertificationMarket = async(page:Page,name:string) => {
    await navigateToCreateSam(page);
    await page.getByTestId('samTypeId').click();
    await page.getByTestId(SAM_FACTORY_SAM_TYPE_IDS.DIRECT).click();

    await page.getByTestId('masterDataSystemId').click();
    await page.getByTestId(SAM_FACTORY_SYSTEM_NAME_IDS.ISTDAWO).click();

    await page.getByTestId('antriebe').click();
    return page.locator('li.MuiAutocomplete-option', { hasText: name });
}