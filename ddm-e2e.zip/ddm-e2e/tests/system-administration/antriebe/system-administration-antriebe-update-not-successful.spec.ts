import {test} from "@playwright/test";
import { addNewEntry, fillOutAllTextFields, goToAntriebeMarketTab } from "./utils/testHelper";
import { deleteEntry, saveEntryAndVerifySuccessMessage, verifyThatEntryCannotBeSavedAndCancelEditing } from "../common/testHelper";
import { ANTRIEBE_CREATE_SUCCESS, ANTRIEBE_DELETE_SUCCESS, ANTRIEBE_NAMEDE_VALIDATION, ANTRIEBE_NAMEEN_VALIDATION } from "./utils/constant";


test.beforeEach(async ({page}) => {
    await goToAntriebeMarketTab(page);
});

const nameEn = 'AName EN';
const nameDe = 'AName DE';

test.describe('Antriebe Update validations', () => {
    test('Given edited NameEn empty - THEN error message appears and saving not possible', async ({page}) => {
        const updatedNameEn = '';
        const updatedNameDe = 'AUpdated Name DE';

        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_CREATE_SUCCESS);
        
        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEEN_VALIDATION)

        await deleteEntry(page, nameEn, ANTRIEBE_DELETE_SUCCESS);
    });

    test('Given edited NameDe empty - THEN error message appears and saving not possible', async ({page}) => {
        const updatedNameEn = 'AUpdated Name EN';
        const updatedNameDe = '';

        await addNewEntry(page, nameEn, nameDe);
        await saveEntryAndVerifySuccessMessage(page, ANTRIEBE_CREATE_SUCCESS);
        
        // Update the entry
        await page.getByTestId(`edit-button-${nameEn}`).click();
        await fillOutAllTextFields(page, updatedNameDe, updatedNameEn);
        await verifyThatEntryCannotBeSavedAndCancelEditing(page,ANTRIEBE_NAMEDE_VALIDATION)

        await deleteEntry(page, nameEn, ANTRIEBE_DELETE_SUCCESS);
    });
});
