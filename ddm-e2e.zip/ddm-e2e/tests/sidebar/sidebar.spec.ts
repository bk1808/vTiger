import {test,expect} from "@playwright/test";
import { navigateToBaseUrl} from "../utils/testHelper";


test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Collapse and Expand Sidebar in DDM Dashboard', () => {
    test('GIVEN landed to base URL - THEN sidebar should be in expanded state', async ({page}) => {
        await expect(page.getByTestId('sidebar-open')).toBeVisible();
    });

    test('GIVEN sidebar collapse button is click - THEN sidebar should be in collapse state', async ({page}) => {
        await expect(page.getByTestId('sidebar-open')).toBeVisible();

        await page.getByTestId('sidebar-button').click();

        await expect(page.getByTestId('sidebar-close')).toBeVisible();
    });
});