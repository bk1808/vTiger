import {expect, test} from "@playwright/test";
import {fillSamFactoryFields} from "./utils/samCreationTestHelper";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {INPUT} from "../utils/locators";
import {
    DATA_SOURCE_SMARAGD_ID,
    FORMAT_TYPE_NO_VALUE_ID, FORMAT_TYPE_REGEX_ID,
    SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS,
    SAM_FACTORY_SAM_TYPE_IDS
} from "../utils/constants";
import {
    verifyThatDropdownFieldIsVisibleAndDisabled,
    verifyThatFreeTextFieldIsVisibleAndDisabled
} from "../utils/commonValidations";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);
});

const FEATURE_DATA_TYPE_DOCUMENT_ID = '11';

test.describe('Create and Edit SAM - Smaragd Meta Data', () => {
    test('GIVEN SAM Create with Sam Type Leg. Verf. Component - THEN Smaragd meta data are filled automatically and not changeable', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
        });

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.LEG_VERF_COMPONENT
        });

        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'featureDataTypeId');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'samFormatTypeId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueAmount');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueDefinition');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'masterDataSystemId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'defaultValue')

        await verifySamFactoryFields(page, {
            featureDataType: FEATURE_DATA_TYPE_DOCUMENT_ID,
            samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
            valueAmount: '1',
            valueDefinition: '^A\\d{10}$',
            masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
            defaultValue: '<SNR Number here>'
        })

        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await page.waitForURL(/.*sam-detail/);
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'featureDataTypeId');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'samFormatTypeId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueAmount');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueDefinition');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'masterDataSystemId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'defaultValue')

        await verifySamFactoryFields(page, {
            featureDataType: FEATURE_DATA_TYPE_DOCUMENT_ID,
            samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
            valueAmount: '1',
            valueDefinition: '^A\\d{10}$',
            masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
            defaultValue: '<SNR Number here>'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            featureDataType: FEATURE_DATA_TYPE_DOCUMENT_ID,
            samFormatType: `${FORMAT_TYPE_REGEX_ID}`,
            valueAmount: '1',
            valueDefinition: '^A\\d{10}$',
            masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
            defaultValue: '<SNR Number here>'
        })
    });

    test('GIVEN SAM Create with Sam Type Leg. Verf. Vehicle - THEN Smaragd meta data are filled automatically and not changeable', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
        });

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.LEG_VERF_VEHICLE
        });

        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'featureDataTypeId');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'samFormatTypeId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueAmount');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueDefinition');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'masterDataSystemId');

        await verifySamFactoryFields(page, {
            featureDataType: FEATURE_DATA_TYPE_DOCUMENT_ID,
            samFormatType: `${FORMAT_TYPE_NO_VALUE_ID}`,
            valueAmount: '',
            valueDefinition: '',
            masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
        })

        await expect(page.getByTestId('kguen-chip-000-99')).toBeVisible();
        await expect(page.getByTestId('kguen-chip-000-99').locator('button')).toBeDisabled();
        await expect(page.getByTestId('kguens').locator(INPUT)).toBeEditable();

        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'defaultValue');

        await verifySamFactoryFields(page, {
            defaultValue: ''
        })

        // fill mandatory legal verification drawing and submit
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            legalVerificationDrawing: SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS.GE_NACHWEIS
        })

        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await page.waitForURL(/.*sam-detail/);
        await expect(page).toHaveURL(/.*sam-detail/)

        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'featureDataTypeId' );
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'samFormatTypeId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueAmount');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueDefinition');
        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'masterDataSystemId');
        await expect(page.getByTestId('kguen-chip-000-99')).toBeVisible();
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'defaultValue');

        await verifySamFactoryFields(page, {
            featureDataType: FEATURE_DATA_TYPE_DOCUMENT_ID,
            samFormatType: `${FORMAT_TYPE_NO_VALUE_ID}`,
            valueAmount: '',
            valueDefinition: '',
            masterDataSystem: `${DATA_SOURCE_SMARAGD_ID}`,
            defaultValue: ''
        })
    });
});