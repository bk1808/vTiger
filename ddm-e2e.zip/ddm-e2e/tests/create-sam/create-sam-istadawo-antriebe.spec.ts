import {expect, test} from "@playwright/test";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {fillSamFactoryFields} from "./utils/samCreationTestHelper";
import {
    SAM_FACTORY_SYSTEM_NAME_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_ANTRIEBE_IDS
} from "../utils/constants";
import {
    verifyThatFreeTextFieldIsVisibleAndDisabled
} from "../utils/commonValidations";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Create and Edit SAM - ISTDaWo', () => {
    test('GIVEN Create SAM - THEN Verify Antriebe is not visible per default', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Check if field is visible per default
        await expect(page.getByTestId('antriebe')).toBeVisible({visible: false});

        // Submit Data
        await page.getByTestId('submit-button').click();
    });

    test('GIVEN - Create SAM - THEN Verify Antriebe field is only visible and not mandatory when SamType-Direct and MasterDataSystem-ISTDaWo is selected', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.ISTDAWO
        });

        // Check if field is visible per default
        await expect(page.getByTestId('antriebe')).toBeVisible();

        // Submit Data
        await page.getByTestId('submit-button').click();

        // Expect Sam Detail View after create sam
        await expect(page).toHaveURL(/.*sam-detail/);

    });

    test('GIVEN Create SAM with Antriebe Value- Then Antribe type is displayed correctly', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.ISTDAWO,
            antriebe: SAM_FACTORY_ANTRIEBE_IDS.DIESEL,
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await expect(page).toHaveURL(/.*sam-detail/);

        // Check if certus values are correctly displayed
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'antriebe');

        await verifySamFactoryFields(page, {
            antriebe: 'Diesel'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            antriebe: 'Diesel',
        })
    });
})