import {expect, Page, test} from "@playwright/test";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {goFromDetailViewToHistoryView, goToSamCreateForm, goToSamDashBoard, navigateToBaseUrl} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {fillSamFactoryFields} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await goToSamDashBoard(page);
    await goToSamCreateForm(page);
});

test.describe('Create SAM Additional Information', () => {
    test('GIVEN a SAM is created with empty additional information fields - THEN the SAM is successfully created (field is not mandatory)', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            supplementalInformationDe: '',
            supplementalInformationEn: ''
        })
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await page.getByTestId('Sam.DetailView.Edit.Button').click();
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn'
        })
        await page.getByTestId('submit-button').click();

        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn'
        });

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            supplementalInformationDe: 'supplementalInformationDe',
            supplementalInformationEn: 'supplementalInformationEn'
         });
    });

    test('GIVEN a SAM is created with invalid characters in additional information fields - THEN a validation message is displayed', async ({page}) => {
        // @ €
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            supplementalInformationDe: 'Lorem:ipsum @ dolor sit amet,',
            supplementalInformationEn: 'Lorem:ipsum € dolor sit amet,'
        })
        await submitAndVerifyAppearanceOfValidationMessage(page, "Character '@' is not allowed", "Character '€' is not allowed");

        // | \
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            supplementalInformationDe: 'Lorem:ipsum /\\/ dolor sit amet,',
            supplementalInformationEn: 'Lorem:ipsum | dolor sit amet,'
        })
        await submitAndVerifyAppearanceOfValidationMessage(page, "Character '\\' is not allowed", "Character '|' is not allowed");

        // ~
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            supplementalInformationDe: 'Lorem:ipsum ~ dolor sit amet,',
            supplementalInformationEn: 'Lorem:ipsum ~ dolor sit amet,'
        })
        await submitAndVerifyAppearanceOfValidationMessage(page, "Character '~' is not allowed");

        // { }
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            supplementalInformationDe: 'Lorem:ipsum { dolor sit amet,',
            supplementalInformationEn: 'Lorem:ipsum } dolor sit amet,'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, "Character '{' is not allowed", "Character '}' is not allowed");
    });
});

async function submitAndVerifyAppearanceOfValidationMessage(page: Page, validationMessageNameDe: string, validationMessageNameEn?: string) {
    await page.getByTestId('submit-button').click();
    await expect(page).toHaveURL(/.*sam-create/);

    await verifyIsEditableAndHasRedColorById(page, 'supplementalInformationDe');
    await verifyIsVisibleAndHasRedColorByText(page, validationMessageNameDe, 0);

    await verifyIsEditableAndHasRedColorById(page, 'supplementalInformationEn');
    const enMessage = validationMessageNameEn ?? validationMessageNameDe;
    const enIndex = validationMessageNameEn && validationMessageNameEn !== validationMessageNameDe ? 0 : 1;
    await verifyIsVisibleAndHasRedColorByText(page, enMessage, enIndex);
}