import {expect, test} from "@playwright/test";
import {
    FORMAT_TYPE_SELECT_FROM_LIST_ID,
    SAM_FACTORY_DATA_FORMAT_TYPE_IDS,
    SAM_FACTORY_DATA_TYPE_IDS
} from "../utils/constants";
import {
    verifyLabelHasRedColorById,
    verifyIsVisibleAndHasRedColorByText,
    verifyThatDropdownFieldIsVisibleAndDisabled,
    verifyThatFreeTextFieldIsVisibleAndDisabled
} from "../utils/commonValidations";
import {Messages} from "./utils/messages";
import {fillSamFactoryFields, getFeatureDataTypeRegularExpressionTestId, navigateToCreateSam} from "./utils/samCreationTestHelper";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

export function getUnitTestId(valueInput: string) {
    return `unit-${valueInput}`;
}

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCreateSam(page);
});

const REG_EX_ID: string = '3';

test.describe('Create SAM - Data Format Type', () => {
    test('GIVEN  Data Format Type Empty is selected - THEN Value  Amount and Value Definition are not visible', async ({page}) => {
        // Select "empty" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.EMPTY
        })

        //The data field does not change and can continue to be written
        await expect(page.getByTestId('formatTypeValueAmount')).not.toBeVisible();
        await expect(page.getByTestId('formatTypeValueDefinition')).not.toBeVisible();
        await expect(page.getByTestId('samFormatTypeId')).toBeEditable();
    });

    test('GIVEN Data Format Type No Value is selected - THEN Value Amount and Value Definition are visible but not editable', async ({page}) => {
        // Select "No Value" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.NO_VALUE
        })

        //Two new data fields appear:
        //1. "Amount of Values"
        await expect(page.getByTestId('formatTypeValueAmount')).toBeVisible();
        //2. "List of Value"
        await expect(page.getByTestId('formatTypeValueDefinition')).toBeVisible();
        // Filling the Field [Amount of Values] is not possible
        await expect(page.getByTestId('formatTypeValueAmount').locator('div > input')).not.toBeEditable();
        // Filling the Field [List of Values] is not possible
        await expect(page.getByTestId('formatTypeValueDefinition').locator('div > input')).not.toBeEditable();
    });

    test('GIVEN  Data Format Type RegEx is selected - THEN invalid pattern for Value Definition shows validation message', async ({page}) => {
        // Select "Regular Expression" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX
        })

        //Two new data fields appear:
        // 1. "Amount of Values"
        await expect(page.getByTestId('formatTypeValueAmount')).toBeVisible();
        // 2. "List of Value"
        await expect(page.getByTestId('formatTypeValueDefinition')).toBeVisible();
        // Filling the Field [Amount of Values] is not possible. Default value "1" cannot be changed
        await expect(page.getByTestId('formatTypeValueAmount').locator('div > input')).not.toBeEditable();

        await verifySamFactoryFields(page, {
            valueAmount: '1',
        })

        // Type no meta data at [List of Values] and press "Submit"
        await page.getByTestId('submit-button').click();
        // You stay on the current "SAM Create view" (SAM is not saved) and the "List of Values" field is highlighted with red text "invalid pattern".
        await expect(page).toHaveURL(/.*sam-create/);
        await verifyLabelHasRedColorById(page, 'formatTypeValueDefinition')
        await verifyIsVisibleAndHasRedColorByText(page, Messages.INVALID_REGEX_ERROR);
        // The Datafield is still writeable / selectable.
        await expect(page.getByTestId('formatTypeValueAmount').locator('div > input')).not.toBeEditable();

        // Fill in the Field [List of Values]
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.REG_EX,
            valueDefinition: ']['
        })

        //Invalid RegEx Pattern
        await verifyLabelHasRedColorById(page, 'formatTypeValueDefinition');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.INVALID_REGEX_ERROR);
    });

    test('GIVEN Data Format Type Select From List is selected without Value Amount and Value Definition data - THEN fields show required validation messages', async ({page}) => {
        // Select "Selection List" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST
        })

        // Two new data fields appear:
        // 1. "Amount of Values"
        await expect(page.getByTestId('formatTypeValueAmount')).toBeVisible();
        // 2. "List of Value"
        await expect(page.getByTestId('formatTypeValueDefinition')).toBeVisible();

        // Type no meta data in [Amaount of Values] and [List of Values] and press "Submit"
        await page.getByTestId('submit-button').click();
        // You stay on the current "SAM Create view" (SAM is not saved) and
        await expect(page).toHaveURL(/.*sam-create/);
        // the "List of Values" and "Amount of Values" fields are highlighted with red text "Field is required".
        await verifyLabelHasRedColorById(page, 'formatTypeValueAmount');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 4);

        await verifyLabelHasRedColorById(page, 'formatTypeValueDefinition');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 5);
        // The data field is still writeable / selectable.
        await expect(page.getByTestId('formatTypeValueAmount').locator('div > input')).toBeEditable();
        await expect(page.getByTestId('formatTypeValueDefinition').locator('div > textarea').first()).toBeEditable();
    });

    test('GIVEN Data Format Type Select From List is selected with invalid value amount - THEN validation message is displayed', async ({page}) => {
        // Select "Selection List" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST,
            valueAmount: 'a'
        })

        // An error message is displayed that this field may only be filled with one or two numbers separated by a comma "," may be filled in
        // random click to activate validation
        await page.getByTestId('samFormatTypeId').click();
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FORMAT_TYPE_VALUE_AMOUNT_ERROR);
    });

    test('GIVEN Data Format Type Select From List is selected with dot separated value - THEN only one box appears', async ({page}) => {
        // Select "Selection List" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST,
            valueDefinitionSelectFromList: 'Test1.Test2'
        })

        // Only one "box" appears next to the text field.
        await expect(page.getByTestId('select-from-list-value-0')).toBeVisible();
        await expect(page.getByTestId('select-from-list-value-1')).not.toBeVisible();
    });

    test('GIVEN Data Format Type Select From List is selected with valid Value Amount and Value Definition - THEN SAM is created successfully', async ({page}) => {
        // Select "Selection List" from the selection list.
        // Fill in the Field [Amount of Values][List of Values] with "1,2" and "Test 1, Test 2" and press "Submit"
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.SELECT_FROM_LIST,
            valueAmount: '1,2',
            valueDefinitionSelectFromList: 'Test1; Test2'
        })

        await expect(page.getByTestId('select-from-list-value-0')).toBeVisible();
        await expect(page.getByTestId('select-from-list-value-1')).toBeVisible();

        await page.getByTestId('submit-button').click();
        // // Redirecting to the SAM detail view page
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            samFormatType: `${FORMAT_TYPE_SELECT_FROM_LIST_ID}`,
            valueAmount: '1,2',
            valueDefinitionSelectFromList: 'Test1; Test2'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            samFormatType: `${FORMAT_TYPE_SELECT_FROM_LIST_ID}`,
            valueAmount: '1,2',
            valueDefinitionSelectFromList: 'Test1; Test2'
        })
    });

    test('GIVEN Data Format Type Free Text Not Empty is selected - THEN Value Amount and Value Definition are disabled', async ({page}) => {
        // Select "Text" from the selection list.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samFormatType: SAM_FACTORY_DATA_FORMAT_TYPE_IDS.FREE_TEXT_NOT_EMPTY
        })

        //Two new data fields appear:
        // 1. "Amount of Values"
        await expect(page.getByTestId('formatTypeValueAmount')).toBeVisible();
        // 2. "List of Value"
        await expect(page.getByTestId('formatTypeValueDefinition')).toBeVisible();
        // Filling the Field [Amount of Values] is not possible.
        await expect(page.getByTestId('formatTypeValueAmount').locator('div > input')).not.toBeEditable();

        await expect(page.getByTestId('formatTypeValueAmount')).toBeVisible();
        await expect(page.getByTestId('formatTypeValueDefinition')).toBeVisible();
        await expect(page.getByTestId('formatTypeValueAmount').locator('div > input')).not.toBeEditable();
        await expect(page.getByTestId('formatTypeValueDefinition').locator('div > input')).not.toBeEditable();
    });

    test('GIVEN SamCreate DataType NUMBER or DataType DATE selected - THEN mandatory Unit and List of Values fields can be set and SamFormatType Regex is filled and disabled', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything required aside of unit and featureDataTypeRegularExpression
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
        });

        // submit & verify
        await page.getByTestId('submit-button').click();

        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);

        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'samFormatTypeId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueAmount');

        await verifySamFactoryFields(page, {
            samFormatType: REG_EX_ID,
            valueAmount: '1',
        })

        // Fill everything required
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            unit: getUnitTestId('A'),
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId('1,23457E+12')
        });

        // verify Detail View
        await verifySamFactoryFields(page, {
            unit: 'A',
            featureDataTypeRegularExpression: '1,23457E+12',
        })

        // submit
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        // Fill in Date
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.DATE,
            featureDataTypeRegularExpression: getFeatureDataTypeRegularExpressionTestId('DD.MM.YYYY')
        });

        await verifyThatDropdownFieldIsVisibleAndDisabled(page, 'samFormatTypeId');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'formatTypeValueAmount');

        await verifySamFactoryFields(page, {
            samFormatType: REG_EX_ID,
            valueAmount: '1',
        })

        // submit
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // verify Detail View &  History View
        await verifySamFactoryFields(page, {
            featureDataTypeRegularExpression: 'DD.MM.YYYY',
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            featureDataTypeRegularExpression: 'DD.MM.YYYY',
        })
    });
});