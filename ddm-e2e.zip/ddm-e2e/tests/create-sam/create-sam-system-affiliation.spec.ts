import {expect, test} from "@playwright/test";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl,
    submitAndVerifyAppearanceOfValidationMessage
} from "../utils/testHelper";
import {INPUT} from "../utils/locators";
import {Messages} from "./utils/messages";
import {fillSamFactoryFields} from "./utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const SYSTEM_AFFILIATIONS: string = 'system-affiliations';

test.describe('Create System Affiliation', () => {
    test('GIVEN KGU-ENs are provided - THEN system affiliations field visibility and validation are verified', async ({page}) => {
        const kguensOutsideRange: string[] = ['899-00', '905-00'];
        const kguensInsideRange: string[] = ['900-00', '904-01'];
        const systemAffiliationAbbreviationOne: string = 'ENG.CTRL.';
        const systemAffiliationAbbreviationTwo: string = 'PAS';
        const systemAffiliationNameTwo: string = 'PARKING ASSIST'

        // Create new SAM
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            kguens: kguensOutsideRange
        })

        // The Attribute “System Affiliations” is not displayed
         await expect(page.getByTestId(SYSTEM_AFFILIATIONS)).not.toBeVisible();

        await page.getByTestId('kguens').getByTestId('CloseIcon').click();
        // Select a KGU-EN in the range from 900-xx to 904-xx
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            kguens: kguensInsideRange,
        })
        await submitAndVerifyAppearanceOfValidationMessage(page, SYSTEM_AFFILIATIONS, Messages.FIELD_IS_REQUIRED_ERROR);

        // Both abbreviations and the names of the system affiliations can be read and selected.
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            systemAffiliations: [systemAffiliationAbbreviationOne]
        })

        await page.getByTestId('system-affiliations').locator(INPUT).fill(systemAffiliationNameTwo);
        await page.getByTestId(`system-affiliation-value-${systemAffiliationAbbreviationTwo}`).click();
        // A “chip” with the abbreviation of the “System Affiliation” is filled in the attribute.
        await expect(page.getByTestId(`system-affiliation-chip-${systemAffiliationAbbreviationTwo}`)).toBeVisible();

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            systemAffiliations: [systemAffiliationAbbreviationOne, systemAffiliationAbbreviationTwo]
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            systemAffiliations: [systemAffiliationAbbreviationOne, systemAffiliationAbbreviationTwo]
        })
    });
});