import {expect, test} from "@playwright/test";
import {
    BLACK,
} from '../utils/constants';
import { verifyLabelHasRedColorById, verifyIsVisibleAndHasRedColorByText } from "../utils/commonValidations";
import {fillSamFactoryFields, navigateToCreateSam} from "./utils/samCreationTestHelper";
import {goFromDetailViewToHistoryView, navigateToBaseUrl} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Characteristics and Examples', () => {
    test('GIVEN no meta data is entered - THEN default value and notes fields have black labels (not mandatory) and validation messages are displayed for invalid inputs and SAM with valid data is created successfully', async ({page}) => {
        await navigateToCreateSam(page);

        //Type no Meta Data at [Expression][Notes for Expression] in the fields and press Submit
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-create/);
        await expect(page.getByTestId('defaultValue').locator('label')).toHaveCSS('color', BLACK);
        await expect(page.getByTestId('notesOnDefaultValue').locator('label')).toHaveCSS('color', BLACK);

        //Fill in the field defaultValue and field notesOnDefaultValue with valid characters
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            defaultValue: 'default value,',
            notesOnDefaultValue: 'notes on default value'
        })
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            defaultValue: 'default value,',
            notesOnDefaultValue: 'notes on default value'
        });

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            defaultValue: 'default value,',
            notesOnDefaultValue: 'notes on default value'
        });

        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        //Fill not allowed characters
        // @ €
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            defaultValue: 'Lorem:ipsum @ dolor sit amet,',
            notesOnDefaultValue: 'Lorem:ipsum € dolor sit amet'
        })
        await page.click('body');
        await verifyLabelHasRedColorById(page, 'defaultValue');
        await verifyLabelHasRedColorById(page, 'notesOnDefaultValue');
        await verifyIsVisibleAndHasRedColorByText(page,"Character '@' is not allowed", 0);
        await verifyIsVisibleAndHasRedColorByText(page,"Character '€' is not allowed", 0);

        // | \
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            defaultValue: 'Lorem:ipsum \\ dolor sit amet,',
            notesOnDefaultValue: 'Lorem:ipsum | dolor sit amet,'
        })
        await page.click('body');
        await verifyLabelHasRedColorById(page, 'defaultValue');
        await verifyLabelHasRedColorById(page, 'notesOnDefaultValue');
        await verifyIsVisibleAndHasRedColorByText(page,"Character '\\' is not allowed", 0);
        await verifyIsVisibleAndHasRedColorByText(page,"Character '|' is not allowed", 0);

        // ~
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            defaultValue: 'Lorem:ipsum ~ dolor sit amet,',
            notesOnDefaultValue: 'Lorem:ipsum ~ dolor sit amet,'
        })
        await page.click('body');
        await verifyLabelHasRedColorById(page, 'defaultValue');
        await verifyLabelHasRedColorById(page, 'notesOnDefaultValue');
        await verifyIsVisibleAndHasRedColorByText(page,"Character '~' is not allowed", 0);
        await verifyIsVisibleAndHasRedColorByText(page,"Character '~' is not allowed", 1);

        // { }
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            defaultValue: 'Lorem:ipsum { dolor sit amet,',
            notesOnDefaultValue: 'Lorem:ipsum } dolor sit amet,'
        })
        await page.click('body');
        await verifyLabelHasRedColorById(page, 'defaultValue');
        await verifyLabelHasRedColorById(page, 'notesOnDefaultValue');
        await verifyIsVisibleAndHasRedColorByText(page,"Character '{' is not allowed", 0);
        await verifyIsVisibleAndHasRedColorByText(page,"Character '}' is not allowed", 0);
    });
});