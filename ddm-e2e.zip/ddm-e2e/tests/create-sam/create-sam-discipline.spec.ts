import {expect, test} from "@playwright/test";
import {verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {fillSamFactoryFields, navigateToCreateSam} from "./utils/samCreationTestHelper";
import {SAM_FACTORY_DISCIPLINE_IDS} from "../utils/constants";
import {goFromDetailViewToHistoryView, navigateToBaseUrl} from "../utils/testHelper";
import {INPUT} from "@root/tests/utils/locators";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
const COMBINATION_OF_DISCIPLINE_AND_SAM_NAME_AREADY_EXISTS = 'A combination of Discipline, SAM Name DE and -EN already exists';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const DISCIPLINE_DOOR_LOCKS_AND_HINGES_EN = 'Door Locks and Hinges: Door Locks and Hinges';
const DISCIPLINE_DOOR_LOCKS_AND_HINGES_DE = 'Tueren-Schloesser-Scharniere: Tueren-Schloesser-Scharniere';

test.describe('Create SAM Discipline', () => {
    test('GIVEN a discipline is selected in German - THEN the corresponding English discipline and SAM ID are automatically filled and SAM is created successfully', async ({page}) => {
        await navigateToCreateSam(page);

        // Select a discipline from the drop-down menu of "Discipline (German)"
        // Type in characters, which are not part of a discipline -> Text 'No Options'
        await page.getByTestId('disciplineId-de').click();
        await page.getByTestId('disciplineId-de').locator(INPUT).type('YY');
        await expect(page.getByText('No options')).toBeVisible();
        // initialize Discipline German by clicking Discipline English
        await page.getByTestId('disciplineId-en').click();

        // Selection of typing is verified
        await page.getByTestId('disciplineId-de').click();
        await page.getByTestId('disciplineId-de').locator(INPUT).type('AIR');
        await page.getByTestId(SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE).isVisible();
        await page.getByTestId(SAM_FACTORY_DISCIPLINE_IDS.HEATING_VENTILATION_AIR_CONDITIONING_DE).isVisible();
        await page.getByTestId(SAM_FACTORY_DISCIPLINE_IDS.MOTORHAUBENVERRIEGELUNG).isHidden();

        // initialize Discipline German by clicking Discipline English
        await page.getByTestId('disciplineId-en').click();

        // Select a discipline from the drop-down menu of "Discipline (German)"
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            responsibleDisciplineDe: SAM_FACTORY_DISCIPLINE_IDS.TUEREN_SCHLOESSER_SCHARNIERE,
        });

        // 1. The corresponding English discipline is automatically filled in ""Discipline (English)""
        await verifySamFactoryFields(page, {
            responsibleDisciplineDe: DISCIPLINE_DOOR_LOCKS_AND_HINGES_DE,
            responsibleDisciplineEn: DISCIPLINE_DOOR_LOCKS_AND_HINGES_EN,
        })

        // 2. The associated Feature ID / SAM ID is automatically filled in.
        await expect(page.getByTestId('featurePrefix').locator('label')).toHaveText('SST');

        // The cross "Clear" to initialize the 3 discipline fields
        await page.getByTestId('disciplineId-de').click();
        await page.getByTestId('disciplineId-de').getByTestId('CloseIcon').click();
        // await page.getByTestId('CloseIcon').click();
        await expect(page.getByTestId('disciplineId-de').locator(INPUT)).toBeEmpty();
        await expect(page.getByTestId('disciplineId-en').locator(INPUT)).toBeEmpty();
        await expect(page.getByTestId('featurePrefix').locator('input')).toBeEmpty();
        await page.getByTestId('disciplineId-de').click(); // to close the dropdown

        // The combination of SAM Name and Discipline already exists
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            nameDe: 'System Affiliation: Before Revision',
            nameEn: 'System Affiliation: Before Revision',
            responsibleDisciplineDe: SAM_FACTORY_DISCIPLINE_IDS.CRASH_DE,
        });

        await verifyIsVisibleAndHasRedColorByText(page, COMBINATION_OF_DISCIPLINE_AND_SAM_NAME_AREADY_EXISTS);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            responsibleDisciplineDe: SAM_FACTORY_DISCIPLINE_IDS.TUEREN_SCHLOESSER_SCHARNIERE,
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            responsibleDisciplineDe: DISCIPLINE_DOOR_LOCKS_AND_HINGES_DE,
            responsibleDisciplineEn: DISCIPLINE_DOOR_LOCKS_AND_HINGES_EN,
        });

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            responsibleDisciplineDe: DISCIPLINE_DOOR_LOCKS_AND_HINGES_DE,
            responsibleDisciplineEn: DISCIPLINE_DOOR_LOCKS_AND_HINGES_EN,
        });
    });

    test('GIVEN a discipline is selected in English - THEN the corresponding German discipline and SAM ID are automatically filled', async ({page}) => {
        await navigateToCreateSam(page);

        // Select a discipline from the drop-down menu of "Discipline (English)"
        await page.getByTestId('disciplineId-en').click();
        await page.getByTestId(SAM_FACTORY_DISCIPLINE_IDS.DOOR_LOCKS_AND_HINGES).click();
        // 1. The corresponding German discipline is automatically filled in "Discipline (German)
        await verifySamFactoryFields(page, {
            responsibleDisciplineDe: DISCIPLINE_DOOR_LOCKS_AND_HINGES_DE,
            responsibleDisciplineEn: DISCIPLINE_DOOR_LOCKS_AND_HINGES_EN,
        })
        // 2. The associated Feature ID / SAM ID is automatically filled in
        await expect(page.getByTestId('featurePrefix').locator('label')).toHaveText('SST');
    });
});