import {expect, Page} from "@playwright/test";
import {
    SAM_FACTORY_DATA_TYPE_IDS,
    SAM_FACTORY_SYSTEM_NAME_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_DISCIPLINE_IDS
} from "../../utils/constants";
import {RandomStringProps, SamFactoryFillProps} from "./models";
import {format} from "date-fns";
import {INPUT, TEXTAREA} from "../../utils/locators";

export async function navigateToCreateSam(page: Page) {
    // Select "SAM" from the left menu bar
    await page.getByTestId('sidebar-sam-button').click();
    // Redirecting to "SAM Overview". A table of SAMs is provided
    await expect(page).toHaveURL(/.*sam-dashboard/);
    await expect(page.getByTestId('sam-view')).toBeVisible();

    // Using the "Create / New SAM" button on the left corner (See Fig.1)
    await page.getByTestId('create-sam-button').click();
    // Redirecting to the "SAM Create View" (See Fig.2)
    await expect(page).toHaveURL(/.*sam-create/);
}

export async function selectFirstDayOfNextMonth(page: Page) {
    await page.getByTestId('CalendarIcon').click();
    // Need to click twice in case we are at the first of the month
    await page.getByTestId('ArrowRightIcon').click({ clickCount: 2, delay: 1000 });
    await page.getByRole('dialog').getByRole('gridcell', {name: '1'}).first().click();
}

/**
 * Function to generate a random string
 *
 * @param props which allow to add a prefix and string length of the generated string
 */
export function generateRandomString(props?: RandomStringProps): string {
    const length: number = props?.length ?? 3;
    const prefix: string = props?.prefix || '';

    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomString = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        randomString += characters[randomIndex];
    }

    return prefix + randomString;
}

/**
 * Dynamic function to fill based on given parameters, the given field
 *
 * @param page we are currently located at
 * @param fieldFunction to call which contains form field fill logic
 * @param fieldValue to enter in the wanted field
 * @param autoFill defines if we want a random value getting filled in the given mandatory field
 * @param generateValueFunction to generate given field value
 */
async function fillMandatoryField(page: Page, fieldFunction: Function, fieldValue: any, autoFill: boolean, generateValueFunction: Function) {
    if (autoFill || fieldValue) {
        await fieldFunction(page, fieldValue ?? generateValueFunction());
    }
}

/**
 * Function to fill all wanted SamFactory fields.
 *
 * If Field is left out empty, it will be left empty
 * If Mandatory field is left out empty, it will be filled with a random value
 *
 * @param page we currently at
 * @param props to fill samFactory fields as data-test-ids
 */
export async function fillSamFactoryFields(page: Page, props?: SamFactoryFillProps) {

    const fillMandatoryFieldsAuto = props?.fillMandatoryFieldsAutomatically ?? true;

    const {
        summary,
        explanation,
        targetDate,
        responsibleDisciplineDe,
        nameDe,
        nameEn,
        featureDataType,
        samType,
        samFormatType,
        valueDefinitionSelectFromList,
        valueDefinition,
        valueAmount,
        certusCertificateType,
        certusCertificateTopic,
        certusMarket,
        certusAdditionalSpecification,
        certusFunction,
        antriebe,
        defaultValue,
        notesOnDefaultValue,
        legalVerificationDrawing,
        masterDataSystem,
        supplementalInformationDe,
        supplementalInformationEn,
        freeAttributeDe,
        freeAttributeEn,
        certificationMarketDe,
        systemAffiliations,
        kguens,
        ruleType,
        derivedFeatureCluster,
        derivedFeatureDelimiter,
        derivedFeatureValuePosition,
        derivedFeatureCondition,
        derivedFeatureConditionValue,
        derivedFeatureValueExplanation,
        derivedFeatureValueInputOneSamId,
        derivedFeatureValueInputTwoSamId,
        derivedFeatureValueOutputValue,
        featureDataTypeRegularExpression,
        unit,
        derivedFeatureValueApplicationLayer
    } = props || {};

    // Mandatory Fields can vary depending on selection
    // Mandatory Fields
    const currentDate = new Date();
    const inputDate = new Date(currentDate.getFullYear() + 1, currentDate.getMonth(), currentDate.getDay())
    await fillMandatoryField(page, fillDateTime, targetDate, fillMandatoryFieldsAuto, () => inputDate);
    await fillMandatoryField(page, fillSummary, summary, fillMandatoryFieldsAuto, generateRandomString);
    await fillMandatoryField(page, fillExplanation, explanation, fillMandatoryFieldsAuto, generateRandomString);
    await fillMandatoryField(page, selectDisciplineDe, responsibleDisciplineDe, fillMandatoryFieldsAuto, () => SAM_FACTORY_DISCIPLINE_IDS.ALCOHOL_INTERLOCK_DE);
    await fillMandatoryField(page, fillSamNameEn, nameEn, fillMandatoryFieldsAuto, () => 'NAME_EN:' + generateRandomString());
    await fillMandatoryField(page, fillSamNameDe, nameDe, fillMandatoryFieldsAuto, () => 'NAME_DE:' + generateRandomString());
    await fillMandatoryField(page, selectSamType, samType, fillMandatoryFieldsAuto, () => SAM_FACTORY_SAM_TYPE_IDS.DIRECT);
    await fillMandatoryField(page, selectMasterDataSystem, masterDataSystem, fillMandatoryFieldsAuto, () => SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD);
    await fillMandatoryField(page, selectFeatureDataType, featureDataType, fillMandatoryFieldsAuto, () => SAM_FACTORY_DATA_TYPE_IDS.UNDEFINED);
    // Non Mandatory Fields
    if (samFormatType) await selectSamFormatType(page, samFormatType);
    if (valueAmount) await fillFormatTypeValueAmount(page, valueAmount);
    if (valueDefinitionSelectFromList) await fillValueDefinitionOfFormatTypeSelectFromList(page, valueDefinitionSelectFromList);
    if (valueDefinition) await fillValueDefinition(page, valueDefinition);
    if (kguens) await selectKguens(page, kguens);
    if (systemAffiliations) await selectSystemAffiliations(page, systemAffiliations);
    if (legalVerificationDrawing) await selectLegalVerificationDrawing(page, legalVerificationDrawing);
    if (certusMarket) await selectCertusMarket(page, certusMarket);
    if (certusCertificateTopic) await selectCertusCertificateTopic(page, certusCertificateTopic);
    if (certusCertificateType) await selectCertusType(page, certusCertificateType);
    if (certusAdditionalSpecification) await selectCertusAdditionalSpecification(page, certusAdditionalSpecification);
    if (certusFunction) await selectCertusFunction(page, certusFunction);
    if (antriebe) await selectAntriebeType(page, antriebe);
    if (certificationMarketDe) await selectCertificationMarketDe(page,certificationMarketDe);
    if (supplementalInformationDe) await fillSupplementalInformationDe(page, supplementalInformationDe);
    if (supplementalInformationEn) await fillSupplementalInformationEn(page, supplementalInformationEn);
    if (freeAttributeDe) await fillFreeAttributeDe(page, freeAttributeDe);
    if (freeAttributeEn) await fillFreeAttributeEn(page, freeAttributeEn);
    if (defaultValue) await fillDefaultValue(page, defaultValue);
    if (notesOnDefaultValue) await fillNotesOnDefaultValue(page, notesOnDefaultValue);
    if (derivedFeatureCluster) await selectDerivedFeatureCluster(page, derivedFeatureCluster);
    if (ruleType) await selectRuleType(page, ruleType);
    if (derivedFeatureValueExplanation) await fillDerivedFeatureValueExplanation(page, derivedFeatureValueExplanation);
    if (derivedFeatureValueInputOneSamId) await selectDerivedFeatureValueInputOneSamId(page, derivedFeatureValueInputOneSamId);
    if (derivedFeatureValueInputTwoSamId) await selectDerivedFeatureValueInputTwoSamId(page, derivedFeatureValueInputTwoSamId);
    if (derivedFeatureValueOutputValue) await fillDerivedFeatureValueOutputValue(page, derivedFeatureValueOutputValue);
    if (derivedFeatureDelimiter) await fillDerivedFeatureDelimiter(page, derivedFeatureDelimiter);
    if (derivedFeatureValuePosition) await fillDerivedFeaturePosition(page, derivedFeatureValuePosition);
    if (derivedFeatureConditionValue) await fillDerivedFeatureConditionValue(page, derivedFeatureConditionValue);
    if (derivedFeatureCondition) await selectDerivedFeatureCondition(page, derivedFeatureCondition);
    if (derivedFeatureValueApplicationLayer) await selectDerivedFeatureValueApplicationLayer(page, derivedFeatureValueApplicationLayer);
    if (featureDataTypeRegularExpression) await selectFeatureDataTypeRegularExpression(page, featureDataTypeRegularExpression);
    if (unit) await selectUnit(page, unit);
}

export async function selectFeatureDataTypeRegularExpression(page: Page, featureDataTypeRegularExpression: string) {
    await page.getByTestId('featureDataTypeRegularExpression').click();
    await page.getByTestId(featureDataTypeRegularExpression).click();
}

export async function selectDerivedFeatureValueApplicationLayer(page: Page, applicationLayer: string) {
    await page.getByTestId('derivedFeatureApplicationLayer').click();
    await page.getByTestId(applicationLayer).click();
}

export async function selectUnit(page: Page, unit: string) {
    await page.getByTestId('unit').click();
    await page.getByTestId(unit).click();
}

export async function selectDerivedFeatureCondition(page: Page, derivedFeatureCondition: string) {
    await page.getByTestId('derivedFeatureCondition').click();
    await page.getByTestId(derivedFeatureCondition).click();
}

export async function selectDerivedFeatureCluster(page: Page, derivedFeatureCluster: string) {
    await page.getByTestId('derivedFeatureCluster').click();
    await page.getByTestId(derivedFeatureCluster).click();
}

export async function fillDerivedFeatureConditionValue(page: Page, derivedFeatureConditionValue: string) {
    await page.getByTestId('derivedFeatureConditionValue').locator(INPUT).fill(derivedFeatureConditionValue);
}

export async function fillDerivedFeaturePosition(page: Page, derivedFeatureValuePosition: string) {
    await page.getByTestId('derivedFeaturePosition').locator(INPUT).fill(derivedFeatureValuePosition);
}

export async function fillDerivedFeatureDelimiter(page: Page, derivedFeatureDelimiter: string) {
    await page.getByTestId('derivedFeatureDelimiter').locator(INPUT).fill(derivedFeatureDelimiter);
}

export async function selectDerivedFeatureValueInputTwoSamId(page: Page, derivedFeatureValueInputTwoSamId: string) {
    await page.getByTestId('derivedFeatureValueInputTwoSamId').click();
    await page.getByTestId(derivedFeatureValueInputTwoSamId).click();
}

export async function selectDerivedFeatureValueInputOneSamId(page: Page, derivedFeatureValueInputOneSamId: string) {
    await page.getByTestId('derivedFeatureValueInputOneSamId').click();
    await page.getByTestId(derivedFeatureValueInputOneSamId).click();
}

export async function fillDerivedFeatureValueExplanation(page: Page, derivedFeatureValueExplanation: string) {
    await page.getByTestId('derivedFeatureValueExplanation').locator(INPUT).fill(derivedFeatureValueExplanation);
}

export async function fillDerivedFeatureValueOutputValue(page: Page, derivedFeatureValueOutputValue: string) {
    await page.getByTestId('derivedFeatureValueOutputValue').locator(INPUT).fill(derivedFeatureValueOutputValue);
}

export async function selectRuleType(page: Page, ruleType: string) {
    await page.getByTestId('ruleType').click();
    await page.getByTestId(ruleType).click();
}

export async function fillNotesOnDefaultValue(page: Page, notesOnDefaultValue: string) {
    await page.getByTestId('notesOnDefaultValue').locator(INPUT).fill(notesOnDefaultValue);
}

export async function fillDefaultValue(page: Page, defaultValue: string) {
    await page.getByTestId('defaultValue').locator(INPUT).fill(defaultValue);
}

export async function fillSupplementalInformationEn(page: Page, supplementalInformationEn: string) {
    await page.getByTestId('supplementalInformationEn').locator(INPUT).fill(supplementalInformationEn);
}

export async function fillSupplementalInformationDe(page: Page, supplementalInformationDe: string) {
    await page.getByTestId('supplementalInformationDe').locator(INPUT).fill(supplementalInformationDe);
}

export async function fillFreeAttributeDe(page: Page, freeAttributeDe: string) {
    await page.getByTestId('freeAttributeDe').locator(INPUT).fill(freeAttributeDe);
}

export async function fillFreeAttributeEn(page: Page, freeAttributeEn: string) {
    await page.getByTestId('freeAttributeEn').locator(INPUT).fill(freeAttributeEn);
}


export async function selectCertusType(page: Page, certusType: string) {
    await page.getByTestId('certusCertificateTypes').getByTestId('ArrowDropDownIcon').click();
    await page.getByTestId(certusType).click();
}

export async function selectCertusCertificateTopic(page: Page, certusTopic: string) {
    await page.getByTestId('certusCertificateTopic').click();
    await page.getByTestId(certusTopic).click();
}

export async function selectCertusMarket(page: Page, certusMarket: string) {
    await page.getByTestId('certusMarket').click();
    await page.getByTestId(certusMarket).click();
}

export async function selectCertusAdditionalSpecification(page: Page, certusAdditionalSpecification: string) {
    await page.getByTestId('certusAdditionalSpecification').click();
    await page.getByTestId(certusAdditionalSpecification).click();
}

export async function selectCertusFunction(page:Page,certusFunction:string){
    await page.getByTestId('certusFunction').click();
    await page.getByTestId(certusFunction).click();
}

export async function selectAntriebeType(page:Page,antriebe:string){
    await page.getByTestId('antriebe').click();
    await page.getByTestId(antriebe).click();
}

export async function selectLegalVerificationDrawing(page: Page, legalVerificationDrawing: string) {
    await page.getByTestId('legal-verification-drawing').click();
    await page.getByTestId(legalVerificationDrawing).click();
}

export async function selectSystemAffiliations(page: Page, systemAffiliations: string[]) {
    const systemAffiliationTestIdMap: Record<string, string> = {
        'ENG.CTRL.': 'MR',
        'PAS': 'PAS',
        'CPCM': 'CPCM'
    };

    for (const sa of systemAffiliations) {
        const testId = systemAffiliationTestIdMap[sa];
        await page.getByTestId('system-affiliations').click();
        await page.getByTestId('system-affiliations').locator(INPUT).fill(sa);
        await page.getByTestId(`system-affiliation-value-${testId}`).click();
        await expect(page.getByTestId(`system-affiliation-chip-${testId}`)).toBeVisible();
    }
}

export async function selectKguens(page: Page, kguens: string[]) {
    for (const kguen of kguens) {
        await page.getByTestId('kguens').click();
        await page.getByTestId('kguens').locator(INPUT).fill(kguen);
        await page.getByTestId(kguen).click();
        await expect(page.getByTestId(`kguen-chip-${kguen}`)).toBeVisible();
    }
}

export async function fillValueDefinitionOfFormatTypeSelectFromList(page: Page, valueDefinitionSelectFromList: string) {
    await page.getByTestId('formatTypeValueDefinition').locator(TEXTAREA).first().fill(valueDefinitionSelectFromList);
}

export async function fillValueDefinition(page: Page, valueDefinition: string) {
    await page.getByTestId('formatTypeValueDefinition').locator(INPUT).first().fill(valueDefinition);
}

export async function fillFormatTypeValueAmount(page: Page, formatTypeValueAmount: string) {
    await page.getByTestId('formatTypeValueAmount').locator(INPUT).fill(formatTypeValueAmount);
}

export async function selectSamFormatType(page: Page, samFormatType: string) {
    await page.getByTestId('samFormatTypeId').click();
    await page.getByTestId(samFormatType).click();
}

export async function selectFeatureDataType(page: Page, featureDataType: string) {
    await page.getByTestId('featureDataTypeId').click();
    await page.getByTestId(featureDataType).click();
}

export async function selectMasterDataSystem(page: Page, masterDataSystem: string) {
    await page.getByTestId('masterDataSystemId').click();
    await page.getByTestId(masterDataSystem).click();
}

export async function selectSamType(page: Page, samTypeId: string) {
    await page.getByTestId('samTypeId').click();
    await page.getByTestId(samTypeId).click();
}

export async function fillSamNameEn(page: Page, name: string) {
    await page.getByTestId('nameEn').locator(INPUT).fill(name);
}

export async function fillSamNameDe(page: Page, name: string) {
    await page.getByTestId('nameDe').locator(INPUT).fill(name);
}

export async function selectDisciplineDe(page: Page, discipline: string) {
    await page.getByTestId('disciplineId-de').click();
    await page.getByTestId(discipline).first().click();
}

export async function selectCertificationMarketDe(page: Page, certificationMarket: string) {
    await page.getByTestId('certificationMarketDe').click();
    await page.getByTestId(certificationMarket).first().click();
}

export async function fillExplanation(page: Page, explanation: string) {
    await page.getByTestId('explanation').fill(explanation);
}

export async function fillSummary(page: Page, summary: string) {
    await page.getByTestId('summary').locator(TEXTAREA).first().fill(summary);
}

export async function fillDateTime(page: Page, date: Date) {
    await page.getByTestId('create-sam-date-picker').click();
    await page.getByTestId('create-sam-date-picker').fill(format(date, 'dd/MM/yyyy'));
}

export function getFeatureDataTypeRegularExpressionTestId(templateInput: string) {
    return `featureDataTypeRegularExpression-${templateInput}`;
}
