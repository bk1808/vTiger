// Important!
// The parameter refer to data-test-ids
export type SamFactoryFillProps = {
    // Control whether to fill mandatory fields automatically
    fillMandatoryFieldsAutomatically?: boolean;

    // Change Block
    summary?: string;
    explanation?: string;
    targetDate?: Date | null;

    // Discipline Block
    responsibleDisciplineDe?: string;

    // Sam Name and Data Type Block
    nameDe?: string;
    nameEn?: string;
    featureDataType?: string;
    samType?: string;
    ruleType?: string;
    derivedFeatureCluster?: string;
    derivedFeatureDelimiter?: string;
    derivedFeatureValuePosition?: string;
    derivedFeatureCondition?: string;
    derivedFeatureConditionValue?: string;
    derivedFeatureValueExplanation?: string;
    derivedFeatureValueInputOneSamId?: string;
    derivedFeatureValueInputTwoSamId?: string;
    derivedFeatureValueOutputValue?: string;
    derivedFeatureValueApplicationLayer?: string;
    unit?: string;

    // Data Format Type Block
    samFormatType?: string;
    valueAmount?: string;
    valueDefinitionSelectFromList?: string;
    valueDefinition?: string;
    featureDataTypeRegularExpression?: string;
    // Data Source
    masterDataSystem?: string;
    kguens?: string[];
    systemAffiliations?: string[];
    legalVerificationDrawing?: string;
    // CERTUS
    certusCertificateType?: string;
    certusCertificateTopic?: string;
    certusMarket?: string;
    certusAdditionalSpecification?: string;
    certusFunction?:string;
    //ISTDaWo
    antriebe?: string;

    // Additional Information Block
    certificationMarketDe?: string;
    supplementalInformationDe?: string;
    supplementalInformationEn?: string;
    freeAttributeDe?: string;
    freeAttributeEn?: string;

    // Characteristics and Examples Block
    defaultValue?: string;
    notesOnDefaultValue?: string;
}

export type SamFactoryVerifyProps = {
    // Change Block
    summary?: string;
    explanation?: string;
    targetDate?: Date | null;

    // Discipline Block
    responsibleDisciplineDe?: string;
    responsibleDisciplineEn?: string;

    // Sam Name and Data Type Block
    nameDe?: string;
    nameEn?: string;
    featureDataType?: string;
    samType?: string;
    ruleType?: string;
    derivedFeatureCluster?: string;
    derivedFeatureDelimiter?: string;
    derivedFeatureValuePosition?: string;
    derivedFeatureCondition?: string;
    derivedFeatureConditionValue?: string;
    derivedFeatureValueExplanation?: string;
    derivedFeatureValueInputOneSamId?: string;
    derivedFeatureValueInputTwoSamId?: string;
    derivedFeatureValueOutputValue?: string;
    derivedFeatureValueApplicationLayer?: string;
    unit?: string;

    // Data Format Type Block
    samFormatType?: string;
    valueAmount?: string;
    valueDefinitionSelectFromList?: string;
    valueDefinition?: string;
    featureDataTypeRegularExpression?: string;

    // Data Source
    masterDataSystem?: string;
    kguens?: string[];
    systemAffiliations?: string[];
    legalVerificationDrawing?: string;
    // CERTUS
    certusCertificateType?: string;
    certusCertificateTopic?: string;
    certusMarket?: string;
    certusAdditionalSpecification?: string;
    certusFunction?:string;
    //ISTDaWo
    antriebe?: string;

    // Additional Information Block
    certificationMarketDe?: string;
    certificationMarketEn?: string;
    supplementalInformationDe?: string;
    supplementalInformationEn?: string;
    freeAttributeDe?: string;
    freeAttributeEn?: string;

    // Characteristics and Examples Block
    defaultValue?: string;
    notesOnDefaultValue?: string;

    verifyEquality?: {
        kguens?: boolean;
        systemAffiliations?: boolean;
        legalVerificationDrawing?: boolean;

        summary?: boolean;
        targetDate?: boolean;
        explanation?: boolean;

        nameDe?: boolean;
        nameEn?: boolean;

        responsibleDisciplineDe?: boolean;
        responsibleDisciplineEn?: boolean;

        samType?: boolean;

        certificationMarketDe?: boolean;
        certificationMarketEn?: boolean;

        supplementalInformationDe?: boolean;
        supplementalInformationEn?: boolean;

        freeAttributeDe?: boolean;
        freeAttributeEn?: boolean;

        defaultValue?: boolean;
        notesOnDefaultValue?: boolean;

        certusCertificateType?: boolean;
        certusCertificateTopic?: boolean;
        certusMarket?: boolean;
        certusAdditionalSpecification?: boolean;
        certusFunction?:boolean;

        antriebe?: boolean;

        samFormatType?: boolean;
        featureDataTypeRegularExpression?: boolean;
        valueAmount?: boolean;
        valueDefinition?: boolean;
        valueDefinitionSelectFromList?: boolean;

        derivedFeatureCluster?: boolean;
        derivedFeatureValueApplicationLayer?: boolean;
        derivedFeatureValueInputOneSamId?: boolean;
        derivedFeatureValueInputTwoSamId?: boolean;
        derivedFeatureValueExplanation?: boolean;
        derivedFeatureCondition?: boolean;
        derivedFeatureConditionValue?: boolean;
        derivedFeatureValueOutputValue?: boolean;
        derivedFeatureValuePosition?: boolean;
        derivedFeatureDelimiter?: boolean
        ruleType?: boolean;

        masterDataSystem?: boolean;

        featureDataType?: boolean;
        unit?: boolean;
        // Add other fields as needed
    };
}

export type RandomStringProps = {
    length?: number;
    prefix?: string;
};