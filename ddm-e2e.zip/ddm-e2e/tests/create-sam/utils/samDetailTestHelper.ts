import {expect, Locator, Page} from "@playwright/test";
import { SamFactoryVerifyProps} from "./models";
import {INPUT, TEXTAREA} from "@root/tests/utils/locators";
import {format} from "date-fns";

/**
 * Verifies the visibility and values of specified SamFactory fields.
 *
 * - If a field is not provided, it will not be checked.
 * - If a visibility property is not provided or set to true, it will check if the field is visible.
 * - If a visibility property is set to false, it will check if the field is not visible.
 * Handles value definitions based on the selected DataFormatType
 * @param {Object} params - Function parameters
 * @param {string} params.DataFormatType - The selected format type (RegEx|FreeTextNotEmpty|NoValue|SelectFromList|Empty)
 * @param {string} [params.valueDefinition] - The value definition for RegEx, Free Text Not Empty, or No Value types
 * @param {string} [params.valueDefinitionSelectFromList] - The value definition when Select From List is chosen
 * When chosen Empty field as DataFormatType then Not visible both field valueDefinition or valueDefinitionSelectFromList
 * @param page The current page instance.
 * @param props The properties to verify SamFactory fields and their input values.
 */
export async function verifySamFactoryFields(page: Page, props?: SamFactoryVerifyProps) {
    const {
        summary,
        explanation,
        targetDate,
        responsibleDisciplineDe,
        responsibleDisciplineEn,
        nameDe,
        nameEn,
        featureDataType,
        samType,
        samFormatType,
        valueDefinitionSelectFromList,
        valueDefinition,
        valueAmount,
        certusCertificateType,
        certusCertificateTopic,
        certusMarket,
        certusAdditionalSpecification,
        certusFunction,
        antriebe,
        defaultValue,
        notesOnDefaultValue,
        legalVerificationDrawing,
        masterDataSystem,
        certificationMarketDe,
        certificationMarketEn,
        supplementalInformationDe,
        supplementalInformationEn,
        freeAttributeDe,
        freeAttributeEn,
        systemAffiliations,
        kguens,
        ruleType,
        derivedFeatureCluster,
        derivedFeatureDelimiter,
        derivedFeatureValuePosition,
        derivedFeatureCondition,
        derivedFeatureConditionValue,
        derivedFeatureValueExplanation,
        derivedFeatureValueInputOneSamId,
        derivedFeatureValueInputTwoSamId,
        derivedFeatureValueOutputValue,
        featureDataTypeRegularExpression,
        unit,
        derivedFeatureValueApplicationLayer,
        verifyEquality
    } = props || {};

    // Check for DetailView Fields
    if (summary) await verifySummary(page, summary, verifyEquality?.summary ?? true);
    if (explanation) await verifyExplanation(page, explanation, verifyEquality?.explanation ?? true);
    if (targetDate) await verifyTargetDate(page, format(targetDate, 'dd/MM/yyyy'), verifyEquality?.targetDate ?? true);
    if (responsibleDisciplineDe) await verifyResponsibleDisciplineDe(page, responsibleDisciplineDe, verifyEquality?.responsibleDisciplineDe ?? true);
    if (responsibleDisciplineEn) await verifyResponsibleDisciplineEn(page, responsibleDisciplineEn, verifyEquality?.responsibleDisciplineEn ?? true);
    if (nameDe) await verifyNameDe(page, nameDe, verifyEquality?.nameDe ?? true);
    if (nameEn) await verifyNameEn(page, nameEn, verifyEquality?.nameEn ?? true);
    if (featureDataType) await verifyFeatureDataType(page, featureDataType, verifyEquality?.featureDataType ?? true);
    if (samType) await verifySamType(page, samType, verifyEquality?.samType ?? true);
    if (samFormatType) await verifySamFormatType(page, samFormatType, verifyEquality?.samFormatType ?? true);
    if (valueDefinitionSelectFromList) await verifyValueDefinitionOfSelectFromList(page, valueDefinitionSelectFromList, verifyEquality?.valueDefinitionSelectFromList ?? true);
    if (valueDefinition) await verifyValueDefinition(page, valueDefinition, verifyEquality?.valueDefinition ?? true);
    if (valueAmount) await verifyValueAmount(page, valueAmount, verifyEquality?.valueAmount ?? true);
    if (certusCertificateType) await verifyCertusCertificateType(page, certusCertificateType, verifyEquality?.certusCertificateType ?? true);
    if (certusCertificateTopic) await verifyCertusCertificateTopic(page, certusCertificateTopic, verifyEquality?.certusCertificateTopic ?? true);
    if (certusMarket) await verifyCertusMarket(page, certusMarket, verifyEquality?.certusMarket ?? true);
    if (certusAdditionalSpecification) await verifyCertusAdditionalSpecification(page, certusAdditionalSpecification, verifyEquality?.certusAdditionalSpecification ?? true);
    if (certusFunction) await verifyCertusFunction(page, certusFunction, verifyEquality?.certusFunction ?? true);
    if (antriebe) await verifyAntriebeType(page, antriebe, verifyEquality?.antriebe ?? true);
    if (defaultValue) await verifyDefaultValue(page, defaultValue, verifyEquality?.defaultValue ?? true);
    if (notesOnDefaultValue) await verifyNotesOnDefaultValue(page, notesOnDefaultValue, verifyEquality?.notesOnDefaultValue ?? true);
    if (legalVerificationDrawing) await verifyLegalVerificationDrawing(page, legalVerificationDrawing, verifyEquality?.legalVerificationDrawing ?? true);
    if (masterDataSystem) await verifyMasterDataSystem(page, masterDataSystem, verifyEquality?.masterDataSystem ?? true);
    if (certificationMarketDe) await verifyCertificationMarketDe(page, certificationMarketDe, verifyEquality?.certificationMarketDe ?? true);
    if (certificationMarketEn) await verifyCertificationMarketEn(page, certificationMarketEn, verifyEquality?.certificationMarketEn ?? true);
    if (supplementalInformationDe) await verifySupplementalInformationDe(page, supplementalInformationDe, verifyEquality?.supplementalInformationDe ?? true);
    if (supplementalInformationEn) await verifySupplementalInformationEn(page, supplementalInformationEn, verifyEquality?.supplementalInformationEn ?? true);
    if (freeAttributeDe) await verifyFreeAttributeDe(page, freeAttributeDe, verifyEquality?.freeAttributeDe ?? true);
    if (freeAttributeEn) await verifyFreeAttributeEn(page, freeAttributeEn, verifyEquality?.freeAttributeEn ?? true);
    if (systemAffiliations) await verifySystemAffiliations(page, systemAffiliations, verifyEquality?.systemAffiliations ?? true);
    if (kguens) await verifyKguens(page, kguens, verifyEquality?.kguens ?? true);
    if (ruleType) await verifyRuleType(page, ruleType, verifyEquality?.ruleType ?? true);
    if (derivedFeatureCluster) await verifyDerivedFeatureCluster(page, derivedFeatureCluster, verifyEquality?.derivedFeatureCluster ?? true);
    if (derivedFeatureDelimiter) await verifyDerivedFeatureDelimiter(page, derivedFeatureDelimiter, verifyEquality?.derivedFeatureDelimiter ?? true);
    if (derivedFeatureValuePosition) await verifyDerivedFeatureValuePosition(page, derivedFeatureValuePosition, verifyEquality?.derivedFeatureValuePosition ?? true);
    if (derivedFeatureCondition) await verifyDerivedFeatureCondition(page, derivedFeatureCondition, verifyEquality?.derivedFeatureCondition ?? true);
    if (derivedFeatureConditionValue) await verifyDerivedFeatureConditionValue(page, derivedFeatureConditionValue, verifyEquality?.derivedFeatureConditionValue ?? true);
    if (derivedFeatureValueExplanation) await verifyDerivedFeatureValueExplanation(page, derivedFeatureValueExplanation, verifyEquality?.derivedFeatureValueExplanation ?? true);
    if (derivedFeatureValueInputOneSamId) await verifyDerivedFeatureValueInputOneSamId(page, derivedFeatureValueInputOneSamId, verifyEquality?.derivedFeatureValueInputOneSamId ?? true);
    if (derivedFeatureValueInputTwoSamId) await verifyDerivedFeatureValueInputTwoSamId(page, derivedFeatureValueInputTwoSamId, verifyEquality?.derivedFeatureValueInputTwoSamId ?? true);
    if (derivedFeatureValueOutputValue) await verifyDerivedFeatureValueOutputValue(page, derivedFeatureValueOutputValue, verifyEquality?.derivedFeatureValueOutputValue ?? true);
    if (featureDataTypeRegularExpression) await verifyFeatureDataTypeRegularExpression(page, featureDataTypeRegularExpression, verifyEquality?.featureDataTypeRegularExpression ?? true);
    if (unit) await verifyUnit(page, unit, verifyEquality?.unit ?? true);
    if (derivedFeatureValueApplicationLayer) await verifyDerivedFeatureValueApplicationLayer(page, derivedFeatureValueApplicationLayer, verifyEquality?.derivedFeatureValueApplicationLayer ?? true);
}

async function verifySummary(page: Page, summary: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('summary').locator(TEXTAREA).first(), summary, shouldBeEqual);
}

async function verifyExplanation(page: Page, explanation: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('explanation'), explanation, shouldBeEqual);
}

async function verifyTargetDate(page: Page, targetDate: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('create-sam-date-picker'), targetDate, shouldBeEqual)
}

async function verifyResponsibleDisciplineDe(page: Page, responsibleDisciplineDe: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('disciplineId-de').locator(INPUT), responsibleDisciplineDe, shouldBeEqual);
}

async function verifyResponsibleDisciplineEn(page: Page, responsibleDisciplineEn: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('disciplineId-en').locator(INPUT), responsibleDisciplineEn, shouldBeEqual);
}

async function verifyNameDe(page: Page, nameDe: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('nameDe').locator(INPUT), nameDe, shouldBeEqual);
}

async function verifyNameEn(page: Page, nameEn: string, shouldBeEqual: boolean) {
    verifyFieldValue(page.getByTestId('nameEn').locator(INPUT), nameEn, shouldBeEqual);
}

async function verifyFeatureDataType(page: Page, featureDataType: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('featureDataTypeId').locator(INPUT), featureDataType, shouldBeEqual);
}

async function verifySamType(page: Page, samType: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('samTypeId').locator(INPUT), samType, shouldBeEqual);
}

async function verifySamFormatType(page: Page, samFormatType: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('samFormatTypeId').locator(INPUT), samFormatType, shouldBeEqual);
}

async function verifyValueDefinition(page: Page, valueDefinition: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('formatTypeValueDefinition').locator(INPUT), valueDefinition, shouldBeEqual);
}

async function verifyValueDefinitionOfSelectFromList(page: Page, valueDefinitionSelectFromList: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('formatTypeValueDefinition').locator(TEXTAREA).first(), valueDefinitionSelectFromList, shouldBeEqual);
}

async function verifyValueAmount(page: Page, valueAmount: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('formatTypeValueAmount').locator(INPUT), valueAmount, shouldBeEqual);
}

async function verifyCertusCertificateType(page: Page, certusCertificateType: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certusCertificateTypes').locator(INPUT), certusCertificateType, shouldBeEqual);
}

async function verifyCertusCertificateTopic(page: Page, certusCertificateTopic: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certusCertificateTopic').locator(INPUT), certusCertificateTopic, shouldBeEqual);
}

async function verifyCertusMarket(page: Page, certusMarket: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certusMarket').locator(INPUT), certusMarket, shouldBeEqual);
}

async function verifyCertusAdditionalSpecification(page: Page, certusAdditionalSpecification: string,  shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certusAdditionalSpecification').locator(INPUT), certusAdditionalSpecification, shouldBeEqual);
}

async function verifyCertusFunction(page: Page, certusFunction: string,  shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certusFunction').locator(INPUT), certusFunction, shouldBeEqual);
}

async function verifyAntriebeType(page:Page, antriebe: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('antriebe').locator(INPUT), antriebe, shouldBeEqual);
}

async function verifyDefaultValue(page: Page, defaultValue: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('defaultValue').locator(INPUT), defaultValue, shouldBeEqual);
}

async function verifyNotesOnDefaultValue(page: Page, notesOnDefaultValue: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('notesOnDefaultValue').locator(INPUT), notesOnDefaultValue, shouldBeEqual);
}

async function verifyLegalVerificationDrawing(page: Page, legalVerificationDrawing: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('legal-verification-drawing').locator(INPUT), legalVerificationDrawing, shouldBeEqual);
}

async function verifyMasterDataSystem(page: Page, masterDataSystemId: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('masterDataSystemId').locator(INPUT), masterDataSystemId, shouldBeEqual);
}

async function verifyCertificationMarketDe(page: Page, certificationMarketDe: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certificationMarketDe').locator(INPUT), certificationMarketDe, shouldBeEqual);
}

async function verifyCertificationMarketEn(page: Page, certificationMarketEn: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('certificationMarketEn').locator(INPUT), certificationMarketEn, shouldBeEqual);
}

async function verifySupplementalInformationDe(page: Page, supplementalInformationDe: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('supplementalInformationDe').locator(INPUT), supplementalInformationDe, shouldBeEqual);
}

async function verifySupplementalInformationEn(page: Page, supplementalInformationEn: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('supplementalInformationEn').locator(INPUT), supplementalInformationEn, shouldBeEqual);
}

async function verifyFreeAttributeDe(page: Page, freeAttributeDe: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('freeAttributeDe').locator(INPUT), freeAttributeDe, shouldBeEqual);
}

async function verifyFreeAttributeEn(page: Page, freeAttributeEn: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('freeAttributeEn').locator(INPUT), freeAttributeEn, shouldBeEqual);
}

async function verifySystemAffiliations(page: Page, systemAffiliations: string[], shouldBeEqual: boolean) {
    const systemAffiliationTestIdMap: Record<string, string> = {
        'ENG.CTRL.': 'MR',
        'PAS': 'PAS',
        'CPCM': 'CPCM'
    };
    for (const sa of systemAffiliations) {
        const testId = systemAffiliationTestIdMap[sa];
        if (shouldBeEqual) {
            await expect(page.getByTestId(`system-affiliation-chip-${testId}`)).toBeVisible();
        } else {
            await expect(page.getByTestId(`system-affiliation-chip-${testId}`)).not.toBeVisible();
        }
    }
}

async function verifyKguens(page: Page, kguens: string[], shouldBeEqual: boolean) {
    for (const kguen of kguens) {
        if (shouldBeEqual) {
            await expect(page.getByTestId(`kguen-chip-${kguen}`)).toBeVisible();
        } else {
            await expect(page.getByTestId(`kguen-chip-${kguen}`)).not.toBeVisible();
        }
    }
}

async function verifyRuleType(page: Page, ruleType: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('ruleType').locator(INPUT), ruleType, shouldBeEqual);
}

async function verifyDerivedFeatureCluster(page: Page, derivedFeatureCluster: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureCluster').locator(INPUT), derivedFeatureCluster, shouldBeEqual);
}

async function verifyDerivedFeatureDelimiter(page: Page, derivedFeatureDelimiter: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureDelimiter').locator(INPUT), derivedFeatureDelimiter, shouldBeEqual);
}

async function verifyDerivedFeatureValuePosition(page: Page, derivedFeatureValuePosition: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeaturePosition').locator(INPUT), derivedFeatureValuePosition, shouldBeEqual);
}

async function verifyDerivedFeatureCondition(page: Page, derivedFeatureCondition: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureCondition').locator(INPUT), derivedFeatureCondition, shouldBeEqual);
}

async function verifyDerivedFeatureConditionValue(page: Page, derivedFeatureConditionValue: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureConditionValue').locator(INPUT), derivedFeatureConditionValue, shouldBeEqual);
}

async function verifyDerivedFeatureValueExplanation(page: Page, derivedFeatureValueExplanation: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureValueExplanation').locator(INPUT), derivedFeatureValueExplanation, shouldBeEqual);
}

async function verifyDerivedFeatureValueInputOneSamId(page: Page, derivedFeatureValueInputOneSamId: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureValueInputOneSamId').locator(INPUT), derivedFeatureValueInputOneSamId, shouldBeEqual);
}

async function verifyDerivedFeatureValueInputTwoSamId(page: Page, derivedFeatureValueInputTwoSamId: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureValueInputTwoSamId').locator(INPUT), derivedFeatureValueInputTwoSamId, shouldBeEqual);
}

async function verifyDerivedFeatureValueOutputValue(page: Page, derivedFeatureValueOutputValue: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureValueOutputValue').locator(INPUT), derivedFeatureValueOutputValue, shouldBeEqual);
}

async function verifyFeatureDataTypeRegularExpression(page: Page, featureDataTypeRegularExpression: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('featureDataTypeRegularExpression').locator(INPUT), featureDataTypeRegularExpression, shouldBeEqual);
}

async function verifyUnit(page: Page, unit: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('unit').locator(INPUT), unit, shouldBeEqual);
}

async function verifyDerivedFeatureValueApplicationLayer(page: Page, derivedFeatureValueApplicationLayer: string, shouldBeEqual: boolean) {
    await verifyFieldValue(page.getByTestId('derivedFeatureApplicationLayer').locator(INPUT), derivedFeatureValueApplicationLayer, shouldBeEqual);
}

async function verifyFieldValue(locator: Locator, value: string, shouldBeEqual: boolean) {
    if (shouldBeEqual) {
        await expect(locator).toHaveValue(value);
    } else {
        await expect(locator).not.toHaveValue(value);
    }
}