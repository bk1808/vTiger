export class Messages {
    public static readonly INVALID_REGEX_ERROR = 'Invalid regex pattern';
    public static readonly FIELD_IS_REQUIRED_ERROR = 'Field is required';
    public static readonly FORMAT_TYPE_VALUE_AMOUNT_ERROR = 'Only one number or two numbers seperate by a comma are allowed';
    public static readonly SUMMARY_IS_EMPTY_ERROR = 'Summary must not be empty or blank';
    public static readonly TARGET_DATE_MUST_FUTURE_ERROR = 'Target Date must be in the future!';
    public static readonly TARGET_DATE_REQUIRED = 'Target Date is required';
    public static readonly EXPLANATION_IS_EMPTY_ERROR = 'Explanation must not be empty or blank';
    public static readonly MAX_LENGTH_OF_SUMMARY_ERROR = 'Length of summary value must be at most 300';
    public static readonly MAX_LENGTH_OF_30_ERROR = 'Length of field must be at most 30';
    public static readonly MAX_LENGTH_OF_100_ERROR = 'Length of field must be at most 100';
    public static readonly MAX_LENGTH_OF_300_ERROR = 'Length of field must be at most 300';
    public static readonly MAX_LENGTH_OF_1000_ERROR = 'Length of field must be at most 1000';
}
