import {expect, test} from "@playwright/test";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {fillSamFactoryFields} from "./utils/samCreationTestHelper";
import {
    SAM_FACTORY_SYSTEM_NAME_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_CERTUS_MARKET_IDS,
    SAM_FACTORY_CERTUS_TOPIC_IDS,
    SAM_FACTORY_CERTUS_TYPE_IDS,
    SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS,
    SAM_FACTORY_CERTUS_FUNCTION_IDS
} from "../utils/constants";
import {Messages} from "./utils/messages";
import {
    verifyIsVisibleAndHasRedColorByText,
    verifyThatFreeTextFieldIsVisibleAndDisabled
} from "../utils/commonValidations";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Create and Edit SAM - Certus', () => {
    test('GIVEN Create SAM - THEN Verify Certus is not visible per default', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Check if fields are visible per default
        await expect(page.getByTestId('certusCertificateTypes')).toBeVisible({visible: false});
        await expect(page.getByTestId('certusCertificateTopic')).toBeVisible({visible: false});
        await expect(page.getByTestId('certusMarket')).toBeVisible({visible: false});
        await expect(page.getByTestId('certusAdditionalSpecification')).toBeVisible({visible: false});

        // Submit Data
        await page.getByTestId('submit-button').click();
    });

    test('GIVEN - Create SAM - THEN Verify Certus fields are only visible and mandatory when SamType-Direct and MasterDataSystem-CERTUS is selected', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS
        });

        // Check if fields are visible per default
        await expect(page.getByTestId('certusCertificateTypes')).toBeVisible();
        await expect(page.getByTestId('certusCertificateTopic')).toBeVisible();
        await expect(page.getByTestId('certusMarket')).toBeVisible();
        await expect(page.getByTestId('certusAdditionalSpecification')).toBeVisible();

        // Submit Data
        await page.getByTestId('submit-button').click();

        // Verify mandatory certus fields are required
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 2);
    });

    test('GIVEN Create SAM with Certus Values- Then Certus Values are displayed correctly', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
            certusMarket: SAM_FACTORY_CERTUS_MARKET_IDS.EU,
            certusCertificateTopic: SAM_FACTORY_CERTUS_TOPIC_IDS.LIGHTING,
            certusCertificateType: SAM_FACTORY_CERTUS_TYPE_IDS.TYPE_APPROVAL,
            certusAdditionalSpecification: SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS.CERTIFICATES,
            certusFunction:SAM_FACTORY_CERTUS_FUNCTION_IDS.CERTIFICATES
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await expect(page).toHaveURL(/.*sam-detail/);

        // Check if certus values are correctly displayed
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusMarket');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusCertificateTopic');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusAdditionalSpecification');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusFunction');

        await verifySamFactoryFields(page, {
            certusMarket: 'EU',
            certusCertificateTopic: 'LIGHTING',
            certusAdditionalSpecification: 'Certificates',
            certusFunction:'Stop lamp'
        })

        // Since there is a special use-case at certificate-types where we display them as chips, we verify that they are displayed correctly
        await expect(page.getByTestId('certusCertificateTypeId-chip-1')).toBeVisible();

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            certusMarket: 'EU',
            certusCertificateTopic: 'LIGHTING',
            certusAdditionalSpecification: 'Certificates',
            certusFunction:'Stop lamp'
        })
        await expect(page.getByTestId('certusCertificateTypeId-chip-1')).toBeVisible();
    });

    test('GIVEN Create SAM with Certus CHN and EDIT SAM to Certus EU - THEN Certus Vallues special cases are displayed correctly', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
            certusMarket:SAM_FACTORY_CERTUS_MARKET_IDS.CHN,
            certusCertificateTopic: SAM_FACTORY_CERTUS_TOPIC_IDS.FUEL_TANK,
            certusCertificateType: SAM_FACTORY_CERTUS_TYPE_IDS.CHN_MARK_CERTIFICATE,
            certusAdditionalSpecification: SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS.CERTIFICATES
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await expect(page).toHaveURL(/.*sam-detail/);

        // Check if certus values are correctly displayed
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusMarket');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusCertificateTopic');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusAdditionalSpecification');

        await verifySamFactoryFields(page, {
            certusMarket: 'CHN',
            certusCertificateTopic: 'FUEL TANK',
            certusAdditionalSpecification: 'Certificates'
        })

        // Since there is a special use-case at certificate-types where we display them as chips, we verify that they are displayed correctly
        // Expect Voluntary and CHN Market
        await expect(page.getByTestId('certusCertificateTypeId-chip-3')).toBeVisible();
        await expect(page.getByTestId('certusCertificateTypeId-chip-7')).toBeVisible();

        // Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        // Verify that Voluntary is displayed
        await expect(page.getByTestId('certusCertificateTypeId-3')).toBeVisible();

        // Fill everything needed
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
            certusMarket: SAM_FACTORY_CERTUS_MARKET_IDS.EU,
            certusCertificateTopic: SAM_FACTORY_CERTUS_TOPIC_IDS.LIGHTING,
            certusCertificateType: SAM_FACTORY_CERTUS_TYPE_IDS.TYPE_APPROVAL,
            certusAdditionalSpecification: SAM_FACTORY_CERTUS_ADDITIONAL_SPECIFICATION_IDS.CERTIFICATES,
            certusFunction:SAM_FACTORY_CERTUS_FUNCTION_IDS.CERTIFICATES
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after edit sam
        await expect(page).toHaveURL(/.*sam-detail/);

        // Check if certus values are correctly displayed
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusMarket');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusCertificateTopic');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusAdditionalSpecification');
        await verifyThatFreeTextFieldIsVisibleAndDisabled(page, 'certusFunction');

        await verifySamFactoryFields(page, {
            certusMarket: 'EU',
            certusCertificateTopic: 'LIGHTING',
            certusAdditionalSpecification: 'Certificates',
            certusFunction:'Stop lamp'
        })
        // Since there is a special use-case at certificate-types where we display them as chips, we verify that they are displayed correctly
        // Expect Type-approval
        await expect(page.getByTestId('certusCertificateTypeId-chip-1')).toBeVisible();
        await expect(page.getByTestId('certusCertificateTypeId-chip-3')).toBeVisible({visible: false});
        await expect(page.getByTestId('certusCertificateTypeId-chip-7')).toBeVisible({visible: false});

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            certusMarket: 'EU',
            certusCertificateTopic: 'LIGHTING',
            certusAdditionalSpecification: 'Certificates',
            certusFunction:'Stop lamp'
        })
        // Since there is a special use-case at certificate-types where we display them as chips, we verify that they are displayed correctly
        // Expect Type-approval
        await expect(page.getByTestId('certusCertificateTypeId-chip-1')).toBeVisible();
        await expect(page.getByTestId('certusCertificateTypeId-chip-3')).toBeVisible({visible: false});
        await expect(page.getByTestId('certusCertificateTypeId-chip-7')).toBeVisible({visible: false});
    });
})