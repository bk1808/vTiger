import {expect, test} from "@playwright/test";
import {
    RED,
    BLACK,
    TEXT_WITH_600_CHARACTERS
} from "../utils/constants";
import {Messages} from "./utils/messages";
import {getSameDateInNextYear, goFromDetailViewToHistoryView, navigateToBaseUrl} from "../utils/testHelper";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {fillSamFactoryFields, navigateToCreateSam} from "@root/tests/create-sam/utils/samCreationTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCreateSam(page);
});

test.describe('Create SAM Change Block', () => {
    test('GIVEN a SAM is created with empty target date, summary length, explanation length - THEN a required validation message is displayed', async ({page}) => {
        await verifySamFactoryFields(page, {
            summary: '',
            explanation: '',
            targetDate: null
        })

        await page.getByTestId('submit-button').click();
        await verifyIsVisibleAndHasRedColorByText(page, Messages.TARGET_DATE_REQUIRED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.SUMMARY_IS_EMPTY_ERROR);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.EXPLANATION_IS_EMPTY_ERROR);
    });

    test('GIVEN a SAM is created with invalid target date, summary length, explanation length - THEN a validation message is displayed AND valid data creates SAM successfully', async ({page}) => {
        // Use the calendar input field of the "Target Date" and select a date in the past or present. Press "Submit"
        const currentDate = new Date();
        const inputDateInPast = new Date(currentDate.getFullYear() - 1, currentDate.getMonth(), currentDate.getDay());

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            targetDate: inputDateInPast
        })

        await page.getByTestId('submit-button').click();
        // You stay on the current "SAM Create view". At Target Date a aRedColor hint is given that the date must be in the future.
        await expect(page).toHaveURL(/.*sam-create/);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.TARGET_DATE_MUST_FUTURE_ERROR);

        // Fill in the following fields: [Summary],[Target Date[Date in future]] [Explanation] and press "Submit"
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            summary: 'sum',
            targetDate: getSameDateInNextYear(),
            explanation: 'exp'
        })

        await page.getByTestId('submit-button').click();
        // You stay on the current "SAM Create view".
        // All mandatory Fields are highlighted with a red text except for [Summary], [Target Date] and [Explanation]
        await expect(page).toHaveURL(/.*sam-create/);

        await expect(page.getByTestId('summary')).toBeEditable();
        await expect(page.getByTestId('summary').locator('label'))
            .toHaveCSS('color', BLACK);
        await expect(page.getByText(Messages.SUMMARY_IS_EMPTY_ERROR)).not.toBeVisible();

        await expect(page.getByTestId('create-sam-date-picker')).toBeEditable();
        await expect(page.getByTestId('create-sam-date-picker').locator('..').locator('..').locator('label')).toHaveCSS('color', BLACK);
        await expect(page.getByText(Messages.TARGET_DATE_MUST_FUTURE_ERROR)).not.toBeVisible();

        await expect(page.getByTestId('explanation')).toBeEditable();
        await expect(page.locator('label').filter({hasText: 'Target Date'})).toHaveCSS('color', BLACK);
        await expect(page.getByText(Messages.EXPLANATION_IS_EMPTY_ERROR)).not.toBeVisible();

        await expect(page.getByTestId('disciplineId-de')).toBeEnabled();
        await expect(page.getByTestId('disciplineId-de').locator('label'))
            .toHaveCSS('color', RED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);

        await expect(page.getByTestId('disciplineId-en')).toBeEnabled();
        await expect(page.getByTestId('disciplineId-en').locator('label'))
            .toHaveCSS('color', RED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);

        await verifyIsEditableAndHasRedColorById(page, 'nameDe');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 2);

        await verifyIsEditableAndHasRedColorById(page, 'nameEn');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 3);

        await expect(page.getByTestId('masterDataSystemId')).toBeEnabled();
        await expect(page.getByTestId('masterDataSystemId').locator('label'))
            .toHaveCSS('color', RED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 4);

        // Fill in the Field [Explanation] with more than 600 characters (use the example text of row 11 twice)
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            explanation: TEXT_WITH_600_CHARACTERS
        })

        await expect(page.getByTestId('explanation')).toContainText(TEXT_WITH_600_CHARACTERS);

        // Fill with valid data & verify
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            explanation: 'exp',
            summary: 'sum',
            targetDate: getSameDateInNextYear()
        })
        await page.getByTestId('submit-button').click();

        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            targetDate: getSameDateInNextYear(),
            summary: 'sum',
            explanation: 'exp'
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            targetDate: getSameDateInNextYear(),
            summary: 'sum',
            explanation: 'exp'
        });
    });
});