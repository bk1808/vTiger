import {expect, test} from "@playwright/test";
import {fillSamFactoryFields, navigateToCreateSam} from "./utils/samCreationTestHelper";
import {SAM_FACTORY_CERTIFICATION_MARKET_IDS, SAM_FACTORY_SAM_TYPE_IDS, SAM_FACTORY_SYSTEM_NAME_IDS} from "../utils/constants";
import {goFromDetailViewToHistoryView, navigateToBaseUrl} from "../utils/testHelper";
import {INPUT} from "@root/tests/utils/locators";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper"; 

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const CERTIFICATION_MARKET_INDIA_EN = 'India';
const CERTIFICATION_MARKET_INDIA_DE = 'Indien';

test.describe('Create SAM Certification Market', () => {
    test('GIVEN a different combination of SamType and DataSource are selected - THEN the certification market visibility varies with combinations', async ({page}) => {
        await navigateToCreateSam(page);

        const certificationMarketDeTab = page.getByTestId('certificationMarketDe');
        const certificationMarketEnTab = page.getByTestId('certificationMarketEn');
        // Initially certification market is not visisble
        expect(certificationMarketDeTab).not.toBeVisible();
        expect(certificationMarketEnTab).not.toBeVisible();

        // Select DIRECT Sam type and CERTUS DataSource - 
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CERTUS,
        });
        await expect(certificationMarketDeTab).not.toBeVisible();
        await expect(certificationMarketEnTab).not.toBeVisible();
        
        // Select DERIVED Sam type-
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DERIVED,
        });
        await expect(certificationMarketDeTab).not.toBeVisible();
        await expect(certificationMarketEnTab).not.toBeVisible();

        // Select DIRECT Sam type and NON CERTUS DataSource - 
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
        });
        await expect(certificationMarketDeTab).toBeVisible();
        await expect(certificationMarketEnTab).toBeVisible();

    });

    test('GIVEN a certification market is selected in German - THEN the corresponding English certification market is automatically filled and SAM is created successfully', async ({page}) => {
        await navigateToCreateSam(page);

        const certificationMarketDeTab = page.getByTestId('certificationMarketDe');
        const certificationMarketEnTab = page.getByTestId('certificationMarketEn');
        // Initially certification amrket is not visisble
        expect(certificationMarketDeTab).not.toBeVisible();

        // Select DIRECT Sam type and NON CERTUS DataSource - certification market visisble
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
        });
        await expect(certificationMarketDeTab).toBeVisible();
        await certificationMarketDeTab.click();
        await certificationMarketDeTab.locator(INPUT).type('YY');
        await expect(page.getByText('No options')).toBeVisible();
        await certificationMarketEnTab.click();

        // Selection of typing is verified
        await certificationMarketDeTab.click();
        await certificationMarketDeTab.locator(INPUT).type('IN');
        await page.getByTestId(SAM_FACTORY_CERTIFICATION_MARKET_IDS.CHINA_DE).isVisible();
        await page.getByTestId(SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_DE).isVisible();
        await page.getByTestId(SAM_FACTORY_CERTIFICATION_MARKET_IDS.AUSTRALIA_DE).isHidden();

        await certificationMarketEnTab.click();

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
            certificationMarketDe:SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_DE
        });

        await verifySamFactoryFields(page, {
            certificationMarketDe: CERTIFICATION_MARKET_INDIA_DE,
            certificationMarketEn: CERTIFICATION_MARKET_INDIA_EN,
        })

        // The cross "Clear" to initialize the 3 discipline fields
        await certificationMarketDeTab.click();
        await certificationMarketDeTab.getByTestId('CloseIcon').click();
        
        await expect(certificationMarketDeTab.locator(INPUT)).toBeEmpty();
        await expect(certificationMarketEnTab.locator(INPUT)).toBeEmpty();
        await certificationMarketDeTab.click(); // to close the dropdown


        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            certificationMarketDe: SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_DE,
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            certificationMarketDe: CERTIFICATION_MARKET_INDIA_DE,
            certificationMarketEn: CERTIFICATION_MARKET_INDIA_EN,
        });

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            certificationMarketDe: CERTIFICATION_MARKET_INDIA_DE,
            certificationMarketEn: CERTIFICATION_MARKET_INDIA_EN,
        });
    });

    test('GIVEN a certification market is selected in English - THEN the corresponding German discipline is automatically filled', async ({page}) => {
        await navigateToCreateSam(page);

        const certificationMarketEnTab = page.getByTestId('certificationMarketEn');
        // Initially certification amrket is not visisble
        expect(certificationMarketEnTab).not.toBeVisible();

        // Select DIRECT Sam type and NON CERTUS DataSource - certification market visisble
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SAM_TYPE_IDS.DIRECT,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC,
        });
        await expect(certificationMarketEnTab).toBeVisible();
        await certificationMarketEnTab.click();
        await page.getByTestId(SAM_FACTORY_CERTIFICATION_MARKET_IDS.INDIA_EN).click();
        // 1. The corresponding German discipline is automatically filled in "Discipline (German)
        await verifySamFactoryFields(page, {
            certificationMarketDe: CERTIFICATION_MARKET_INDIA_DE,
            certificationMarketEn: CERTIFICATION_MARKET_INDIA_EN,
        })
    });
});