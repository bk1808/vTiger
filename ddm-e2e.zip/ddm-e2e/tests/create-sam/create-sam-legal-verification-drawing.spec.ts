import {expect, test} from "@playwright/test";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS, SAM_FACTORY_SYSTEM_NAME_IDS} from "../utils/constants";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {Messages} from "./utils/messages";
import {fillSamFactoryFields} from "./utils/samCreationTestHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const LEGAL_VERIFICATION_DRAWING_LEG_VERIF = 'LEG.VERIF | LEGAL VERIFICATION';
test.describe('Create SAM Legal Verification Drawing', () => {
    test('GIVEN required fields are filled - THEN legal verification drawing field is only visible if KGU-EN 000-99 is set and SAM is created successfully', async ({page}) => {
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        const samName: string = 'SAM:GESETZESNACHWEIS';

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            nameDe: samName,
            nameEn: samName,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD,
            kguens: ['000-00']
        })

        await expect(page.getByTestId('legal-verification-drawing')).not.toBeVisible();

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            kguens: ['000-99']
        })

        // Check for Mandatory message
        await verifyIsEditableAndHasRedColorById(page, 'legal-verification-drawing');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            legalVerificationDrawing: SAM_FACTORY_LEGAL_VERIFICATION_DRAWING_IDS.GE_NACHWEIS
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            legalVerificationDrawing: LEGAL_VERIFICATION_DRAWING_LEG_VERIF
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            legalVerificationDrawing: LEGAL_VERIFICATION_DRAWING_LEG_VERIF
        })
    });
});