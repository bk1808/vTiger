import {expect, test} from "@playwright/test";
import {
    SAM_FACTORY_DATA_TYPE_IDS
} from "../utils/constants";
import {
    verifyLabelHasRedColorById,
    verifyIsVisibleAndHasBlueColorByText
} from "../utils/commonValidations";
import {Messages} from "./utils/messages";
import {fillSamFactoryFields, navigateToCreateSam} from "./utils/samCreationTestHelper";
import {
    goFromDetailViewToHistoryView,
    navigateToBaseUrl,
    submitAndVerifyAppearanceOfValidationMessage
} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

const VALIDATION_ERROR_CAPITAL_LETTER_AND_COLON = 'value must start with a capital letter and contain a ":"';

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCreateSam(page);
});

const NAME_DE_TEST_ID = 'nameDe';
const NAME_EN_TEST_ID = 'nameEn';

const DATA_TYPE_DOCUMENT_ID = '11';
test.describe('Create SAM Name and Type', () => {
    test('GIVEN all mandatory fields are filled except name - THEN validation messages are displayed for missing names and SAM is created successfully with valid data', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: '',
            nameEn: ''
        })
        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, Messages.FIELD_IS_REQUIRED_ERROR);
        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, Messages.FIELD_IS_REQUIRED_ERROR);

        const nameDe = 'Name:De';
        const nameEn = 'Name:En';
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: nameDe,
            nameEn: nameEn
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            nameDe: nameDe,
            nameEn: nameEn
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            nameDe: nameDe,
            nameEn: nameEn
        })
    });

    test('GIVEN nameDE does not start with an uppercase letter - THEN a validation message is displayed', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: 'zusaetzliche Abgasreinigung: Beschreibung'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, VALIDATION_ERROR_CAPITAL_LETTER_AND_COLON);
    });

    test('GIVEN nameDE does not contain a colon - THEN a validation message is displayed', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: 'Zusaetzliche Abgasreinigung; Beschreibung'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, VALIDATION_ERROR_CAPITAL_LETTER_AND_COLON);
    });

    test('GIVEN nameEN does not start with an uppercase letter - THEN a validation message is displayed', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameEn: 'additional Exhaust:Description'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, VALIDATION_ERROR_CAPITAL_LETTER_AND_COLON);
    });

    test('GIVEN nameEN does not contain a colon - THEN a validation message is displayed', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameEn: 'Additional Exhaust,Description'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, VALIDATION_ERROR_CAPITAL_LETTER_AND_COLON);
    });

    test('GIVEN name contains invalid characters - THEN validation messages are displayed', async ({page}) => {
        // @ €
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: 'Lorem:ipsum @ dolor sit amet,',
            nameEn: 'Lorem:ipsum € dolor sit amet,'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, "Character '@' is not allowed");
        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, "Character '€' is not allowed");

        // ~
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: 'Lorem:ipsum ~ dolor sit amet,',
            nameEn: 'Lorem:ipsum ~ dolor sit amet,'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, "Character '~' is not allowed");
        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, "Character '~' is not allowed");

        //|\
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: 'Lorem:ipsum \\ dolor sit amet,',
            nameEn: 'Lorem:ipsum | dolor sit amet,'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, "Character '\\' is not allowed");
        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, "Character '|' is not allowed");

        //{}
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            nameDe: 'Lorem:ipsum { dolor sit amet,',
            nameEn: 'Lorem:ipsum } dolor sit amet,'
        })

        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_DE_TEST_ID, "Character '{' is not allowed");
        await submitAndVerifyAppearanceOfValidationMessage(page, NAME_EN_TEST_ID, "Character '}' is not allowed");
    });

    test('GIVEN Data Type is not selected - THEN Data Type label appears red and SAM with valid data is created successfully ', async ({page}) => {
        // Press "Submit"
        await page.getByTestId('submit-button').click();
        // A red note appears below the input field. It indicates that it not fulfills the Regex Matching condition.
        await expect(page).toHaveURL(/.*sam-create/);

        await expect(page.getByTestId('featureDataTypeId')).toBeEnabled();
        await expect(page.getByTestId('featureDataTypeId')).toBeVisible();
        await verifyLabelHasRedColorById(page, 'featureDataTypeId');

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.DOCUMENT
        })
        await page.getByTestId('submit-button').click();

        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            featureDataType: DATA_TYPE_DOCUMENT_ID
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            featureDataType: DATA_TYPE_DOCUMENT_ID
        })
    });

    test('GIVEN a similar name exists in DE - THEN a warning message is displayed', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            nameDe: 'HD*Abgasrueckfuehrung: ?Typ...'
        })

        await verifyIsVisibleAndHasBlueColorByText(page, 'A similar SAM name exists. Please check the name and adjust it if necessary');
        await verifyIsVisibleAndHasBlueColorByText(page, 'HD Abgasrueckfuehrung: Typ');
        await verifyIsVisibleAndHasBlueColorByText(page, 'ID: ASC.0001');
    });

    test('Check for similar names EN', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            nameEn: 'HP*exhaust+gas?recirculation:&type...'
        })

        await verifyIsVisibleAndHasBlueColorByText(page, 'A similar SAM name exists. Please check the name and adjust it if necessary');
        await verifyIsVisibleAndHasBlueColorByText(page, 'HP exhaust gas recirculation: type');
        await verifyIsVisibleAndHasBlueColorByText(page, 'ID: ASC.0001');
    });
});