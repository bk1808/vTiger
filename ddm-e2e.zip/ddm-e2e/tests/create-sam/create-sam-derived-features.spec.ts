import {expect, test} from "@playwright/test";
import {
    goFromDetailViewToHistoryView,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {fillSamFactoryFields} from "./utils/samCreationTestHelper";
import {
    RULE_TYPE_IDS,
    SAM_FACTORY_APPLICATION_LAYER_IDS,
    SAM_FACTORY_CLUSTER_IDS,
    SAM_FACTORY_CONDITION_IDS,
    SAM_FACTORY_SAM_TYPE_IDS,
    SAM_FACTORY_SYSTEM_TYPE_IDS
} from "../utils/constants";
import {Messages} from "./utils/messages";
import {verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const DERIVED_ID: string = '2';
const IF_THEN_FUNCTION: string = 'If Then function';
const FEATURE_TRANSFER_FUNCTION: string = 'Feature transfer function';
const EXISTING_YN: string = 'Existing [y/n] (EXI)';
const TOTAL_LAYER: string = 'Total layer (Request)';
const LOCATION: string = 'Location (LOC)';
const BOM_PART_POSV: string = 'BOM part (POSV)';
const POS: string = 'POS';

test.describe('Create and Edit SAM - Derived Features', () => {
    const derivedFeatureValueExplanation: string = 'derived feature value explanation';
    const derivedFeatureConditionValue: string = 'Derived Feature Condition Value';

    test('GIVEN SAM Create - THEN Verify Derived Features are not visible per default', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Check if fields are visible per default
        await expect(page.getByTestId('ruleType')).toBeVisible({visible: false}); // Ruletype Input field
        await expect(page.getByTestId('derivedFeatureValueExplanation')).toBeVisible({visible: false});  //  Ruletype derivedFeatureValueExplanation input field
        await expect(page.getByTestId('derivedFeatureValueInputOneSamId')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueInputOneSamId input field
        await expect(page.getByTestId('derivedFeatureValueInputTwoSamId')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueInputTwoSamId input field
        await expect(page.getByTestId('derivedFeatureValueOutputValue')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueOutputValue input field
        await expect(page.getByTestId('derivedFeatureCluster')).toBeVisible({visible: false});  //  Ruletype derivedFeatureCluster input field
        await expect(page.getByTestId('derivedFeatureDelimiter')).toBeVisible({visible: false});  //  Ruletype derivedFeatureDelimiter input field
        await expect(page.getByTestId('derivedFeaturePosition')).toBeVisible({visible: false});  //  Ruletype derivedFeatureValuePosition input field
        await expect(page.getByTestId('derivedFeatureCondition')).toBeVisible({visible: false});  //  Ruletype derivedFeatureCondition input field
        await expect(page.getByTestId('derivedFeatureConditionValue')).toBeVisible({visible: false});  //  Ruletype derivedFeatureConditionValue input field
    });

    test('GIVEN SamType-Derived and according ruleType selected - THEN Verify Derived Features fields are visible and mandatory', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed with default cluster
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.FEATURE_TRANSFER_FUNCTION,
        });

        // Check if fields are visible per default and ruleType is mandatory
        await expect(page.getByTestId('derivedFeatureCluster')).toBeVisible({visible: true});  //  Ruletype derivedFeatureCluster input field
        await expect(page.getByTestId('ruleType')).toBeVisible(); // Ruletype Input field
        await expect(page.getByTestId('derivedFeatureValueExplanation')).toBeVisible({visible: false});  //  Ruletype derivedFeatureValueExplanation input field
        await expect(page.getByTestId('derivedFeatureValueInputOneSamId')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueInputOneSamId input field
        await expect(page.getByTestId('derivedFeatureValueInputTwoSamId')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueInputTwoSamId input field
        await expect(page.getByTestId('derivedFeatureValueOutputValue')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueOutputValue input field
        await expect(page.getByTestId('derivedFeatureDelimiter')).toBeVisible({visible: false});  //  Ruletype derivedFeatureDelimiter input field
        await expect(page.getByTestId('derivedFeaturePosition')).toBeVisible({visible: false});  //  Ruletype derivedFeatureValuePosition input field
        await expect(page.getByTestId('derivedFeatureCondition')).toBeVisible({visible: false});  //  Ruletype derivedFeatureCondition input field
        await expect(page.getByTestId('derivedFeatureConditionValue')).toBeVisible({visible: false});  //  Ruletype derivedFeatureConditionValue input field
        await expect(page.getByTestId('derivedFeatureApplicationLayer')).toBeVisible({visible: false});  //  Ruletype derivedFeatureApplicationLayer input field

        // Submit Data
        await page.getByTestId('submit-button').click();

        // Verify mandatory ruleType
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);

        // Check for visible fields based on ruleType
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.QUANTITY_FUNCTION,
            ruleType: RULE_TYPE_IDS.UNION,
            derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.BOM_PART_POSV,
        });
        await expect(page.getByTestId('derivedFeatureValueExplanation')).toBeVisible();  //  Ruletype derivedFeatureValueExplanation input field
        await expect(page.getByTestId('derivedFeatureValueInputOneSamId')).toBeVisible(); // Ruletype derivedFeatureValueInputOneSamId input field
        await expect(page.getByTestId('derivedFeatureValueInputTwoSamId')).toBeVisible(); // Ruletype derivedFeatureValueInputTwoSamId input field
        await expect(page.getByTestId('derivedFeatureValueOutputValue')).toBeVisible(); // Ruletype derivedFeatureValueOutputValue input field

        // Submit Data
        await page.getByTestId('submit-button').click();

        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 2);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 3);

        // Check for visible fields based on ruleType
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SYSTEM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.IF_THEN_FUNCTION,
            ruleType: RULE_TYPE_IDS.EXISTING,
            derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.TOTAL_LAYER,
        });
        await expect(page.getByTestId('derivedFeatureValueExplanation')).toBeVisible();  //  Ruletype derivedFeatureValueExplanation input field
        await expect(page.getByTestId('derivedFeatureValueInputOneSamId')).toBeVisible(); // Ruletype derivedFeatureValueInputOneSamId input field
        await expect(page.getByTestId('derivedFeatureValueInputTwoSamId')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueInputTwoSamId input field
        await expect(page.getByTestId('derivedFeatureValueOutputValue')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueOutputValue input field

        // Submit Data
        await page.getByTestId('submit-button').click();

        // Check for visibility of mandatory fields
        await expect(page.getByTestId('derivedFeatureValueExplanation')).toBeVisible();  //  Ruletype derivedFeatureValueExplanation input field
        await expect(page.getByTestId('derivedFeatureValueInputOneSamId')).toBeVisible(); // Ruletype derivedFeatureValueInputOneSamId input field
        await expect(page.getByTestId('derivedFeatureValueInputTwoSamId')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueInputTwoSamId input field
        await expect(page.getByTestId('derivedFeatureValueOutputValue')).toBeVisible({visible: false}); // Ruletype derivedFeatureValueOutputValue input field

        // Verify mandatory fields
        verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);
        verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);
    });

    test('GIVEN SAM Create - THEN Create SAM with RuleType:Existing [y/n] (EXI) and Edit to RuleType:Location successfully', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        await page.getByTestId('submit-button').click();

        // Fill everything needed
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SYSTEM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.IF_THEN_FUNCTION,
            ruleType: RULE_TYPE_IDS.EXISTING,
            derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.TOTAL_LAYER,
            derivedFeatureValueInputOneSamId: "derivedFeatureValueInputOneSamId-c97c9121-1380-4a85-b12e-73367509e070",
            derivedFeatureValueExplanation: derivedFeatureValueExplanation,
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await expect(page).toHaveURL(/.*sam-detail/);

        // Verify given Input Fields
        await verifySamFactoryFields(page, {
            samType: DERIVED_ID,
            derivedFeatureCluster: IF_THEN_FUNCTION,
            ruleType: EXISTING_YN,
            derivedFeatureValueApplicationLayer: TOTAL_LAYER,
            derivedFeatureValueInputOneSamId: 'ASC.0001',
            derivedFeatureValueExplanation: derivedFeatureValueExplanation,
        })

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        // Fill everything needed
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SAM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.FEATURE_TRANSFER_FUNCTION,
            ruleType: RULE_TYPE_IDS.LOCATION,
            derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.BOM_PART_POSV,
            derivedFeatureCondition: SAM_FACTORY_CONDITION_IDS.POS,
            derivedFeatureConditionValue: derivedFeatureConditionValue,
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await page.waitForURL(/.*sam-detail/);
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            samType: DERIVED_ID,
            derivedFeatureCluster: FEATURE_TRANSFER_FUNCTION,
            ruleType: LOCATION,
            derivedFeatureValueApplicationLayer: BOM_PART_POSV,
            derivedFeatureCondition: POS,
            derivedFeatureConditionValue: derivedFeatureConditionValue,
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            samType: DERIVED_ID,
            derivedFeatureCluster: FEATURE_TRANSFER_FUNCTION,
            ruleType: LOCATION,
            derivedFeatureValueApplicationLayer: BOM_PART_POSV,
            derivedFeatureCondition: POS,
            derivedFeatureConditionValue: derivedFeatureConditionValue,
        })
    });

    test('GIVEN SAM Create - THEN Create SAM with RuleType:Location and Edit to RuleType:Existing [y/n] (EXI) successfully', async ({page}) => {
        // Go to SamCreate view
        await goToSamDashBoard(page);
        await goToSamCreateForm(page);

        // Fill everything needed
        await fillSamFactoryFields(page, {
            samType: SAM_FACTORY_SYSTEM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.FEATURE_TRANSFER_FUNCTION,
            ruleType: RULE_TYPE_IDS.LOCATION,
            derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.BOM_PART_POSV,
            derivedFeatureValueInputOneSamId: "derivedFeatureValueInputOneSamId-c97c9121-1380-4a85-b12e-73367509e070",
            derivedFeatureCondition: SAM_FACTORY_CONDITION_IDS.POS,
            derivedFeatureConditionValue: derivedFeatureConditionValue,
            derivedFeatureValueExplanation: derivedFeatureValueExplanation
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await page.waitForURL(/.*sam-detail/);
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            samType: DERIVED_ID,
            ruleType: LOCATION,
            derivedFeatureValueInputOneSamId: 'ASC.0001',
            derivedFeatureValueApplicationLayer: BOM_PART_POSV,
            derivedFeatureCondition: POS,
            derivedFeatureConditionValue: derivedFeatureConditionValue,
            derivedFeatureValueExplanation: derivedFeatureValueExplanation
        })

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        // Fill everything needed
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            samType: SAM_FACTORY_SYSTEM_TYPE_IDS.DERIVED,
            derivedFeatureCluster: SAM_FACTORY_CLUSTER_IDS.IF_THEN_FUNCTION,
            ruleType: RULE_TYPE_IDS.EXISTING,
            derivedFeatureValueApplicationLayer: SAM_FACTORY_APPLICATION_LAYER_IDS.TOTAL_LAYER,
        });

        // Submit Data
        await page.getByTestId('submit-button').click();
        // Expect Sam Detail View after create sam
        await expect(page).toHaveURL(/.*sam-detail/);

        // Verify given Input Fields
        await verifySamFactoryFields(page, {
            samType: DERIVED_ID,
            ruleType: EXISTING_YN,
            derivedFeatureValueInputOneSamId: 'ASC.0001',
            derivedFeatureValueApplicationLayer: TOTAL_LAYER,
        })
    });
});