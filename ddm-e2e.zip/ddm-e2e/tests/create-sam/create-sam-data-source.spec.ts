import {expect, test} from "@playwright/test";
import {BLACK, SAM_FACTORY_SYSTEM_NAME_IDS} from "../utils/constants";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";
import {Messages} from "./utils/messages";
import {fillSamFactoryFields, navigateToCreateSam} from "./utils/samCreationTestHelper";
import {goFromDetailViewToHistoryView, navigateToBaseUrl} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";
import {INPUT} from "@root/tests/utils/locators";


test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

const DATA_SOURCE_UNDEFINED_ID: string = '0';

test.describe('Create SAM with Data Source', () => {
    test('GIVEN no data source is selected - THEN a validation message for mandatory field is displayed', async ({page}) => {
        await navigateToCreateSam(page);

        //Select no data from the selection list and press "Submit"
        await page.getByTestId('submit-button').click();
        //You stay on the current "SAM Create view" SAM is not saved
        await expect(page).toHaveURL(/.*sam-create/);
        //Data Source field is highlighted with red text "Field is requiered".
        await verifyIsEditableAndHasRedColorById(page, 'masterDataSystemId');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR);
        //Datafield is still writeable / selectable.
        await expect(page.getByTestId('masterDataSystemId')).toBeEditable();

    });

    test('GIVEN undefined data source is selected - THEN KGU-ENs field is not visible and SAM is successfully created', async ({page}) => {
        await navigateToCreateSam(page);

        //Select [undefined]
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.UNDEFINED
        })

        await expect(page.getByTestId('kguens')).not.toBeVisible();

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);
        await verifySamFactoryFields(page, {
            masterDataSystem: DATA_SOURCE_UNDEFINED_ID
        })

        await goFromDetailViewToHistoryView(page);
        await verifySamFactoryFields(page, {
            masterDataSystem: DATA_SOURCE_UNDEFINED_ID
        });
    });

    test('GIVEN Data Source CBC is selected - THEN KGU-ENs field should not be visible', async ({page}) => {
        await navigateToCreateSam(page);

        // Select [CBC]
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.CBC
        })

        await expect(page.getByTestId('kguens')).not.toBeVisible();
        //and press "Submit"
        await page.getByTestId('submit-button').click();
        //You stay on the current "SAM Create view" SAM is not saved
        await expect(page).toHaveURL(/.*sam-create/);

        await expect(page.getByTestId('masterDataSystemId').locator('label')).toHaveCSS('color', BLACK);
    });

    test('GIVEN Data Source is selected Smaragd with unmatched KGU-EN - THEN no options are visible', async ({page}) => {
        await navigateToCreateSam(page);

        //Select
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            masterDataSystem: SAM_FACTORY_SYSTEM_NAME_IDS.SMARAGD,
            kguens: ['860-00', '340-11']
        })

        await page.getByTestId('kguens').locator(INPUT).clear();
        //no options must be visible if a KGU-EN not matched
        await page.getByTestId('kguens').locator(INPUT).fill('123');
        await expect(page.getByTestId('kguens-no-options')).toBeVisible();
    });
});