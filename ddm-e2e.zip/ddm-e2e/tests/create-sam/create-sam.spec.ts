import {expect, test} from "@playwright/test";
import {RED} from "../utils/constants";
import {Messages} from "./utils/messages";
import {
    goToSamCreateAndFillAllMandatoryFieldsAndSave,
    goToSamCreateForm,
    goToSamDashBoard,
    navigateToBaseUrl
} from "../utils/testHelper";
import {verifyIsEditableAndHasRedColorById, verifyIsVisibleAndHasRedColorByText} from "../utils/commonValidations";

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
});

test.describe('Create SAM', () => {
    test('Create SAM View', async ({page}) => {
        await goToSamDashBoard(page);

        await goToSamCreateForm(page);
    });

    test('GIVEN submitted CreateSAM with empty mandatory fields -THEN all mandatory fields labels appear in red color and red error helper text is displayed', async ({page}) => {
        await goToSamDashBoard(page);

        await goToSamCreateForm(page);

        // Type no Meta Data in all fields and press "Submit"
        await page.getByTestId('submit-button').click();
        // All mandatory fields are highlighted with aRedColor text and validation helper text is visible.
        // SAM is not saved and all data fields are still writeable
        await expect(page).toHaveURL(/.*sam-create/);

        await verifyIsEditableAndHasRedColorById(page, 'summary');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.SUMMARY_IS_EMPTY_ERROR);

        await expect(page.getByTestId('create-sam-date-picker')).toBeEditable();
        await verifyIsVisibleAndHasRedColorByText(page, Messages.TARGET_DATE_REQUIRED);

        await expect(page.getByTestId('explanation')).toBeEditable()
        await verifyIsVisibleAndHasRedColorByText(page, Messages.EXPLANATION_IS_EMPTY_ERROR);

        await expect(page.getByTestId('disciplineId-de')).toBeEnabled();
        await expect(page.getByTestId('disciplineId-de').locator('label'))
            .toHaveCSS('color', RED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);

        await expect(page.getByTestId('disciplineId-en')).toBeEnabled();
        await expect(page.getByTestId('disciplineId-en').locator('label'))
            .toHaveCSS('color', RED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 1);

        await verifyIsEditableAndHasRedColorById(page, 'nameDe');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 2);

        await verifyIsEditableAndHasRedColorById(page, 'nameEn');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 3);

        await verifyIsEditableAndHasRedColorById(page, 'featureDataTypeId');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 4);

        await expect(page.getByTestId('masterDataSystemId')).toBeEnabled();
        await expect(page.getByTestId('masterDataSystemId').locator('label'))
            .toHaveCSS('color', RED);
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 5);
    });

    test('GIVEN submitted CreateSAM with filled mandatory fields -THEN SAM can be saved and is visible on sam dashboard', async ({page}) => {
        const samName: string = 'SAM:MANDATORY_FIELDS';
        await goToSamCreateAndFillAllMandatoryFieldsAndSave(page, samName);

        // Select "SAM" from the left menu bar
        await page.getByTestId('sidebar-sam-button').click();
        // Redirecting to the SAM overview page. SAM is saved and appears in the table
        await expect(page).toHaveURL(/.*sam-dashboard/);

        await page.getByTestId('sidebar-sam-button').click();
        await page.getByTestId('sam-view-filter').click();

        await page.getByTestId('filter-name-en').click();
        await page.getByTestId('SAM Name (EN)-input').locator('input').fill(samName);
        await page.getByTestId('SAM Name (EN)-input').locator('input').press('Enter');

        await expect(page.getByText(samName).first()).toBeVisible();
    });
});