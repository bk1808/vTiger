import {expect, test} from "@playwright/test";
import {
    SAM_FACTORY_DATA_TYPE_IDS
} from "../utils/constants";
import {
    verifyLabelHasRedColorById,
    verifyIsVisibleAndHasRedColorByText,
} from "../utils/commonValidations";
import {Messages} from "./utils/messages";
import {fillSamFactoryFields, navigateToCreateSam} from "./utils/samCreationTestHelper";
import { navigateToBaseUrl} from "../utils/testHelper";
import {verifySamFactoryFields} from "@root/tests/create-sam/utils/samDetailTestHelper";

export function getUnitTestId(valueInput: string) {
    return `unit-${valueInput}`;
}

test.beforeEach(async ({page}) => {
    await navigateToBaseUrl(page);
    await navigateToCreateSam(page);
});


test.describe('Create SAM - Data Type with Unit', () => {
    test('GIVEN Data Type Number is selected - THEN Unit is visible and mandatory', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
            featureDataTypeRegularExpression: 'featureDataTypeRegularExpression-1,23457E+12'
        })

        await expect(page.getByTestId('unit')).toBeVisible();
        
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-create/);

        await verifyLabelHasRedColorById(page, 'unit');
        await verifyIsVisibleAndHasRedColorByText(page, Messages.FIELD_IS_REQUIRED_ERROR, 0);

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMBER,
            unit: getUnitTestId('A'),
            featureDataTypeRegularExpression: 'featureDataTypeRegularExpression-1,23457E+12'
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        await verifySamFactoryFields(page, {
            unit:'A',
            featureDataTypeRegularExpression: '1,23457E+12',
        })
    });

    test('GIVEN Data Type Numerical Interval is selected - THEN Unit is visible and not mandatory', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMERICAL_INTERVAL,
        })

        await expect(page.getByTestId('unit')).toBeVisible();
        
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMERICAL_INTERVAL,
            unit: getUnitTestId('A')
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        await verifySamFactoryFields(page, {
            unit:'A'
        })
    });

    test('GIVEN Data Type Numerical Value is selected - THEN Unit is visible and not mandatory', async ({page}) => {
        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: true,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMERICAL_VALUE,
        })

        await expect(page.getByTestId('unit')).toBeVisible();
        
        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        await fillSamFactoryFields(page, {
            fillMandatoryFieldsAutomatically: false,
            featureDataType: SAM_FACTORY_DATA_TYPE_IDS.NUMERICAL_VALUE,
            unit: getUnitTestId('A')
        })

        await page.getByTestId('submit-button').click();
        await expect(page).toHaveURL(/.*sam-detail/);

        // Click Edit Button
        await page.getByTestId('Sam.DetailView.Edit.Button').click();

        await verifySamFactoryFields(page, {
            unit:'A'
        })
    });
});