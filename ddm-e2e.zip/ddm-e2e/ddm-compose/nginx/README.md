# General
For further information check following confluence documentation (https://mercedes-benz.atlassian.net/wiki/spaces/DDMDEV/pages/434440739/DDM+-+NGINX+Proxy)

This nginx based service is doing 2 things
* it works on local machine as reverse proxy for the react application in order to combine the 2 backend services behind one port
* Further für local environment in can simulate the i3 access to give users entitlements - see JWT_TOKENS file

# Commands
## Build Nginx Docker Image
```
docker build --no-cache -t ddm-nginx-proxy .
```

## Run Docker Container
```
docker run -d -p 7777:7777 ddm-nginx-proxy
```


## Handling gitleaks file
Do frequently check on stored secrets. The giteleaks-repot.json is a baseline files which holds all secrets used in commits.
For documentation have a look at [gitleaks mercedes page](https://git.i.mercedes-benz.com/howto/secret-scanning-with-gitleaks)
