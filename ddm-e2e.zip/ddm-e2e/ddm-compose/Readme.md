## DDM Docker Compose

This folder contains a ready to use configuration to run complete ddm locally. However, some services are mocked.

## Use of docker compose
1. Start Docker Desktop for Windows
2. Optional: Clean Up/Delete the postgres volume
3. Open a terminal in the folder where the docker-compose.yml file is located
4. Login to Artifactory
    - `docker login https://registry-emea.app.corpintra.net -u <username> -p <password>`
3. Use the cmds below

| Command                      | Explanation                                                                                              | 
|------------------------------|----------------------------------------------------------------------------------------------------------|
| docker compose up (--detach) | starts docker compose, --detach for execution in the background                                          |
| docker compose up --build    | starts docker compose, forces a rebuild of the images, e.g., necessary when the Nginx config has been changed |
| docker compose down          | stops docker compose                                                                                     | 
| docker compose watch         | can be used for changes during runtime, please ask Google                                                |

To use the setup for local development feel free to adapt the docker compose configuration at any time you need it.

## Components

| Component       | Usage                                                         |
|-----------------|---------------------------------------------------------------|
| nginx           | Necessary as a proxy to, for example, mock authentication     |
| postgresdb      | DDM database                                                  |
| zookeeper       | Part of the local Kafka                                       |
| kafka           | Local Kafka for communication with the CA mock                |
| camock          | Mock for the Central Approval platform                        |
| sma4umock       | Mock for Sma4U </br> :warning: 2024-12-10 not implemented yet |
| ddm-service     | the DDM-Service                                               |
| ddm-service-sam | the  DDM-Service-Sam                                          |
| ddm-ui          | the DDM-UI                                                    |

## Configuration Insights

### Postgres
Postgres must be initially populated with KGUENs:

- If the persistent volume of Postgres is empty, Postgres will be fully initialized.
- If the persistent volume of Postgres exists, the existing state will be started.

To trigger re-initialization, the volume must be deleted and recreated.

:information_source: See also https://hub.docker.com/_/postgres under "Initialization scripts"

:warning: Important when making changes: The path where the KGUEN.csv file is located must be updated in the [Postgres Dockerfile](postgres/Dockerfile).

### Nginx

The Nginx is automatically built. It is based on https://mercedes-benz.atlassian.net/wiki/spaces/DDMDEV/pages/434440739/DDM+-+NGINX+Proxy

Suggestions for improvement:

- In the future, there needs to be a way to flexibly switch the user or the entitlements within the scope of the E2E tests.

### Kafka

Through Docker Desktop, you can access the shell of the Kafka container and retrieve the topic data using the Kafka client.

Example: `kafka-console-consumer --topic sam-provider --from-beginning --bootstrap-server localhost:9092`

See also: https://kafka.apache.org/quickstart

## Further information

- https://docs.docker.com/compose/gettingstarted/
- https://docs.docker.com/compose/intro/compose-application-model/