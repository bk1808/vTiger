# ddm-e2e
End-To-End Tests

# Requirements
* Node.js V 20.5.1
* npx playwright install

# Local Installation

* npm install
* adapt playwright.config.ts to 
  * Create folder playwright/.auth
    * Needed files
    * user.json
    * user-store.json
  * apapt baseUrl: 'http://localhost:3000/test'
* npx playwright test --ui
![Playwright console](./doc/playwright-ui-example.png)
* Make sure that all projects are selected

# Testing on Jenkins
* Go to https://git.i.mercedes-benz.com/ddm/ddm-kubernetes-config/blob/develop/Jenkinsfile_TestApp_DEV
* change the branch to your e2e branch
* Go To Jenkins https://ccd-jenkins.dot.i.mercedes-benz.com/job/DDM_E2E_Tests/job/DDM_DEV_Nightly/configure
* and change the configuration
* ![Jenkins Config](./doc/jenkins-config.png)