import {devices, PlaywrightTestConfig} from '@playwright/test';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();

/**
 * See https://playwright.dev/docs/test-configuration.
 */
const config: PlaywrightTestConfig = {
    testDir: './tests',
    workers: 1,
    testMatch: '**/*.{spec,test}.{js,ts}',
    timeout: 180 * 1000, // default 30000
    expect: {timeout: 30000}, // default 5000
    /* Run tests in files in parallel */
    fullyParallel: true,
    /* Fail the build on CI if you accidentally left test.only in the source code. */
    forbidOnly: !!process.env.CI,
    /* Retry on CI only */
    retries: process.env.CI ? 2 : 0,
    /* Reporter to use. See https://playwright.dev/docs/test-reporters */
    reporter: [['html', {open: 'never'}]],
    /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
    use: {
        /* Base URL to use in actions like `await page.goto('/')`. */
        baseURL: 'https://ddm-dev-test.c82p227.c82.cloud.corpintra.net/',
        // baseURL: 'http://localhost:7777',

        /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
        trace: 'on-first-retry',

        // Capture screenshot after each test failure.
        screenshot: 'only-on-failure',
    },

    /* Configure projects for major browsers */
    projects: [
        // Setup project
        {name: 'setup', testMatch: /.*\.setup\.ts/},
        {
            name: 'chromium',
            use: {
                acceptDownloads: true,
                ignoreHTTPSErrors: true,
                ...devices['Desktop Chrome'],
                // Use prepared auth state.
                storageState: 'playwright/.auth/user.json',
            },
            dependencies: ['setup']
        },
        // {
        //     name: 'firefox',
        // use: {
        // ignoreHTTPSErrors: true,
        // ...devices['Desktop Firefox'],
        // // Use prepared auth state.
        // storageState: 'playwright/.auth/user.json',
        // },
        // dependencies: ['setup'],
        // },
    ],
}

export default config;
