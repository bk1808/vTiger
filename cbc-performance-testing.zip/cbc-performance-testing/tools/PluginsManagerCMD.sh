#!/bin/sh

java -Djava.awt.headless=true $JVM_ARGS -cp "$(dirname $0)/../lib/*:$(dirname $0)/../lib/ext/*" kg.apc.cmdrunner.CmdRunner --tool org.jmeterplugins.repository.PluginManagerCMD "$@"

