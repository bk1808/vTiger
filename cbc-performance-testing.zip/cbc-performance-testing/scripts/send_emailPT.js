// Script: Send Performance Test Report
// Developed by: Adithya Munagapati

const nodemailer = require("nodemailer");
const fs = require("fs");
const path = require("path");
const parse = require("csv-parse/sync");
const { execSync } = require("child_process");

// --- SMTP & Email Config ---
const SMTP_HOST = "smtprelay.rd.corpintra.net";
const SMTP_PORT = 465;
const EMAIL_FROM = "no-reply@mercedes-benz.com";
const EMAIL_TO = [
   "santanu.ghosh@mercedes-benz.com",
   "adithya.munagapati@mercedes-benz.com",
   "geethanjali.chadivae@mercedes-benz.com",
   "sankar.gudisa@mercedes-benz.com",
   "madhusudhan.mandyala@mercedes-benz.com",
   "radhika.purwar@mercedes-benz.com",
    "rajdeep.jha@mercedes-benz.com",
    "veenashree.chandrashekarappa@mercedes-benz.com",
    "shraddha.s.p@mercedes-benz.com",
    "mouna.myluswamy@mercedes-benz.com",
    "lopamudra.mohanty@mercedes-benz.com",
   "pallawi.singh@mercedes-benz.com",
   "kyndryl.sai_latha_patamsetti@mercedes-benz.com",
   "cognizant.rabgal@mercedes-benz.com",
   "capgemini.pothineni@mercedes-benz.com"
].join(",");

// --- File Paths ---
const RESULT_FILE = "target/result.jtl";
const HTML_REPORT_ZIP = "target/html-report.zip";
const HTML_REPORT = "target/html-report";
const CONSOLE_LOG = "target/jmeter-console.log";
const THRESHOLD_MS = 3000;

/**
 * IST time formatter
 */
function toIST(timestamp) {
  const date = new Date(Number(timestamp));
  return date.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
}

/**
 * Calculate percentile
 */
function percentile(arr, p) {
  if (!arr.length) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const index = Math.ceil((p / 100) * sorted.length) - 1;
  return sorted[index];
}

/**
 * Parse JTL and return summary + grouped API stats
 */
function parseJTL(filePath) {
  try {
    const content = fs.readFileSync(filePath);
    const records = parse.parse(content, {
      columns: true,
      skip_empty_lines: true,
    });

    const total = records.length;
    const failures = records.filter(r => r.success === "false").length;
    const failureRate = ((failures / total) * 100).toFixed(2);
    const averageTime = (
      records.reduce((sum, r) => sum + parseInt(r.elapsed || 0, 10), 0) / total
    ).toFixed(2);

    const apiMap = {};

    for (const r of records) {
      const label = r.label;
      const elapsed = parseInt(r.elapsed, 10);
      const success = r.success === "true";
      const timestamp = toIST(r.timeStamp);

      if (!apiMap[label]) {
        apiMap[label] = {
          label,
          elapsedTimes: [],
          timestamps: [],
          failures: 0
        };
      }

      apiMap[label].elapsedTimes.push(elapsed);
      apiMap[label].timestamps.push(timestamp);
      if (!success) apiMap[label].failures += 1;
    }

    const allAPIStats = Object.values(apiMap).map(api => {
      const { elapsedTimes } = api;
      return {
        label: api.label,
        min: Math.min(...elapsedTimes),
        max: Math.max(...elapsedTimes),
        avg: (elapsedTimes.reduce((a, b) => a + b, 0) / elapsedTimes.length).toFixed(2),
        percentile90: percentile(elapsedTimes, 90),
        percentile95: percentile(elapsedTimes, 95),
        count: elapsedTimes.length,
        failures: api.failures,
        first_ts: api.timestamps[0]
      };
    });

    return {
      total,
      failures,
      failureRate,
      averageTime,
      allAPIStats,
      slowAPIData: allAPIStats.filter(api => api.max > THRESHOLD_MS)
    };
  } catch (error) {
    console.error("❌ Failed to parse result.jtl:", error.message);
    return null;
  }
}

/**
 * Generate HTML table
 */
function generateApiTable(apiStats, title) {
  if (!apiStats.length) {
    if (title.includes("Slow")) {
      return `
        <h3>🚨 APIs with Slow Performance (Above 3 Seconds)</h3>
        <p><i>No APIs exceeded the 3 second threshold.</i></p>`;
    }
    return `<p><i>No data available for ${title}</i></p>`;
  }

  let html = `<h3>${title}</h3>
  <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; font-size: 14px;">
    <thead>
      <tr>
        <th>API Label</th>
        <th>Min (ms)</th>
        <th>Max (ms)</th>
        <th>Avg (ms)</th>
        <th>90th % (ms)</th>
        <th>95th % (ms)</th>
        <th>Requests</th>
        <th>Failures</th>
        <th>First Timestamp (IST)</th>
      </tr>
    </thead>
    <tbody>`;

  for (const api of apiStats) {
    html += `<tr>
      <td>${api.label}</td>
      <td>${api.min}</td>
      <td>${api.max}</td>
      <td>${api.avg}</td>
      <td>${api.percentile90}</td>
      <td>${api.percentile95}</td>
      <td>${api.count}</td>
      <td>${api.failures}</td>
      <td>${api.first_ts}</td>
    </tr>`;
  }

  html += "</tbody></table>";
  return html;
}

/**
 * Zip the HTML report folder
 */
function zipHtmlReport() {
  try {
    if (fs.existsSync(HTML_REPORT)) {
      console.log("📦 Zipping HTML report folder...");
      execSync(`cd target && zip -r html-report.zip html-report`);
      console.log("✅ Zipping complete.");
    } else {
      console.log("📁 HTML report folder not found. Skipping zipping.");
    }
  } catch (err) {
    console.error("❌ Failed to zip HTML report:", err.message);
    process.exit(1);
  }
}

/**
 * Create a secure SMTP transport
 */
function createTransport() {
  return nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: false,
    tls: {
      rejectUnauthorized: false,
    },
    debug: true,
    logger: true,
  });
}

/**
 * Compose and send the email
 */
async function sendEmail(summary) {
  const transporter = createTransport();
  const subject = "📊 CBC JMeter Performance Test Summary";

  const allApiTable = generateApiTable(summary.allAPIStats, "📊 API-wise Performance Summary");
  const slowApiTable = generateApiTable(summary.slowAPIData, "🚨 APIs with Slow Performance (Above 3 Seconds)");

  let failureNote = "";
  if (parseFloat(summary.failureRate) > 1.0) {
    failureNote = `<p style="color: red; font-weight: bold;">⚠️ Failure rate is ${summary.failureRate}%, which exceeds the 1% threshold.</p>`;
  }

  let percentileWarning = "";
  const hasHighP95 = summary.allAPIStats.some(api => api.percentile95 > THRESHOLD_MS);
  if (hasHighP95) {
    percentileWarning = `<p style="color: red; font-weight: bold;">⚠️ One or more APIs have 95th percentile response time greater than 3 seconds.</p>`;
  }

  const htmlBody = `
  <p style="font-size: 15px;">Hello All,</p>

  <p style="font-size: 15px;">Please find the attached performance test report from the latest JMeter execution.</p>

  ${allApiTable}
  <br>
  ${slowApiTable}
  <br>
  ${failureNote}
  ${percentileWarning}

  <p style="font-size: 15px;">Attachments:</p>
  <ul style="font-size: 14px;">
    <li><b>html-report.zip</b> – JMeter Dashboard</li>
    <li><b>result.jtl</b> – Raw Results</li>
    <li><b>jmeter-console.log</b> – Execution Log</li>
  </ul>

  <p style="font-size: 15px;">Regards,<br><b>CBC Automation Team</b></p>
`;

  const attachments = [
    { filename: "html-report.zip", path: path.resolve(HTML_REPORT_ZIP), contentType: "application/zip" },
    { filename: "result.jtl", path: path.resolve(RESULT_FILE) },
    { filename: "jmeter-console.log", path: path.resolve(CONSOLE_LOG) },
  ];

  const mailOptions = {
    from: EMAIL_FROM,
    to: EMAIL_TO,
    subject,
    html: htmlBody,
    attachments,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ Email sent successfully: ${info.messageId}`);
  } catch (error) {
    console.error("❌ Email failed:", error.message);
    process.exit(1);
  }
}

// --- Execute Script ---
console.log("📧 Starting email script...");
zipHtmlReport();
const summary = parseJTL(RESULT_FILE);
if (summary) sendEmail(summary);
